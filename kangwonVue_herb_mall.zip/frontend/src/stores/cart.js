import { defineStore } from 'pinia'

const FREE_SHIPPING_THRESHOLD = 50000
const SHIPPING_FEE = 3200

export const useCartStore = defineStore('cart', {
  state: () => ({
    items: JSON.parse(localStorage.getItem('kw_cart') || '[]')
  }),
  getters: {
    count: (state) => state.items.reduce((sum, item) => sum + (item.qty || 1), 0),
    itemTotal: (state) => state.items.reduce((sum, item) => sum + ((item.price || 0) * (item.qty || 1)), 0),
    shippingFee: (state) => {
      const total = state.items.reduce((sum, item) => sum + ((item.price || 0) * (item.qty || 1)), 0)
      if (total === 0 || total >= FREE_SHIPPING_THRESHOLD) return 0
      return SHIPPING_FEE
    },
    freeShippingRemaining: (state) => {
      const total = state.items.reduce((sum, item) => sum + ((item.price || 0) * (item.qty || 1)), 0)
      if (total >= FREE_SHIPPING_THRESHOLD) return 0
      return FREE_SHIPPING_THRESHOLD - total
    },
    finalTotal: (state) => {
      const total = state.items.reduce((sum, item) => sum + ((item.price || 0) * (item.qty || 1)), 0)
      const fee = (total === 0 || total >= FREE_SHIPPING_THRESHOLD) ? 0 : SHIPPING_FEE
      return total + fee
    }
  },
  actions: {
    save() {
      localStorage.setItem('kw_cart', JSON.stringify(this.items))
    },
    addItem({ product, option = null, qty = 1 }) {
      const optionName = option ? option.name : '기본 단품'
      const unitPrice = product.price + (option?.price_diff || 0)
      const key = `${product.id || product._id}_${optionName}`

      const existingIndex = this.items.findIndex(item => item.key === key)
      if (existingIndex > -1) {
        this.items[existingIndex].qty += qty
      } else {
        this.items.push({
          key,
          product_id: product.id || product._id,
          name: product.name,
          option_name: optionName,
          price: unitPrice,
          qty,
          image: product.image
        })
      }
      this.save()
    },
    updateQty(key, qty) {
      const item = this.items.find(i => i.key === key)
      if (item) {
        item.qty = Math.max(1, qty)
        this.save()
      }
    },
    removeItem(key) {
      this.items = this.items.filter(i => i.key !== key)
      this.save()
    },
    clearCart() {
      this.items = []
      this.save()
    }
  }
})
