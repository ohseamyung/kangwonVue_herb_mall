import { defineStore } from 'pinia'
import api from '../api'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: JSON.parse(localStorage.getItem('kw_user') || 'null'),
    token: localStorage.getItem('kw_token') || null,
    loading: false
  }),
  getters: {
    isLoggedIn: (state) => !!state.token && !!state.user,
    isAdmin: (state) => state.user?.role === 'admin',
    userName: (state) => state.user?.name || '고객',
    userPoints: (state) => state.user?.points || 0
  },
  actions: {
    async login(username, password) {
      this.loading = true
      try {
        const res = await api.post('/auth/login', { username, password })
        this.token = res.token
        this.user = res.user
        localStorage.setItem('kw_token', res.token)
        localStorage.setItem('kw_user', JSON.stringify(res.user))
        return res
      } finally {
        this.loading = false
      }
    },
    async register(userData) {
      this.loading = true
      try {
        const res = await api.post('/auth/register', userData)
        this.token = res.token
        this.user = res.user
        localStorage.setItem('kw_token', res.token)
        localStorage.setItem('kw_user', JSON.stringify(res.user))
        return res
      } finally {
        this.loading = false
      }
    },
    async fetchMe() {
      if (!this.token) return
      try {
        const userData = await api.get('/auth/me')
        this.user = userData
        localStorage.setItem('kw_user', JSON.stringify(userData))
      } catch (err) {
        this.logout()
      }
    },
    logout() {
      this.user = null
      this.token = null
      localStorage.removeItem('kw_token')
      localStorage.removeItem('kw_user')
    }
  }
})
