<template>
  <footer class="mall-footer">
    <!-- Bottom Support / Bank Area -->
    <div class="footer-widgets">
      <div class="container widgets-inner">
        <!-- CS Box -->
        <div class="widget-box">
          <h4 class="widget-title"><i class="fa-solid fa-headset text-green"></i> 고객지원센터</h4>
          <div class="widget-content cs-body">
            <div class="cs-phone-big">033-762-8114</div>
            <div class="cs-phone-mobile">Tel. 010-8638-6380</div>
            <p class="cs-hours">AM 10:00 ~ PM 06:00</p>
            <p class="cs-holiday">SAT, SUN, HOLIDAY OFF</p>
          </div>
        </div>

        <!-- Bank Box -->
        <div class="widget-box">
          <h4 class="widget-title"><i class="fa-solid fa-building-columns text-green"></i> 은행계좌정보</h4>
          <div class="widget-content bank-body">
            <p class="bank-name">농협은행</p>
            <p class="bank-account">302-0851-0319-21</p>
            <p class="bank-holder">예금주 : <strong>강영자(강원약초)</strong></p>
            <p class="bank-tip">인터넷뱅킹 / 폰뱅킹 / 무통장입금 가능</p>
          </div>
        </div>

        <!-- Quick Board Links Box -->
        <div class="widget-box">
          <h4 class="widget-title"><i class="fa-solid fa-comments text-green"></i> 고객센터 게시판</h4>
          <div class="widget-content board-links-grid">
            <router-link to="/board/notice" class="board-pill">
              <i class="fa-solid fa-bullhorn"></i> 공지사항
            </router-link>
            <router-link to="/board/review" class="board-pill">
              <i class="fa-solid fa-star"></i> 구매후기
            </router-link>
            <router-link to="/board/qna" class="board-pill">
              <i class="fa-solid fa-circle-question"></i> 상품문의
            </router-link>
            <router-link to="/board/faq" class="board-pill">
              <i class="fa-solid fa-circle-info"></i> 자주묻는질문
            </router-link>
          </div>
        </div>
      </div>
    </div>

    <!-- Bottom Footer Links & Business Info -->
    <div class="footer-legal">
      <div class="container legal-inner">
        <ul class="legal-nav">
          <li><router-link to="/">홈</router-link></li>
          <li><a href="#" @click.prevent="alert('강원도 청정 자연에서 채취한 100% 토종 자연산 약초만을 고집하는 강원약초입니다.')">회사소개</a></li>
          <li><a href="#" @click.prevent="alert('전자상거래 표준 이용약관에 의거하여 고객님의 권익을 보장합니다.')">이용약관</a></li>
          <li><a href="#" @click.prevent="alert('개인정보보호법에 따라 고객님의 소중한 정보를 안전하게 암호화 관리합니다.')">개인정보보호정책</a></li>
          <li><router-link to="/board/faq">이용안내</router-link></li>
        </ul>

        <div class="business-info">
          <p>
            <span>상호 : 강원약초</span> | 
            <span>대표자 : 강영자</span> | 
            <span>주소 : 26323 강원특별자치도 원주시 육판길 27-11 (태장동)</span> | 
            <span>사업자등록번호 : 129-23-86759</span>
          </p>
          <p>
            <span>전화 : 033-762-8114 / 010-8638-6380</span> | 
            <span>통신판매업 신고 : 2010-강원원주-00187</span> | 
            <span>개인정보관리책임자 : 강영자 (<a href="mailto:glala1007@hanmail.net">glala1007@hanmail.net</a>)</span>
          </p>
          <p class="copyright">
            Copyright © 2021~2026 <strong>강원약초</strong>. All rights reserved. 본 사이트는 자연산 토종 약초 채취 판매 공식 쇼핑몰입니다.
          </p>
        </div>
      </div>
    </div>
  </footer>
</template>

<script setup>
const alert = window.alert
</script>

<style scoped>
.mall-footer {
  margin-top: 60px;
  background-color: #f8fafc;
  border-top: 1px solid #e2e8f0;
}

/* Widgets */
.footer-widgets {
  padding: 36px 0;
  border-bottom: 1px solid #e2e8f0;
}
.widgets-inner {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 32px;
}
.widget-box {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 20px 24px;
}
.widget-title {
  font-size: 15px;
  font-weight: 700;
  color: #1e293b;
  margin-bottom: 14px;
  display: flex;
  align-items: center;
  gap: 8px;
  border-bottom: 2px solid #eef7f0;
  padding-bottom: 8px;
}
.text-green {
  color: #276735;
}
.cs-phone-big {
  font-size: 24px;
  font-weight: 900;
  color: #276735;
  letter-spacing: -0.5px;
  line-height: 1.1;
}
.cs-phone-mobile {
  font-size: 14px;
  font-weight: 700;
  color: #475569;
  margin-top: 4px;
}
.cs-hours {
  font-size: 12px;
  color: #64748b;
  margin-top: 8px;
}
.cs-holiday {
  font-size: 11px;
  color: #94a3b8;
}

/* Bank */
.bank-name {
  font-size: 13px;
  color: #475569;
  font-weight: bold;
}
.bank-account {
  font-size: 18px;
  font-weight: 800;
  color: #1e293b;
  margin: 2px 0 6px 0;
  letter-spacing: 0.5px;
}
.bank-holder {
  font-size: 13px;
  color: #334155;
}
.bank-tip {
  font-size: 11px;
  color: #94a3b8;
  margin-top: 6px;
}

/* Board Pills */
.board-links-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}
.board-pill {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 600;
  color: #334155;
  background-color: #f8fafc;
  transition: all 0.2s;
}
.board-pill:hover {
  background-color: #eef7f0;
  color: #276735;
  border-color: #276735;
}

/* Legal */
.footer-legal {
  padding: 24px 0 36px 0;
  font-size: 12px;
  color: #64748b;
}
.legal-nav {
  display: flex;
  gap: 16px;
  margin-bottom: 16px;
  font-weight: 600;
}
.legal-nav a:hover {
  color: #276735;
  text-decoration: underline;
}
.business-info {
  display: flex;
  flex-direction: column;
  gap: 6px;
  line-height: 1.6;
}
.business-info a {
  color: #475569;
}
.copyright {
  margin-top: 8px;
  color: #94a3b8;
}

@media (max-width: 900px) {
  .widgets-inner {
    grid-template-columns: 1fr;
  }
}
</style>
