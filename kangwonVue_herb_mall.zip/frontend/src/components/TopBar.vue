<template>
  <div class="top-bar">
    <div class="container top-bar-inner">
      <div class="top-left">
        <button class="bookmark-btn" @click="addBookmark">
          <i class="fa-solid fa-star text-gold"></i> 즐겨찾기 추가
        </button>
        <span class="divider">|</span>
        <span class="delivery-notice">
          <i class="fa-solid fa-truck-fast text-green"></i> 50,000원 이상 무료배송
        </span>
      </div>
      <div class="top-right">
        <template v-if="authStore.isLoggedIn">
          <span class="user-greeting">
            <strong>{{ authStore.userName }}</strong>님 (적립금: <span class="points">{{ (authStore.userPoints || 0).toLocaleString() }}P</span>)
          </span>
          <span class="divider">|</span>
          <router-link to="/mypage">마이페이지</router-link>
          <span class="divider">|</span>
          <a href="#" @click.prevent="logout">로그아웃</a>
        </template>
        <template v-else>
          <router-link to="/login">로그인</router-link>
          <span class="divider">|</span>
          <router-link to="/register" class="join-link">
            회원가입 <span class="badge-point">+2,000P</span>
          </router-link>
        </template>
        <span class="divider">|</span>
        <router-link to="/cart" class="cart-link">
          장바구니
          <span v-if="cartStore.count > 0" class="cart-count">{{ cartStore.count }}</span>
        </router-link>
        <span class="divider">|</span>
        <router-link to="/order-lookup">주문조회</router-link>
        <span class="divider">|</span>
        <router-link to="/board/notice">고객센터</router-link>
        <template v-if="authStore.isAdmin">
          <span class="divider">|</span>
          <router-link to="/admin" class="admin-link">
            <i class="fa-solid fa-gear"></i> 관리자모드
          </router-link>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useAuthStore } from '../stores/auth'
import { useCartStore } from '../stores/cart'
import { useRouter } from 'vue-router'

const authStore = useAuthStore()
const cartStore = useCartStore()
const router = useRouter()

const logout = () => {
  if (confirm('로그아웃 하시겠습니까?')) {
    authStore.logout()
    router.push('/')
  }
}

const addBookmark = () => {
  alert('Ctrl + D 키를 누르시면 즐겨찾기에 추가됩니다!')
}
</script>

<style scoped>
.top-bar {
  background-color: #f8fafc;
  border-bottom: 1px solid #e2e8f0;
  font-size: 12px;
  color: #64748b;
  height: 36px;
}
.top-bar-inner {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 100%;
}
.top-left, .top-right {
  display: flex;
  align-items: center;
  gap: 8px;
}
.bookmark-btn {
  font-size: 12px;
  color: #64748b;
  display: flex;
  align-items: center;
  gap: 4px;
}
.bookmark-btn:hover {
  color: #276735;
}
.text-gold {
  color: #d97706;
}
.text-green {
  color: #276735;
}
.divider {
  color: #cbd5e1;
  font-size: 10px;
}
.join-link {
  display: flex;
  align-items: center;
  gap: 4px;
  color: #1e293b;
  font-weight: 600;
}
.badge-point {
  background-color: #e53e3e;
  color: #ffffff;
  font-size: 10px;
  padding: 1px 4px;
  border-radius: 3px;
  font-weight: bold;
}
.cart-link {
  display: flex;
  align-items: center;
  gap: 4px;
}
.cart-count {
  background-color: #276735;
  color: #ffffff;
  font-size: 11px;
  font-weight: bold;
  padding: 1px 5px;
  border-radius: 10px;
}
.points {
  color: #c04928;
  font-weight: bold;
}
.admin-link {
  color: #7c3aed;
  font-weight: bold;
}
</style>
