<template>
  <header class="main-header">
    <div class="container header-inner">
      <!-- Logo -->
      <div class="logo-area">
        <router-link to="/" class="logo-link">
          <div class="logo-symbol">
            <i class="fa-solid fa-seedling"></i>
          </div>
          <div class="logo-text">
            <span class="logo-sub">강원도 자연산 토종약초 채취 판매</span>
            <h1 class="logo-title">강원약초</h1>
          </div>
        </router-link>
      </div>

      <!-- Search Area -->
      <div class="search-area">
        <form class="search-box" @submit.prevent="handleSearch">
          <input 
            type="text" 
            v-model="searchQuery" 
            placeholder="자연산 약초, 버섯, 액기스, 증상 검색"
            class="search-input"
          />
          <button type="submit" class="search-btn">
            <i class="fa-solid fa-magnifying-glass"></i>
          </button>
        </form>
        <div class="popular-keywords">
          <span class="keyword-label">인기검색:</span>
          <button @click="quickSearch('말굽버섯')">말굽버섯</button>
          <button @click="quickSearch('마가목')">마가목</button>
          <button @click="quickSearch('쌍화차')">쌍화차</button>
          <button @click="quickSearch('산양산삼')">산양산삼</button>
          <button @click="quickSearch('당귀')">당귀</button>
        </div>
      </div>

      <!-- Customer Center Banner -->
      <div class="cs-info-box">
        <div class="cs-tel-row">
          <div class="cs-icon">
            <i class="fa-solid fa-phone-volume"></i>
          </div>
          <div class="cs-numbers">
            <strong class="tel-main">033-762-8114</strong>
            <span class="tel-sub">Tel. 010-8638-6380</span>
          </div>
        </div>
        <div class="cs-meta">
          <span>상담시간: AM 10:00 ~ PM 06:00</span>
          <span>(토, 일, 공휴일 휴무)</span>
        </div>
      </div>
    </div>
  </header>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const searchQuery = ref('')
const router = useRouter()

const handleSearch = () => {
  if (searchQuery.value.trim()) {
    router.push({ path: '/products', query: { search: searchQuery.value.trim() } })
  }
}

const quickSearch = (keyword) => {
  searchQuery.value = keyword
  router.push({ path: '/products', query: { search: keyword } })
}
</script>

<style scoped>
.main-header {
  padding: 24px 0 16px 0;
  background-color: #ffffff;
}
.header-inner {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 24px;
}

/* Logo */
.logo-area .logo-link {
  display: flex;
  align-items: center;
  gap: 12px;
}
.logo-symbol {
  width: 50px;
  height: 50px;
  background-color: #276735;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-size: 26px;
  box-shadow: 0 4px 10px rgba(39, 103, 53, 0.25);
}
.logo-text {
  display: flex;
  flex-direction: column;
}
.logo-sub {
  font-size: 12px;
  color: #5c7060;
  font-weight: 500;
  letter-spacing: -0.3px;
}
.logo-title {
  font-size: 32px;
  font-weight: 900;
  color: #1a4d25;
  letter-spacing: -1.5px;
  line-height: 1.1;
}

/* Search */
.search-area {
  flex: 1;
  max-width: 440px;
}
.search-box {
  display: flex;
  align-items: center;
  border: 2px solid #276735;
  border-radius: 24px;
  overflow: hidden;
  background: #ffffff;
  padding: 2px;
}
.search-input {
  flex: 1;
  padding: 9px 16px;
  border: none;
  outline: none;
  font-size: 13px;
  color: #333333;
}
.search-btn {
  width: 42px;
  height: 38px;
  background-color: #276735;
  color: #ffffff;
  font-size: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  margin-right: 2px;
  transition: background-color 0.2s;
}
.search-btn:hover {
  background-color: #1c4d26;
}
.popular-keywords {
  margin-top: 6px;
  font-size: 11px;
  color: #888888;
  display: flex;
  align-items: center;
  gap: 8px;
  padding-left: 8px;
}
.popular-keywords button {
  color: #555555;
  font-size: 11px;
  padding: 0;
  background: none;
}
.popular-keywords button:hover {
  color: #276735;
  text-decoration: underline;
}

/* CS Box */
.cs-info-box {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 10px 16px;
  background: #f8fafc;
  min-width: 220px;
}
.cs-tel-row {
  display: flex;
  align-items: center;
  gap: 10px;
}
.cs-icon {
  font-size: 20px;
  color: #276735;
}
.cs-numbers {
  display: flex;
  flex-direction: column;
}
.tel-main {
  font-size: 18px;
  color: #1a202c;
  font-weight: 800;
  line-height: 1.1;
}
.tel-sub {
  font-size: 12px;
  color: #64748b;
  font-weight: 600;
}
.cs-meta {
  font-size: 11px;
  color: #888888;
  margin-top: 4px;
  display: flex;
  flex-direction: column;
  line-height: 1.3;
}

@media (max-width: 900px) {
  .header-inner {
    flex-direction: column;
    align-items: stretch;
  }
  .search-area {
    max-width: 100%;
  }
}
</style>
