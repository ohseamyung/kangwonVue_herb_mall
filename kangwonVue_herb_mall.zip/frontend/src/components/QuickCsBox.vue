<template>
  <div class="quick-floating-bar">
    <!-- Cart Pill -->
    <router-link to="/cart" class="quick-btn cart-pill">
      <i class="fa-solid fa-cart-shopping"></i>
      <span class="pill-label">장바구니</span>
      <span v-if="cartStore.count > 0" class="pill-badge">{{ cartStore.count }}</span>
    </router-link>

    <!-- CS Direct Call -->
    <a href="tel:033-762-8114" class="quick-btn cs-pill">
      <i class="fa-solid fa-headset"></i>
      <span class="pill-label">전화상담</span>
    </a>

    <!-- Bank Info Tooltip -->
    <button class="quick-btn bank-pill" @click="showBankModal = !showBankModal">
      <i class="fa-solid fa-building-columns"></i>
      <span class="pill-label">계좌안내</span>
    </button>

    <!-- Top Scroll -->
    <button class="quick-btn top-pill" @click="scrollToTop">
      <i class="fa-solid fa-chevron-up"></i>
      <span class="pill-label">TOP</span>
    </button>

    <!-- Bank Info Popup -->
    <div v-if="showBankModal" class="bank-popup">
      <div class="popup-header">
        <strong>무통장 입금 계좌</strong>
        <button class="close-btn" @click="showBankModal = false">&times;</button>
      </div>
      <div class="popup-body">
        <p class="bank-row"><strong>농협은행</strong></p>
        <p class="acc-row">302-0851-0319-21</p>
        <p class="holder-row">예금주: 강영자(강원약초)</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useCartStore } from '../stores/cart'

const cartStore = useCartStore()
const showBankModal = ref(false)

const scrollToTop = () => {
  window.scrollTo({ top: 0, behavior: 'smooth' })
}
</script>

<style scoped>
.quick-floating-bar {
  position: fixed;
  right: 20px;
  bottom: 80px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  z-index: 100;
}
.quick-btn {
  width: 58px;
  height: 58px;
  background-color: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
  color: #334155;
  transition: all 0.2s;
  position: relative;
  text-decoration: none;
}
.quick-btn:hover {
  background-color: #276735;
  color: #ffffff;
  border-color: #276735;
  transform: translateY(-3px);
}
.quick-btn i {
  font-size: 16px;
  margin-bottom: 2px;
}
.pill-label {
  font-size: 10px;
  font-weight: 700;
}
.pill-badge {
  position: absolute;
  top: -2px;
  right: -2px;
  background-color: #e53e3e;
  color: #ffffff;
  font-size: 11px;
  font-weight: bold;
  padding: 1px 6px;
  border-radius: 10px;
  border: 2px solid #ffffff;
}
.top-pill {
  background-color: #1e293b;
  color: #ffffff;
  border-color: #1e293b;
}
.top-pill:hover {
  background-color: #0f172a;
}

/* Bank Popup */
.bank-popup {
  position: absolute;
  right: 70px;
  bottom: 60px;
  width: 220px;
  background: #ffffff;
  border: 2px solid #276735;
  border-radius: 8px;
  box-shadow: 0 10px 25px rgba(0,0,0,0.2);
  padding: 12px;
  z-index: 110;
}
.popup-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #edf2f7;
  padding-bottom: 6px;
  font-size: 13px;
  color: #276735;
}
.close-btn {
  font-size: 18px;
  color: #94a3b8;
}
.popup-body {
  margin-top: 8px;
  font-size: 12px;
  line-height: 1.4;
}
.acc-row {
  font-size: 14px;
  font-weight: 800;
  color: #1e293b;
  margin: 2px 0;
}
</style>
