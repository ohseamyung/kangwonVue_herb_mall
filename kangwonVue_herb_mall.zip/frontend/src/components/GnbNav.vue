<template>
  <nav class="gnb-wrapper">
    <div class="container gnb-inner">
      <!-- Mega Category Dropdown Trigger -->
      <div 
        class="category-btn-wrap"
        @mouseenter="isMenuOpen = true"
        @mouseleave="isMenuOpen = false"
      >
        <button class="category-toggle-btn" @click="isMenuOpen = !isMenuOpen">
          <i class="fa-solid fa-bars"></i>
          <span>▤ 전체 카테고리</span>
        </button>

        <!-- Dropdown Menu -->
        <div v-show="isMenuOpen" class="category-dropdown">
          <ul class="dropdown-list">
            <li v-for="cat in categories" :key="cat.slug" class="dropdown-item">
              <router-link :to="`/category/${cat.slug}`" @click="isMenuOpen = false">
                <i class="fa-solid" :class="cat.icon || 'fa-leaf'"></i>
                <span class="cat-name">{{ cat.name }}</span>
                <span v-if="cat.product_count" class="cat-count">({{ cat.product_count }})</span>
              </router-link>
            </li>
          </ul>
        </div>
      </div>

      <!-- Main Horizontal Links -->
      <ul class="nav-links">
        <li v-for="cat in categories.slice(0, 8)" :key="cat.slug">
          <router-link :to="`/category/${cat.slug}`" active-class="active-link">
            {{ cat.name }}
          </router-link>
        </li>
        <li>
          <router-link to="/category/best-items" class="best-tab" active-class="active-link">
            <i class="fa-solid fa-fire"></i> BEST
          </router-link>
        </li>
      </ul>

      <!-- Community quick links -->
      <ul class="community-links">
        <li><router-link to="/board/notice">공지사항</router-link></li>
        <li><router-link to="/board/review">구매후기</router-link></li>
        <li><router-link to="/board/qna">상품문의</router-link></li>
        <li><router-link to="/board/faq">FAQ</router-link></li>
      </ul>
    </div>
  </nav>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'

const isMenuOpen = ref(false)
const categories = ref([])

onMounted(async () => {
  try {
    const data = await api.get('/categories')
    categories.value = data
  } catch (err) {
    console.error('Failed to load categories', err)
  }
})
</script>

<style scoped>
.gnb-wrapper {
  background-color: #276735;
  color: #ffffff;
  border-bottom: 2px solid #1c4d26;
  position: relative;
  z-index: 50;
}
.gnb-inner {
  display: flex;
  align-items: center;
  height: 48px;
}

/* Category Button */
.category-btn-wrap {
  position: relative;
  height: 100%;
}
.category-toggle-btn {
  background-color: #1b4925;
  color: #ffffff;
  height: 100%;
  padding: 0 20px;
  font-size: 14px;
  font-weight: 700;
  display: flex;
  align-items: center;
  gap: 8px;
  letter-spacing: -0.5px;
}
.category-toggle-btn:hover {
  background-color: #15391d;
}

/* Dropdown */
.category-dropdown {
  position: absolute;
  top: 100%;
  left: 0;
  width: 220px;
  background-color: #ffffff;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
  border: 1px solid #cbd5e1;
  border-top: none;
  z-index: 100;
}
.dropdown-list {
  padding: 6px 0;
}
.dropdown-item a {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  font-size: 13px;
  color: #334155;
  font-weight: 600;
  transition: all 0.15s;
}
.dropdown-item a:hover {
  background-color: #eef7f0;
  color: #276735;
  padding-left: 20px;
}
.dropdown-item i {
  color: #276735;
  font-size: 14px;
  width: 16px;
  text-align: center;
}
.cat-count {
  font-size: 11px;
  color: #94a3b8;
  margin-left: auto;
}

/* Nav Links */
.nav-links {
  display: flex;
  align-items: center;
  height: 100%;
  margin-left: 12px;
}
.nav-links li {
  height: 100%;
}
.nav-links a {
  display: flex;
  align-items: center;
  height: 100%;
  padding: 0 14px;
  font-size: 14px;
  font-weight: 600;
  color: #ffffff;
  transition: background-color 0.2s;
  white-space: nowrap;
}
.nav-links a:hover,
.active-link {
  background-color: #1e5229;
}
.best-tab {
  color: #fed7aa !important;
  font-weight: bold;
}

/* Community Links */
.community-links {
  display: flex;
  align-items: center;
  margin-left: auto;
  gap: 16px;
  font-size: 12px;
}
.community-links a {
  color: #e2e8f0;
  transition: color 0.2s;
}
.community-links a:hover {
  color: #ffffff;
  text-decoration: underline;
}

@media (max-width: 1100px) {
  .community-links {
    display: none;
  }
}
</style>
