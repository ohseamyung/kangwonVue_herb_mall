<template>
  <div class="banner-slider">
    <div 
      class="slider-container"
      :style="{ transform: `translateX(-${currentSlide * 100}%)` }"
    >
      <div 
        v-for="(banner, idx) in banners" 
        :key="idx"
        class="slide-item"
        :style="{ background: `linear-gradient(135deg, ${banner.bg_color || '#1b4925'}, #0d2914)` }"
      >
        <div class="container slide-content">
          <div class="slide-text">
            <span class="slide-tag">{{ banner.tag || '산지직송' }}</span>
            <h2 class="slide-title">{{ banner.title }}</h2>
            <p class="slide-subtitle">{{ banner.subtitle }}</p>
            <router-link :to="banner.link || '/category/nature-herbs'" class="slide-btn">
              {{ banner.button_text || '자세히 보기' }}
              <i class="fa-solid fa-arrow-right"></i>
            </router-link>
          </div>
          <div class="slide-graphic">
            <div class="graphic-circle">
              <i class="fa-solid fa-leaf"></i>
              <span>100% 자연산</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Navigation Arrows -->
    <button class="slide-arrow prev" @click="prevSlide">
      <i class="fa-solid fa-chevron-left"></i>
    </button>
    <button class="slide-arrow next" @click="nextSlide">
      <i class="fa-solid fa-chevron-right"></i>
    </button>

    <!-- Dots -->
    <div class="slide-dots">
      <button 
        v-for="(_, idx) in banners" 
        :key="idx" 
        class="dot"
        :class="{ active: currentSlide === idx }"
        @click="currentSlide = idx"
      ></button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import api from '../api'

const banners = ref([
  {
    title: "강원도 청정 자연의 숨결, 100% 자연산 토종약초",
    subtitle: "해발 600m 이상 강원도 고지대에서 정성껏 채취한 산지직송 건강",
    bg_color: "#1c3d27",
    tag: "산지직송",
    link: "/category/nature-herbs",
    button_text: "자연산 약초 보러가기"
  },
  {
    title: "48시간 저온추출 수제 마가목·민들레 진액즙",
    subtitle: "인공첨가물 0%! 순수 원적외선 특수추출로 깊은 맛과 영양을 그대로",
    bg_color: "#2c261e",
    tag: "프리미엄 엑기스",
    link: "/category/liquid-extract",
    button_text: "수제 진액즙 보기"
  },
  {
    title: "전통 비법 그대로, 수제 쌍화차 & 십전대보차 세트",
    subtitle: "엄선된 10~11가지 최고급 약재로 집에서 간편하게 달여 마시는 보약",
    bg_color: "#382314",
    tag: "건강선물세트",
    link: "/category/ssanghwa-tea",
    button_text: "한방차 세트 보기"
  }
])

const currentSlide = ref(0)
let timer = null

const nextSlide = () => {
  currentSlide.value = (currentSlide.value + 1) % banners.value.length
}

const prevSlide = () => {
  currentSlide.value = (currentSlide.value - 1 + banners.value.length) % banners.value.length
}

onMounted(async () => {
  try {
    const data = await api.get('/banners')
    if (data && data.length > 0) {
      banners.value = data
    }
  } catch (err) {
    // default banners already defined
  }
  timer = setInterval(nextSlide, 5000)
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
})
</script>

<style scoped>
.banner-slider {
  position: relative;
  overflow: hidden;
  height: 380px;
  background-color: #1b4925;
}
.slider-container {
  display: flex;
  height: 100%;
  transition: transform 0.6s cubic-bezier(0.25, 1, 0.5, 1);
}
.slide-item {
  min-width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  color: #ffffff;
}
.slide-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}
.slide-text {
  max-width: 600px;
}
.slide-tag {
  display: inline-block;
  background-color: rgba(255, 255, 255, 0.2);
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 12px;
  letter-spacing: -0.3px;
  backdrop-filter: blur(4px);
}
.slide-title {
  font-size: 32px;
  font-weight: 800;
  line-height: 1.25;
  margin-bottom: 12px;
  letter-spacing: -1px;
}
.slide-subtitle {
  font-size: 15px;
  color: rgba(255, 255, 255, 0.85);
  margin-bottom: 24px;
  line-height: 1.5;
}
.slide-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background-color: #ffffff;
  color: #1b4925;
  font-weight: 700;
  font-size: 14px;
  padding: 12px 24px;
  border-radius: 24px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  transition: transform 0.2s, background-color 0.2s;
}
.slide-btn:hover {
  background-color: #f1f5f9;
  transform: translateY(-2px);
}

.slide-graphic {
  display: flex;
  align-items: center;
  justify-content: center;
}
.graphic-circle {
  width: 180px;
  height: 180px;
  border: 2px dashed rgba(255, 255, 255, 0.35);
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(8px);
}
.graphic-circle i {
  font-size: 48px;
  color: #86efac;
}
.graphic-circle span {
  font-size: 15px;
  font-weight: bold;
  letter-spacing: 1px;
}

/* Arrows */
.slide-arrow {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 44px;
  height: 44px;
  background-color: rgba(0, 0, 0, 0.3);
  color: #ffffff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  transition: background-color 0.2s;
  z-index: 10;
}
.slide-arrow:hover {
  background-color: rgba(0, 0, 0, 0.6);
}
.slide-arrow.prev {
  left: 20px;
}
.slide-arrow.next {
  right: 20px;
}

/* Dots */
.slide-dots {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 8px;
  z-index: 10;
}
.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background-color: rgba(255, 255, 255, 0.4);
  transition: all 0.3s;
}
.dot.active {
  width: 28px;
  border-radius: 5px;
  background-color: #ffffff;
}

@media (max-width: 768px) {
  .banner-slider {
    height: 320px;
  }
  .slide-graphic {
    display: none;
  }
  .slide-title {
    font-size: 24px;
  }
}
</style>
