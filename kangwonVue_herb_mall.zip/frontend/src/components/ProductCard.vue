<template>
  <div class="product-card">
    <div class="card-thumb-wrap">
      <router-link :to="`/product/${product.id || product._id}`" class="thumb-link">
        <img 
          :src="product.image || '/static/images/p_mushroom_horse.jpg'" 
          :alt="product.name" 
          class="product-thumb"
          loading="lazy"
          @error="handleImgError"
        />
      </router-link>

      <!-- Badges -->
      <div class="card-badges">
        <span v-if="product.badge" class="badge badge-hit">{{ product.badge }}</span>
        <span v-if="product.is_best" class="badge badge-best">BEST</span>
        <span v-if="discountRate > 0" class="badge badge-discount">{{ discountRate }}% OFF</span>
      </div>

      <!-- Quick Action Floating Button -->
      <div class="quick-actions">
        <button class="action-btn" title="장바구니 담기" @click.stop="quickAddToCart">
          <i class="fa-solid fa-cart-shopping"></i>
        </button>
      </div>
    </div>

    <div class="card-info">
      <!-- Product Name -->
      <h3 class="product-name">
        <router-link :to="`/product/${product.id || product._id}`">
          {{ product.name }}
        </router-link>
      </h3>

      <!-- Summary -->
      <p v-if="product.summary" class="product-summary">
        {{ product.summary }}
      </p>

      <!-- Price Box matching kangwons.com -->
      <div class="price-table">
        <div v-if="product.original_price && product.original_price > product.price" class="price-row original">
          <span class="label">소비자가 :</span>
          <span class="val strikethrough">{{ product.original_price.toLocaleString() }}원</span>
        </div>
        <div class="price-row sale">
          <span class="label">판매가 :</span>
          <span class="val price-val">
            <strong>{{ product.price.toLocaleString() }}</strong>원
            <span v-if="discountRate > 0" class="discount-percent">{{ discountRate }}%</span>
          </span>
        </div>
        <div class="price-row meta">
          <span class="label">배송비 :</span>
          <span class="val">3,200원 (5만원 이상 무료)</span>
        </div>
        <div class="price-row meta">
          <span class="label">원산지 :</span>
          <span class="val">{{ product.origin || '국산' }}</span>
        </div>
        <div class="price-row meta">
          <span class="label">적립금 :</span>
          <span class="val point-val">1% ({{ Math.floor(product.price * 0.01).toLocaleString() }}P)</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useCartStore } from '../stores/cart'

const props = defineProps({
  product: {
    type: Object,
    required: true
  }
})

const cartStore = useCartStore()

const discountRate = computed(() => {
  if (props.product.original_price && props.product.original_price > props.product.price) {
    return Math.round(((props.product.original_price - props.product.price) / props.product.original_price) * 100)
  }
  return 0
})

const quickAddToCart = () => {
  cartStore.addItem({ product: props.product, qty: 1 })
  alert(`[${props.product.name}] 상품이 장바구니에 담겼습니다!`)
}

const handleImgError = (e) => {
  e.target.src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=60'
}
</script>

<style scoped>
.product-card {
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  overflow: hidden;
  transition: transform 0.2s, box-shadow 0.2s, border-color 0.2s;
  display: flex;
  flex-direction: column;
}
.product-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.08);
  border-color: #276735;
}

/* Thumbnail */
.card-thumb-wrap {
  position: relative;
  width: 100%;
  padding-top: 85%;
  overflow: hidden;
  background-color: #f8fafc;
}
.thumb-link {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}
.product-thumb {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}
.product-card:hover .product-thumb {
  transform: scale(1.05);
}

/* Badges */
.card-badges {
  position: absolute;
  top: 8px;
  left: 8px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  z-index: 5;
}
.badge-discount {
  background-color: #c04928;
  color: #ffffff;
}

/* Quick Actions */
.quick-actions {
  position: absolute;
  bottom: 8px;
  right: 8px;
  opacity: 0;
  transform: translateY(10px);
  transition: all 0.2s;
  z-index: 5;
}
.product-card:hover .quick-actions {
  opacity: 1;
  transform: translateY(0);
}
.action-btn {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background-color: #276735;
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 6px rgba(0,0,0,0.2);
  transition: background-color 0.2s, transform 0.1s;
}
.action-btn:hover {
  background-color: #1b4925;
  transform: scale(1.1);
}

/* Card Info */
.card-info {
  padding: 14px;
  display: flex;
  flex-direction: column;
  flex: 1;
}
.product-name {
  font-size: 14px;
  font-weight: 700;
  color: #1a202c;
  line-height: 1.4;
  margin-bottom: 6px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  height: 40px;
}
.product-name a:hover {
  color: #276735;
}
.product-summary {
  font-size: 11px;
  color: #718096;
  margin-bottom: 10px;
  line-height: 1.35;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* Price Table matching classic kangwons.com */
.price-table {
  font-size: 11px;
  color: #4a5568;
  border-top: 1px solid #edf2f7;
  padding-top: 8px;
  margin-top: auto;
  display: flex;
  flex-direction: column;
  gap: 3px;
}
.price-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.price-row .label {
  color: #718096;
  width: 55px;
}
.strikethrough {
  text-decoration: line-through;
  color: #a0aec0;
}
.price-row.sale {
  margin: 2px 0;
}
.price-val {
  color: #c04928;
  font-size: 13px;
}
.price-val strong {
  font-size: 16px;
  font-weight: 800;
}
.discount-percent {
  color: #c04928;
  font-weight: bold;
  font-size: 11px;
  margin-left: 4px;
}
.point-val {
  color: #276735;
  font-weight: 600;
}
</style>
