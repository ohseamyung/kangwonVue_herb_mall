import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import ProductListView from '../views/ProductListView.vue'
import ProductDetailView from '../views/ProductDetailView.vue'
import CartView from '../views/CartView.vue'
import CheckoutView from '../views/CheckoutView.vue'
import OrderCompleteView from '../views/OrderCompleteView.vue'
import MyPageView from '../views/MyPageView.vue'
import OrderLookupView from '../views/OrderLookupView.vue'
import BoardView from '../views/BoardView.vue'
import LoginView from '../views/LoginView.vue'
import RegisterView from '../views/RegisterView.vue'
import AdminView from '../views/AdminView.vue'

const routes = [
  { path: '/', name: 'home', component: HomeView },
  { path: '/category/:slug', name: 'category', component: ProductListView },
  { path: '/products', name: 'products', component: ProductListView },
  { path: '/product/:id', name: 'product-detail', component: ProductDetailView },
  { path: '/cart', name: 'cart', component: CartView },
  { path: '/checkout', name: 'checkout', component: CheckoutView },
  { path: '/order-complete/:orderNumber', name: 'order-complete', component: OrderCompleteView },
  { path: '/mypage', name: 'mypage', component: MyPageView },
  { path: '/order-lookup', name: 'order-lookup', component: OrderLookupView },
  { path: '/board/:boardType', name: 'board', component: BoardView },
  { path: '/login', name: 'login', component: LoginView },
  { path: '/register', name: 'register', component: RegisterView },
  { path: '/admin', name: 'admin', component: AdminView },
  { path: '/:pathMatch(.*)*', redirect: '/' }
]

const router = createRouter({
  history: createWebHistory('/vue/'),
  routes,
  scrollBehavior() {
    return { top: 0 }
  }
})

export default router
