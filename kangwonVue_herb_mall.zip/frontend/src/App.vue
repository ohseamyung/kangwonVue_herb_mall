<template>
  <div class="app-layout">
    <!-- Top Utility Bar -->
    <TopBar />

    <!-- Main Header with Logo, Search, CS info -->
    <Header />

    <!-- Category Mega GNB Navigation -->
    <GnbNav />

    <!-- Main Dynamic Route View -->
    <main class="main-content">
      <router-view />
    </main>

    <!-- Footer with Business, Bank, CS info -->
    <Footer />

    <!-- Floating Quick Action Bar -->
    <QuickCsBox />
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import TopBar from './components/TopBar.vue'
import Header from './components/Header.vue'
import GnbNav from './components/GnbNav.vue'
import Footer from './components/Footer.vue'
import QuickCsBox from './components/QuickCsBox.vue'
import { useAuthStore } from './stores/auth'

const authStore = useAuthStore()

onMounted(() => {
  if (authStore.token) {
    authStore.fetchMe()
  }
})
</script>

<style scoped>
.app-layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}
.main-content {
  flex: 1;
}
</style>
