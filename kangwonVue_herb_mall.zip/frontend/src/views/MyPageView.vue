<template>
  <div class="mypage-view container">
    <h2 class="page-title">마이페이지</h2>

    <!-- User Profile Summary Box -->
    <div class="profile-summary-card">
      <div class="user-avatar-col">
        <div class="user-avatar"><i class="fa-solid fa-user"></i></div>
        <div class="user-main-info">
          <h3><strong>{{ authStore.userName }}</strong>님 환영합니다!</h3>
          <p class="user-email">{{ authStore.user?.email || authStore.user?.username }}</p>
        </div>
      </div>
      <div class="user-stats-col">
        <div class="stat-box">
          <span class="stat-label">보유 적립금</span>
          <span class="stat-val text-green">{{ (authStore.userPoints || 0).toLocaleString() }}P</span>
        </div>
        <div class="stat-box">
          <span class="stat-label">총 주문 건수</span>
          <span class="stat-val">{{ orders.length }}건</span>
        </div>
      </div>
    </div>

    <!-- Tab navigation: 주문내역 / 적립금 내역 / 회원정보수정 -->
    <div class="mypage-tabs">
      <button :class="{ active: currentTab === 'orders' }" @click="currentTab = 'orders'">
        주문/배송 내역 ({{ orders.length }})
      </button>
      <button :class="{ active: currentTab === 'points' }" @click="currentTab = 'points'">
        적립금 내역
      </button>
      <button :class="{ active: currentTab === 'profile' }" @click="currentTab = 'profile'">
        회원 정보 수정
      </button>
    </div>

    <!-- Tab 1: Orders -->
    <div v-if="currentTab === 'orders'" class="tab-content">
      <div v-if="orders.length === 0" class="empty-list">
        <i class="fa-solid fa-box-open empty-icon"></i>
        <p>주문 내역이 없습니다.</p>
        <router-link to="/" class="btn btn-primary btn-sm">약초 쇼핑하러 가기</router-link>
      </div>
      <div v-else class="orders-list">
        <div v-for="order in orders" :key="order.id || order._id" class="order-card">
          <div class="order-card-header">
            <div>
              <span class="order-date">{{ formatDate(order.created_at) }}</span>
              <span class="order-number">주문번호: {{ order.order_number }}</span>
            </div>
            <span class="order-status-badge" :class="getStatusClass(order.status)">
              {{ order.status || '입금대기' }}
            </span>
          </div>

          <div class="order-card-body">
            <div v-for="(it, idx) in order.items" :key="idx" class="order-item-row">
              <img :src="it.image || '/static/images/p_mushroom_horse.jpg'" class="item-thumb" />
              <div class="item-info">
                <strong>{{ it.product_name }}</strong>
                <span class="item-opt">옵션: {{ it.option_name }} / {{ it.qty }}개</span>
              </div>
              <div class="item-price">
                {{ ((it.price || 0) * (it.qty || 1)).toLocaleString() }}원
              </div>
            </div>
          </div>

          <div class="order-card-footer">
            <div class="footer-left">
              <span>결제수단: {{ order.payment_method === 'bank_transfer' ? '무통장입금' : '카드/간편결제' }}</span>
              <span v-if="order.used_points > 0" class="used-pts"> (적립금 {{ order.used_points.toLocaleString() }}P 사용)</span>
            </div>
            <div class="footer-right">
              <span>최종 결제금액: <strong>{{ order.final_total?.toLocaleString() }}원</strong></span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Tab 2: Points -->
    <div v-if="currentTab === 'points'" class="tab-content">
      <div class="points-card">
        <h3>적립금 적립/사용 내역</h3>
        <table class="mall-table">
          <thead>
            <tr>
              <th style="width: 140px;">일자</th>
              <th>내용</th>
              <th style="width: 120px;">변동금액</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(hist, idx) in pointHistory" :key="idx">
              <td style="text-align: center;">{{ formatDate(hist.created_at) }}</td>
              <td>{{ hist.desc }}</td>
              <td style="text-align: right;" :class="hist.amount > 0 ? 'text-green font-bold' : 'text-red font-bold'">
                {{ hist.amount > 0 ? `+${hist.amount.toLocaleString()}` : hist.amount.toLocaleString() }}P
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Tab 3: Profile Edit -->
    <div v-if="currentTab === 'profile'" class="tab-content">
      <div class="profile-edit-card">
        <h3>회원정보 수정</h3>
        <form @submit.prevent="updateProfile">
          <div class="form-row">
            <label>아이디</label>
            <input type="text" :value="authStore.user?.username" class="form-input" disabled />
          </div>
          <div class="form-row">
            <label>성명</label>
            <input type="text" v-model="profileForm.name" class="form-input" required />
          </div>
          <div class="form-row">
            <label>연락처</label>
            <input type="tel" v-model="profileForm.phone" class="form-input" required />
          </div>
          <div class="form-row">
            <label>이메일</label>
            <input type="email" v-model="profileForm.email" class="form-input" />
          </div>
          <div class="form-row">
            <label>기본 배송주소</label>
            <input type="text" v-model="profileForm.address" class="form-input" />
          </div>
          <div class="form-row">
            <label>새 비밀번호 (변경 시에만 입력)</label>
            <input type="password" v-model="profileForm.password" placeholder="변경할 비밀번호" class="form-input" />
          </div>
          <button type="submit" class="btn btn-primary btn-lg">수정 완료</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'
import api from '../api'

const router = useRouter()
const authStore = useAuthStore()

const currentTab = ref('orders')
const orders = ref([])

const profileForm = ref({
  name: '',
  phone: '',
  email: '',
  address: '',
  password: ''
})

const pointHistory = computed(() => {
  return authStore.user?.point_history || [
    { desc: '신규 회원가입 축하 적립금', amount: 2000, created_at: new Date() }
  ]
})

const formatDate = (isoStr) => {
  if (!isoStr) return ''
  return typeof isoStr === 'string' ? isoStr.substring(0, 10) : ''
}

const getStatusClass = (status) => {
  if (status === '결제완료') return 'status-paid'
  if (status === '배송중' || status === '상품준비중') return 'status-shipping'
  if (status === '배송완료') return 'status-delivered'
  return 'status-pending'
}

const updateProfile = async () => {
  try {
    const res = await api.put('/auth/me', profileForm.value)
    alert(res.message)
    authStore.user = res.user
  } catch (err) {
    alert(err.message)
  }
}

onMounted(async () => {
  if (!authStore.isLoggedIn) {
    alert('로그인이 필요한 페이지입니다.')
    router.push('/login')
    return
  }

  profileForm.value = {
    name: authStore.user?.name || '',
    phone: authStore.user?.phone || '',
    email: authStore.user?.email || '',
    address: authStore.user?.address || '',
    password: ''
  }

  try {
    const res = await api.get('/orders')
    orders.value = res
  } catch (err) {
    console.error('Failed to load orders', err)
  }
})
</script>

<style scoped>
.mypage-view {
  padding: 30px 16px 80px 16px;
}
.page-title {
  font-size: 24px;
  font-weight: 800;
  color: #1a202c;
  margin-bottom: 24px;
  border-bottom: 2px solid #276735;
  padding-bottom: 12px;
}

/* Profile Summary */
.profile-summary-card {
  background: linear-gradient(135deg, #1b4925, #276735);
  color: #ffffff;
  border-radius: 12px;
  padding: 28px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
}
.user-avatar-col {
  display: flex;
  align-items: center;
  gap: 16px;
}
.user-avatar {
  width: 56px;
  height: 56px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}
.user-main-info h3 {
  font-size: 20px;
  margin-bottom: 4px;
}
.user-email {
  font-size: 13px;
  color: #d1fae5;
}
.user-stats-col {
  display: flex;
  gap: 32px;
}
.stat-box {
  text-align: center;
  background: rgba(255, 255, 255, 0.1);
  padding: 12px 24px;
  border-radius: 8px;
}
.stat-label {
  display: block;
  font-size: 12px;
  color: #d1fae5;
  margin-bottom: 4px;
}
.stat-val {
  font-size: 20px;
  font-weight: 800;
}

/* Tabs */
.mypage-tabs {
  display: flex;
  border-bottom: 2px solid #276735;
  margin-bottom: 24px;
}
.mypage-tabs button {
  padding: 14px 24px;
  font-size: 15px;
  font-weight: 700;
  color: #64748b;
  border: 1px solid #e2e8f0;
  border-bottom: none;
  background: #f8fafc;
  transition: all 0.2s;
}
.mypage-tabs button.active {
  background: #276735;
  color: #ffffff;
  border-color: #276735;
}

/* Orders List */
.empty-list {
  text-align: center;
  padding: 60px 20px;
  background-color: #f8fafc;
  border-radius: 8px;
}
.empty-icon {
  font-size: 48px;
  color: #cbd5e1;
  margin-bottom: 12px;
}
.orders-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.order-card {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  overflow: hidden;
  background: #ffffff;
}
.order-card-header {
  background-color: #f8fafc;
  padding: 12px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #edf2f7;
  font-size: 13px;
}
.order-date {
  font-weight: 700;
  color: #1e293b;
  margin-right: 12px;
}
.order-number {
  color: #64748b;
}

.order-status-badge {
  font-size: 12px;
  font-weight: 700;
  padding: 3px 8px;
  border-radius: 4px;
}
.status-pending {
  background: #fef3c7;
  color: #b45309;
}
.status-paid {
  background: #dbeafe;
  color: #1d4ed8;
}
.status-shipping {
  background: #fed7aa;
  color: #c2410c;
}
.status-delivered {
  background: #dcfce7;
  color: #15803d;
}

.order-card-body {
  padding: 16px 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.order-item-row {
  display: flex;
  align-items: center;
  gap: 16px;
}
.item-thumb {
  width: 50px;
  height: 50px;
  object-fit: cover;
  border-radius: 4px;
  border: 1px solid #e2e8f0;
}
.item-info {
  flex: 1;
}
.item-opt {
  display: block;
  font-size: 12px;
  color: #64748b;
  margin-top: 2px;
}
.item-price {
  font-weight: 700;
  font-size: 14px;
}

.order-card-footer {
  background-color: #f8fafc;
  padding: 12px 20px;
  border-top: 1px solid #edf2f7;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
}
.used-pts {
  color: #ef4444;
}

/* Points & Profile */
.points-card, .profile-edit-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 24px;
}
.profile-edit-card {
  max-width: 540px;
}
.form-row {
  margin-bottom: 16px;
}
.form-row label {
  display: block;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 6px;
}
.text-red {
  color: #ef4444;
}
</style>
