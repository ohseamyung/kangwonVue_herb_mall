<template>
  <div class="auth-view container">
    <div class="auth-box register-box">
      <div class="auth-header">
        <div class="signup-benefit-badge">
          <i class="fa-solid fa-gift"></i> 신규 가입 즉시 <strong>2,000원 적립금</strong> 자동 지급!
        </div>
        <h2>강원약초 회원가입</h2>
        <p>회원가입 후 다양한 할인 혜택과 적립금 혜택을 누려보세요.</p>
      </div>

      <form @submit.prevent="handleRegister" class="auth-form">
        <div class="form-row">
          <label>아이디 <span class="req">*</span></label>
          <input 
            type="text" 
            v-model="form.username" 
            placeholder="영문, 숫자 4자 이상" 
            class="form-input" 
            required 
          />
        </div>

        <div class="form-row">
          <label>비밀번호 <span class="req">*</span></label>
          <input 
            type="password" 
            v-model="form.password" 
            placeholder="4자리 이상 입력" 
            class="form-input" 
            required 
          />
        </div>

        <div class="form-row">
          <label>비밀번호 확인 <span class="req">*</span></label>
          <input 
            type="password" 
            v-model="confirmPassword" 
            placeholder="비밀번호를 한번 더 입력" 
            class="form-input" 
            required 
          />
        </div>

        <div class="form-row">
          <label>성명 <span class="req">*</span></label>
          <input 
            type="text" 
            v-model="form.name" 
            placeholder="실명을 입력하세요" 
            class="form-input" 
            required 
          />
        </div>

        <div class="form-row">
          <label>휴대폰 번호 <span class="req">*</span></label>
          <input 
            type="tel" 
            v-model="form.phone" 
            placeholder="010-0000-0000" 
            class="form-input" 
            required 
          />
        </div>

        <div class="form-row">
          <label>이메일</label>
          <input 
            type="email" 
            v-model="form.email" 
            placeholder="example@email.com" 
            class="form-input" 
          />
        </div>

        <div class="form-row">
          <label>기본 배송 주소</label>
          <input 
            type="text" 
            v-model="form.address" 
            placeholder="주소를 상세히 입력하세요" 
            class="form-input" 
          />
        </div>

        <div class="terms-agree-box">
          <label class="terms-label">
            <input type="checkbox" v-model="agreeTerms" required />
            [필수] 강원약초 이용약관 및 개인정보 수집·이용에 동의합니다.
          </label>
        </div>

        <button type="submit" class="btn btn-primary btn-lg auth-btn" :disabled="authStore.loading">
          <span v-if="authStore.loading"><i class="fa-solid fa-spinner fa-spin"></i> 가입 처리 중...</span>
          <span v-else>가입하고 2,000P 받기</span>
        </button>
      </form>

      <div class="auth-footer-links text-center">
        <span>이미 회원이신가요?</span>
        <router-link to="/login" class="login-link">로그인하러 가기</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'

const router = useRouter()
const authStore = useAuthStore()

const confirmPassword = ref('')
const agreeTerms = ref(true)

const form = ref({
  username: '',
  password: '',
  name: '',
  phone: '',
  email: '',
  address: ''
})

const handleRegister = async () => {
  if (form.value.password !== confirmPassword.value) {
    alert('비밀번호가 일치하지 않습니다.')
    return
  }
  if (!agreeTerms.value) {
    alert('이용약관에 동의해주세요.')
    return
  }

  try {
    const res = await authStore.register(form.value)
    alert(res.message)
    router.push('/')
  } catch (err) {
    alert(err.message)
  }
}
</script>

<style scoped>
.auth-view {
  padding: 40px 16px 100px 16px;
  display: flex;
  justify-content: center;
}
.register-box {
  width: 100%;
  max-width: 500px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 36px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
}
.signup-benefit-badge {
  background-color: #eef7f0;
  border: 1px solid #276735;
  color: #276735;
  font-size: 13px;
  padding: 8px 14px;
  border-radius: 20px;
  display: inline-block;
  margin-bottom: 14px;
}
.auth-header {
  text-align: center;
  margin-bottom: 24px;
}
.auth-header h2 {
  font-size: 24px;
  font-weight: 800;
  color: #1a202c;
  margin-bottom: 4px;
}
.auth-header p {
  font-size: 13px;
  color: #64748b;
}

.form-row {
  margin-bottom: 14px;
}
.form-row label {
  display: block;
  font-size: 13px;
  font-weight: 700;
  color: #334155;
  margin-bottom: 4px;
}
.req {
  color: #ef4444;
}

.terms-agree-box {
  margin: 18px 0;
  padding: 12px;
  background-color: #f8fafc;
  border-radius: 6px;
  font-size: 12px;
  color: #475569;
}
.terms-label {
  display: flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
}

.auth-btn {
  width: 100%;
  margin-top: 10px;
}

.auth-footer-links {
  margin-top: 24px;
  border-top: 1px solid #edf2f7;
  padding-top: 16px;
  font-size: 13px;
  color: #64748b;
  display: flex;
  justify-content: center;
  gap: 8px;
}
.login-link {
  color: #276735;
  font-weight: bold;
}
</style>
