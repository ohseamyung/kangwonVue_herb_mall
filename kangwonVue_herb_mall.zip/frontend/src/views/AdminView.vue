<template>
  <div class="admin-view container">
    <div class="admin-top-bar">
      <h2><i class="fa-solid fa-chart-line text-green"></i> 강원약초 관리자 센터</h2>
      <div class="admin-user-tag">
        <span class="badge badge-hit">ADMIN</span>
        <strong>{{ authStore.userName }}</strong>님
      </div>
    </div>

    <!-- Non-admin Alert -->
    <div v-if="!authStore.isAdmin" class="admin-alert-box">
      <i class="fa-solid fa-triangle-exclamation alert-icon"></i>
      <h3>관리자 권한이 필요합니다</h3>
      <p>관리자 계정(admin / admin1234)으로 로그인해주세요.</p>
      <router-link to="/login" class="btn btn-primary btn-sm">관리자 로그인</router-link>
    </div>

    <div v-else>
      <!-- 1. Stats Cards -->
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon bg-green"><i class="fa-solid fa-won-sign"></i></div>
          <div class="stat-info">
            <span class="stat-name">총 누적 매출</span>
            <strong class="stat-number">{{ (stats.total_sales || 0).toLocaleString() }}원</strong>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon bg-blue"><i class="fa-solid fa-box"></i></div>
          <div class="stat-info">
            <span class="stat-name">총 주문 건수</span>
            <strong class="stat-number">{{ stats.total_orders || 0 }}건</strong>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon bg-orange"><i class="fa-solid fa-clock"></i></div>
          <div class="stat-info">
            <span class="stat-name">입금 대기 건</span>
            <strong class="stat-number text-orange">{{ stats.pending_orders || 0 }}건</strong>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon bg-purple"><i class="fa-solid fa-leaf"></i></div>
          <div class="stat-info">
            <span class="stat-name">등록 상품 수</span>
            <strong class="stat-number">{{ stats.total_products || 0 }}개</strong>
          </div>
        </div>
      </div>

      <!-- Navigation Tabs -->
      <div class="admin-tabs">
        <button :class="{ active: currentTab === 'orders' }" @click="currentTab = 'orders'">
          <i class="fa-solid fa-cart-shopping"></i> 주문/배송 관리
        </button>
        <button :class="{ active: currentTab === 'products' }" @click="currentTab = 'products'">
          <i class="fa-solid fa-boxes-stacked"></i> 상품 등록/관리
        </button>
      </div>

      <!-- Tab 1: Orders Management -->
      <div v-if="currentTab === 'orders'" class="admin-section">
        <div class="section-title-row">
          <h3>전체 주문 목록 ({{ adminOrders.length }}건)</h3>
          <button class="btn btn-outline btn-sm" @click="loadAdminOrders">
            <i class="fa-solid fa-rotate-right"></i> 새로고침
          </button>
        </div>

        <table class="mall-table">
          <thead>
            <tr>
              <th style="width: 140px;">주문일시</th>
              <th style="width: 150px;">주문번호</th>
              <th>주문상품</th>
              <th style="width: 110px;">주문자</th>
              <th style="width: 110px;">결제금액</th>
              <th style="width: 140px;">상태변경</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="ord in adminOrders" :key="ord.id || ord._id">
              <td style="text-align: center;">{{ formatDate(ord.created_at) }}</td>
              <td style="text-align: center;">
                <strong>{{ ord.order_number }}</strong>
              </td>
              <td>
                <div v-for="(item, i) in ord.items" :key="i" class="order-mini-item">
                  {{ item.product_name }} ({{ item.option_name }}) × {{ item.qty }}
                </div>
              </td>
              <td style="text-align: center;">
                {{ ord.buyer_name }}<br />
                <span class="text-xs text-muted">{{ ord.buyer_phone }}</span>
              </td>
              <td style="text-align: center;">
                <strong>{{ (ord.final_total || 0).toLocaleString() }}원</strong><br />
                <span class="text-xs text-muted">{{ ord.payment_method === 'bank_transfer' ? '무통장' : '카드' }}</span>
              </td>
              <td style="text-align: center;">
                <select 
                  :value="ord.status || '입금대기'" 
                  class="status-select"
                  @change="changeOrderStatus(ord.id || ord._id, $event.target.value)"
                >
                  <option value="입금대기">입금대기</option>
                  <option value="결제완료">결제완료</option>
                  <option value="상품준비중">상품준비중</option>
                  <option value="배송중">배송중</option>
                  <option value="배송완료">배송완료</option>
                  <option value="주문취소">주문취소</option>
                </select>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Tab 2: Products Management -->
      <div v-if="currentTab === 'products'" class="admin-section">
        <div class="section-title-row">
          <h3>등록 상품 목록 ({{ adminProducts.length }}개)</h3>
          <button class="btn btn-primary btn-sm" @click="showAddModal = true">
            <i class="fa-solid fa-plus"></i> 새 상품 등록
          </button>
        </div>

        <table class="mall-table">
          <thead>
            <tr>
              <th style="width: 70px;">이미지</th>
              <th>상품명</th>
              <th style="width: 120px;">카테고리</th>
              <th style="width: 100px;">판매가</th>
              <th style="width: 80px;">재고</th>
              <th style="width: 80px;">추천/BEST</th>
              <th style="width: 100px;">관리</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="prod in adminProducts" :key="prod.id || prod._id">
              <td style="text-align: center;">
                <img :src="prod.image || '/static/images/p_mushroom_horse.jpg'" class="prod-admin-thumb" />
              </td>
              <td>
                <strong>{{ prod.name }}</strong>
                <div class="text-xs text-muted">{{ prod.summary }}</div>
              </td>
              <td style="text-align: center;">{{ prod.sub_category || prod.category }}</td>
              <td style="text-align: center;">{{ prod.price.toLocaleString() }}원</td>
              <td style="text-align: center;">{{ prod.stock || 100 }}개</td>
              <td style="text-align: center;">
                <span v-if="prod.is_best" class="badge badge-hit">BEST</span>
                <span v-if="prod.is_md" class="badge badge-origin">MD</span>
              </td>
              <td style="text-align: center;">
                <button class="btn-delete" @click="deleteProduct(prod.id || prod._id)" title="삭제">
                  <i class="fa-solid fa-trash-can"></i>
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- New Product Modal -->
      <div v-if="showAddModal" class="modal-backdrop">
        <div class="modal-card">
          <div class="modal-header">
            <h3>신규 상품 등록</h3>
            <button class="close-btn" @click="showAddModal = false">&times;</button>
          </div>
          <form @submit.prevent="submitAddProduct" class="modal-body">
            <div class="form-row">
              <label>상품명 <span class="req">*</span></label>
              <input type="text" v-model="newProd.name" placeholder="예: (강원약초) 국산 자연산 상황버섯 300g" class="form-input" required />
            </div>
            <div class="form-row-grid">
              <div class="form-row">
                <label>카테고리 <span class="req">*</span></label>
                <select v-model="newProd.category" class="form-input" required>
                  <option value="nature-herbs">건강식품 자연약초</option>
                  <option value="rare-herbs">희귀 자연산약초</option>
                  <option value="liquid-extract">수제 건강 액기스즙</option>
                  <option value="herb-sets">건강식품 약초 셋트</option>
                  <option value="ssanghwa-tea">쌍화차재료</option>
                  <option value="sipjeon-tea">십전대보차 셋트</option>
                  <option value="wild-mushrooms">자연산 버섯</option>
                  <option value="wild-ginseng">산 양 산 삼</option>
                  <option value="magamok">마가목</option>
                </select>
              </div>
              <div class="form-row">
                <label>소분류명</label>
                <input type="text" v-model="newProd.sub_category" placeholder="예: 자연산 버섯" class="form-input" />
              </div>
            </div>
            <div class="form-row-grid">
              <div class="form-row">
                <label>판매가 <span class="req">*</span></label>
                <input type="number" v-model.number="newProd.price" class="form-input" required />
              </div>
              <div class="form-row">
                <label>소비자가 (정가)</label>
                <input type="number" v-model.number="newProd.original_price" class="form-input" />
              </div>
            </div>
            <div class="form-row-grid">
              <div class="form-row">
                <label>원산지</label>
                <input type="text" v-model="newProd.origin" placeholder="국산 (강원도 정선)" class="form-input" />
              </div>
              <div class="form-row">
                <label>재고수량</label>
                <input type="number" v-model.number="newProd.stock" class="form-input" />
              </div>
            </div>
            <div class="form-row">
              <label>상품 요약 설명</label>
              <input type="text" v-model="newProd.summary" placeholder="자연산 고지대 채취 최상품" class="form-input" />
            </div>
            <div class="form-row">
              <label>대표 이미지 경로 / URL</label>
              <input type="text" v-model="newProd.image" placeholder="/static/images/p_mushroom_horse.jpg" class="form-input" />
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-outline" @click="showAddModal = false">취소</button>
              <button type="submit" class="btn btn-primary">등록하기</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useAuthStore } from '../stores/auth'
import api from '../api'

const authStore = useAuthStore()

const currentTab = ref('orders')
const stats = ref({})
const adminOrders = ref([])
const adminProducts = ref([])
const showAddModal = ref(false)

const newProd = ref({
  name: '',
  category: 'nature-herbs',
  sub_category: '건강식품 자연약초',
  price: 30000,
  original_price: 35000,
  origin: '국산 (강원도)',
  stock: 50,
  summary: '',
  image: '/static/images/p_mushroom_horse.jpg'
})

const loadAdminStats = async () => {
  try {
    stats.value = await api.get('/admin/stats')
  } catch (err) {}
}

const loadAdminOrders = async () => {
  try {
    adminOrders.value = await api.get('/admin/orders')
  } catch (err) {}
}

const loadAdminProducts = async () => {
  try {
    adminProducts.value = await api.get('/admin/products')
  } catch (err) {}
}

const changeOrderStatus = async (orderId, newStatus) => {
  try {
    await api.put(`/admin/orders/${orderId}/status`, { status: newStatus })
    alert(`주문 상태가 [${newStatus}] 로 변경되었습니다.`)
    loadAdminOrders()
    loadAdminStats()
  } catch (err) {
    alert(err.message)
  }
}

const deleteProduct = async (id) => {
  if (confirm('정말 이 상품을 삭제하시겠습니까?')) {
    try {
      await api.delete(`/admin/products/${id}`)
      alert('상품이 삭제되었습니다.')
      loadAdminProducts()
    } catch (err) {
      alert(err.message)
    }
  }
}

const submitAddProduct = async () => {
  try {
    await api.post('/admin/products', newProd.value)
    alert('새 상품이 등록되었습니다!')
    showAddModal.value = false
    loadAdminProducts()
    loadAdminStats()
  } catch (err) {
    alert(err.message)
  }
}

const formatDate = (isoStr) => {
  if (!isoStr) return ''
  return typeof isoStr === 'string' ? isoStr.replace('T', ' ').substring(0, 16) : ''
}

onMounted(() => {
  if (authStore.isAdmin) {
    loadAdminStats()
    loadAdminOrders()
    loadAdminProducts()
  }
})
</script>

<style scoped>
.admin-view {
  padding: 30px 16px 80px 16px;
}
.admin-top-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 2px solid #276735;
  padding-bottom: 14px;
  margin-bottom: 24px;
}
.admin-top-bar h2 {
  font-size: 24px;
  font-weight: 800;
  color: #1a202c;
  display: flex;
  align-items: center;
  gap: 10px;
}
.text-green { color: #276735; }

.admin-alert-box {
  text-align: center;
  padding: 80px 20px;
  background: #f8fafc;
  border-radius: 8px;
}
.alert-icon {
  font-size: 48px;
  color: #f59e0b;
  margin-bottom: 12px;
}

/* Stats */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 30px;
}
.stat-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.04);
}
.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-size: 20px;
}
.bg-green { background: #276735; }
.bg-blue { background: #2563eb; }
.bg-orange { background: #ea580c; }
.bg-purple { background: #7c3aed; }

.stat-name {
  display: block;
  font-size: 12px;
  color: #64748b;
  margin-bottom: 4px;
}
.stat-number {
  font-size: 20px;
  font-weight: 800;
  color: #1e293b;
}
.text-orange { color: #ea580c; }

/* Tabs */
.admin-tabs {
  display: flex;
  border-bottom: 2px solid #276735;
  margin-bottom: 24px;
}
.admin-tabs button {
  padding: 14px 24px;
  font-size: 15px;
  font-weight: 700;
  color: #64748b;
  border: 1px solid #e2e8f0;
  border-bottom: none;
  background: #f8fafc;
  display: flex;
  align-items: center;
  gap: 8px;
}
.admin-tabs button.active {
  background: #276735;
  color: #ffffff;
  border-color: #276735;
}

.admin-section {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 24px;
}
.section-title-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.section-title-row h3 {
  font-size: 16px;
  font-weight: 700;
}

.status-select {
  padding: 4px 8px;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  font-size: 12px;
  font-weight: bold;
}
.order-mini-item {
  font-size: 12px;
  color: #334155;
  margin-bottom: 2px;
}
.prod-admin-thumb {
  width: 44px;
  height: 44px;
  object-fit: cover;
  border-radius: 4px;
}
.text-xs { font-size: 11px; }
.text-muted { color: #64748b; }
.btn-delete { color: #94a3b8; font-size: 14px; }
.btn-delete:hover { color: #ef4444; }

/* Modal */
.modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 200;
}
.modal-card {
  width: 100%;
  max-width: 540px;
  background: #ffffff;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}
.modal-header {
  padding: 16px 20px;
  background: #f8fafc;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.close-btn { font-size: 22px; color: #64748b; }
.modal-body { padding: 20px; }
.form-row { margin-bottom: 14px; }
.form-row label { display: block; font-size: 12px; font-weight: bold; margin-bottom: 4px; }
.form-row-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.req { color: #ef4444; }
.modal-footer { display: flex; justify-content: flex-end; gap: 8px; margin-top: 20px; }

@media (max-width: 900px) {
  .stats-grid { grid-template-columns: repeat(2, 1fr); }
}
</style>
