<template>
  <div class="auth-view container">
    <div class="auth-box">
      <div class="auth-header">
        <h2>로그인</h2>
        <p>강원도 자연산 토종약초 공식몰에 오신 것을 환영합니다.</p>
      </div>

      <form @submit.prevent="handleLogin" class="auth-form">
        <div class="form-row">
          <label>아이디</label>
          <input 
            type="text" 
            v-model="username" 
            placeholder="아이디를 입력하세요" 
            class="form-input" 
            required 
          />
        </div>
        <div class="form-row">
          <label>비밀번호</label>
          <input 
            type="password" 
            v-model="password" 
            placeholder="비밀번호를 입력하세요" 
            class="form-input" 
            required 
          />
        </div>

        <button type="submit" class="btn btn-primary btn-lg auth-btn" :disabled="authStore.loading">
          <span v-if="authStore.loading"><i class="fa-solid fa-spinner fa-spin"></i> 로그인 중...</span>
          <span v-else>로그인</span>
        </button>
      </form>

      <!-- Quick Demo Login -->
      <div class="demo-login-box">
        <span class="demo-title">테스트 간편 로그인</span>
        <div class="demo-buttons">
          <button type="button" class="btn btn-outline btn-sm" @click="quickLogin('admin', 'admin1234')">
            <i class="fa-solid fa-user-shield"></i> 관리자(admin)
          </button>
          <button type="button" class="btn btn-outline btn-sm" @click="quickLogin('testuser', '1234')">
            <i class="fa-solid fa-user"></i> 일반회원(testuser)
          </button>
        </div>
      </div>

      <!-- Join Promotion Banner -->
      <div class="auth-footer-links">
        <div class="join-promo">
          <span>아직 강원약초 회원이 아니신가요?</span>
          <router-link to="/register" class="btn btn-accent btn-sm">
            회원가입하고 2,000P 받기 <i class="fa-solid fa-chevron-right"></i>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'

const username = ref('')
const password = ref('')
const router = useRouter()
const authStore = useAuthStore()

const handleLogin = async () => {
  try {
    const res = await authStore.login(username.value.trim(), password.value.trim())
    alert(res.message)
    router.push('/')
  } catch (err) {
    alert(err.message)
  }
}

const quickLogin = async (u, p) => {
  username.value = u
  password.value = p
  await handleLogin()
}
</script>

<style scoped>
.auth-view {
  padding: 60px 16px 100px 16px;
  display: flex;
  justify-content: center;
}
.auth-box {
  width: 100%;
  max-width: 440px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 36px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
}
.auth-header {
  text-align: center;
  margin-bottom: 28px;
}
.auth-header h2 {
  font-size: 24px;
  font-weight: 800;
  color: #1a202c;
  margin-bottom: 6px;
}
.auth-header p {
  font-size: 13px;
  color: #64748b;
}

.auth-form .form-row {
  margin-bottom: 18px;
}
.auth-form label {
  display: block;
  font-size: 13px;
  font-weight: 700;
  color: #334155;
  margin-bottom: 6px;
}
.auth-btn {
  width: 100%;
  margin-top: 10px;
  font-size: 16px;
}

.demo-login-box {
  margin-top: 24px;
  padding: 16px;
  background-color: #f8fafc;
  border-radius: 8px;
  text-align: center;
}
.demo-title {
  display: block;
  font-size: 12px;
  color: #64748b;
  font-weight: bold;
  margin-bottom: 10px;
}
.demo-buttons {
  display: flex;
  gap: 8px;
  justify-content: center;
}

.auth-footer-links {
  margin-top: 24px;
  border-top: 1px solid #edf2f7;
  padding-top: 20px;
}
.join-promo {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  font-size: 13px;
  color: #475569;
}
</style>
