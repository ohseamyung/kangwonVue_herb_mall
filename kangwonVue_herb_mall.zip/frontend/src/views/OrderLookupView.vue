<template>
  <div class="lookup-view container">
    <h2 class="page-title">주문 / 배송 조회</h2>

    <div class="lookup-card">
      <p class="lookup-desc">
        비회원 주문 또는 회원 주문번호와 주문 시 등록한 연락처를 입력하시면 실시간 배송 상태를 조회하실 수 있습니다.
      </p>

      <form @submit.prevent="handleLookup" class="lookup-form">
        <div class="form-row">
          <label>주문번호</label>
          <input 
            type="text" 
            v-model="orderNumber" 
            placeholder="예: KW20260905-12345" 
            class="form-input" 
            required 
          />
        </div>
        <div class="form-row">
          <label>주문자 연락처</label>
          <input 
            type="tel" 
            v-model="phone" 
            placeholder="010-0000-0000" 
            class="form-input" 
            required 
          />
        </div>
        <button type="submit" class="btn btn-primary btn-lg submit-btn" :disabled="loading">
          <span v-if="loading"><i class="fa-solid fa-spinner fa-spin"></i> 조회 중...</span>
          <span v-else><i class="fa-solid fa-magnifying-glass"></i> 주문 조회하기</span>
        </button>
      </form>
    </div>

    <!-- Lookup Result -->
    <div v-if="orderResult" class="result-card">
      <div class="result-header">
        <div>
          <h3>주문번호: <strong>{{ orderResult.order_number }}</strong></h3>
          <span class="result-date">주문일시: {{ formatDate(orderResult.created_at) }}</span>
        </div>
        <span class="status-pill" :class="getStatusClass(orderResult.status)">
          {{ orderResult.status }}
        </span>
      </div>

      <!-- Items List -->
      <table class="mall-table mt-4">
        <thead>
          <tr>
            <th>상품명</th>
            <th style="width: 100px;">수량</th>
            <th style="width: 120px;">결제금액</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(it, idx) in orderResult.items" :key="idx">
            <td>
              <strong>{{ it.product_name }}</strong>
              <div class="text-xs text-muted">옵션: {{ it.option_name }}</div>
            </td>
            <td style="text-align: center;">{{ it.qty }}개</td>
            <td style="text-align: center;">{{ ((it.price || 0) * (it.qty || 1)).toLocaleString() }}원</td>
          </tr>
        </tbody>
      </table>

      <!-- Shipping & Bank info -->
      <div class="result-meta-grid">
        <div class="meta-box">
          <h4>배송지 정보</h4>
          <p><strong>받는분:</strong> {{ orderResult.recipient_name }}</p>
          <p><strong>연락처:</strong> {{ orderResult.recipient_phone }}</p>
          <p><strong>배송지:</strong> {{ orderResult.shipping_address }}</p>
        </div>
        <div class="meta-box">
          <h4>결제 정보</h4>
          <p><strong>결제방식:</strong> {{ orderResult.payment_method === 'bank_transfer' ? '무통장입금' : '카드/간편결제' }}</p>
          <p><strong>최종 결제금액:</strong> <span class="text-red font-bold">{{ orderResult.final_total?.toLocaleString() }}원</span></p>
          <div v-if="orderResult.payment_method === 'bank_transfer'" class="bank-tip">
            입금계좌: 농협은행 302-0851-0319-21 (예금주: 강영자)
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import api from '../api'

const orderNumber = ref('')
const phone = ref('')
const loading = ref(false)
const orderResult = ref(null)

const handleLookup = async () => {
  loading.value = true
  orderResult.value = null
  try {
    const res = await api.post('/orders/lookup', {
      order_number: orderNumber.value.trim(),
      phone: phone.value.trim()
    })
    orderResult.value = res
  } catch (err) {
    alert(err.message)
  } finally {
    loading.value = false
  }
}

const formatDate = (isoStr) => {
  if (!isoStr) return ''
  return typeof isoStr === 'string' ? isoStr.replace('T', ' ').substring(0, 16) : ''
}

const getStatusClass = (status) => {
  if (status === '결제완료') return 'status-paid'
  if (status === '배송중' || status === '상품준비중') return 'status-shipping'
  if (status === '배송완료') return 'status-delivered'
  return 'status-pending'
}
</script>

<style scoped>
.lookup-view {
  padding: 30px 16px 80px 16px;
  max-width: 800px;
}
.page-title {
  font-size: 24px;
  font-weight: 800;
  color: #1a202c;
  margin-bottom: 24px;
  border-bottom: 2px solid #276735;
  padding-bottom: 12px;
}
.lookup-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 30px;
  margin-bottom: 30px;
}
.lookup-desc {
  font-size: 14px;
  color: #64748b;
  margin-bottom: 20px;
  line-height: 1.6;
}
.form-row {
  margin-bottom: 16px;
}
.form-row label {
  display: block;
  font-size: 13px;
  font-weight: 700;
  color: #334155;
  margin-bottom: 6px;
}
.submit-btn {
  width: 100%;
  margin-top: 8px;
}

/* Result Card */
.result-card {
  background: #ffffff;
  border: 2px solid #276735;
  border-radius: 8px;
  padding: 24px;
}
.result-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #edf2f7;
  padding-bottom: 14px;
}
.result-header h3 strong {
  color: #c04928;
}
.result-date {
  font-size: 12px;
  color: #64748b;
}

.status-pill {
  font-size: 13px;
  font-weight: 700;
  padding: 4px 12px;
  border-radius: 20px;
}
.status-pending { background: #fef3c7; color: #b45309; }
.status-paid { background: #dbeafe; color: #1d4ed8; }
.status-shipping { background: #fed7aa; color: #c2410c; }
.status-delivered { background: #dcfce7; color: #15803d; }

.mt-4 { margin-top: 16px; }
.text-xs { font-size: 11px; }
.text-muted { color: #64748b; }
.text-red { color: #ef4444; }
.font-bold { font-weight: bold; }

.result-meta-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-top: 24px;
}
.meta-box {
  background: #f8fafc;
  padding: 16px;
  border-radius: 6px;
  font-size: 13px;
  line-height: 1.6;
}
.meta-box h4 {
  font-size: 14px;
  font-weight: 700;
  margin-bottom: 8px;
  color: #1e293b;
}
.bank-tip {
  margin-top: 8px;
  padding: 8px;
  background: #eef7f0;
  border-radius: 4px;
  font-size: 12px;
  color: #276735;
}

@media (max-width: 600px) {
  .result-meta-grid {
    grid-template-columns: 1fr;
  }
}
</style>
