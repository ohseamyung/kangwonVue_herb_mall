<template>
  <div class="product-list-view container">
    <!-- Breadcrumb -->
    <div class="breadcrumb">
      <router-link to="/"><i class="fa-solid fa-house"></i> 홈</router-link>
      <i class="fa-solid fa-angle-right sep"></i>
      <span class="current">{{ currentCategoryTitle }}</span>
    </div>

    <!-- Category Banner Header -->
    <div class="category-header">
      <h2 class="cat-title">{{ currentCategoryTitle }}</h2>
      <p v-if="currentCategoryDesc" class="cat-desc">{{ currentCategoryDesc }}</p>
    </div>

    <!-- Filter & Sort Bar -->
    <div class="list-control-bar">
      <div class="total-count">
        전체 등록 상품 <strong>{{ totalCount }}</strong>개
      </div>
      <div class="sort-options">
        <button 
          :class="{ active: currentSort === 'default' }" 
          @click="changeSort('default')"
        >추천순</button>
        <button 
          :class="{ active: currentSort === 'sales' }" 
          @click="changeSort('sales')"
        >인기순</button>
        <button 
          :class="{ active: currentSort === 'new' }" 
          @click="changeSort('new')"
        >신상품순</button>
        <button 
          :class="{ active: currentSort === 'price_asc' }" 
          @click="changeSort('price_asc')"
        >낮은가격순</button>
        <button 
          :class="{ active: currentSort === 'price_desc' }" 
          @click="changeSort('price_desc')"
        >높은가격순</button>
        <button 
          :class="{ active: currentSort === 'rating' }" 
          @click="changeSort('rating')"
        >고객평점순</button>
      </div>
    </div>

    <!-- Product Grid or Empty State -->
    <div v-if="loading" class="loading-state">
      <i class="fa-solid fa-spinner fa-spin"></i> 상품을 불러오는 중입니다...
    </div>
    <div v-else-if="products.length === 0" class="empty-state">
      <i class="fa-solid fa-box-open empty-icon"></i>
      <p>조건에 맞는 상품이 존재하지 않습니다.</p>
      <router-link to="/" class="btn btn-primary btn-sm">메인으로 가기</router-link>
    </div>
    <div v-else class="product-grid">
      <ProductCard 
        v-for="prod in products" 
        :key="prod.id || prod._id" 
        :product="prod" 
      />
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import ProductCard from '../components/ProductCard.vue'
import api from '../api'

const route = useRoute()

const products = ref([])
const totalCount = ref(0)
const loading = ref(false)
const currentSort = ref('default')
const categories = ref([])

const slug = computed(() => route.params.slug || '')
const searchKeyword = computed(() => route.query.search || '')

const currentCategory = computed(() => {
  return categories.value.find(c => c.slug === slug.value)
})

const currentCategoryTitle = computed(() => {
  if (searchKeyword.value) {
    return `'${searchKeyword.value}' 검색 결과`
  }
  if (slug.value === 'best-items') {
    return 'BEST 인기상품'
  }
  return currentCategory.value?.name || '전체 상품'
})

const currentCategoryDesc = computed(() => {
  if (searchKeyword.value) return '검색된 상품 목록입니다.'
  return currentCategory.value?.desc || '강원도 청정 자연에서 채취한 100% 토종 자연산 약초'
})

const loadProducts = async () => {
  loading.value = true
  try {
    let url = `/products?sort=${currentSort.value}`
    if (slug.value && slug.value !== 'all') {
      url += `&category=${slug.value}`
    }
    if (searchKeyword.value) {
      url += `&search=${encodeURIComponent(searchKeyword.value)}`
    }
    const res = await api.get(url)
    products.value = res.products || []
    totalCount.value = res.total || 0
  } catch (err) {
    console.error('Failed to load products', err)
  } finally {
    loading.value = false
  }
}

const changeSort = (sort) => {
  currentSort.value = sort
  loadProducts()
}

watch([slug, searchKeyword], () => {
  loadProducts()
})

onMounted(async () => {
  try {
    categories.value = await api.get('/categories')
  } catch (err) {}
  loadProducts()
})
</script>

<style scoped>
.product-list-view {
  padding: 24px 16px 60px 16px;
}
.breadcrumb {
  font-size: 12px;
  color: #64748b;
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 20px;
}
.sep {
  font-size: 10px;
  color: #cbd5e1;
}
.current {
  color: #1e293b;
  font-weight: 600;
}

.category-header {
  border-bottom: 2px solid #1a4d25;
  padding-bottom: 16px;
  margin-bottom: 20px;
}
.cat-title {
  font-size: 26px;
  font-weight: 800;
  color: #1a4d25;
}
.cat-desc {
  font-size: 13px;
  color: #64748b;
  margin-top: 4px;
}

.list-control-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background-color: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  margin-bottom: 24px;
  font-size: 13px;
}
.total-count strong {
  color: #c04928;
}
.sort-options {
  display: flex;
  gap: 12px;
}
.sort-options button {
  font-size: 12px;
  color: #64748b;
  background: none;
  padding: 2px 4px;
}
.sort-options button:hover,
.sort-options button.active {
  color: #276735;
  font-weight: 700;
  border-bottom: 2px solid #276735;
}

.loading-state,
.empty-state {
  text-align: center;
  padding: 80px 20px;
  color: #64748b;
}
.empty-icon {
  font-size: 48px;
  color: #cbd5e1;
  margin-bottom: 12px;
  display: block;
}
.empty-state p {
  font-size: 15px;
  margin-bottom: 16px;
}
</style>
