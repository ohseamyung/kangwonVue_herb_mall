<template>
  <div class="board-view container">
    <h2 class="page-title">고객센터 / 커뮤니티</h2>

    <!-- Board Tabs -->
    <div class="board-tabs">
      <router-link to="/board/notice" :class="{ active: currentBoard === 'notice' }">
        <i class="fa-solid fa-bullhorn"></i> 공지사항
      </router-link>
      <router-link to="/board/review" :class="{ active: currentBoard === 'review' }">
        <i class="fa-solid fa-star"></i> 구매후기
      </router-link>
      <router-link to="/board/qna" :class="{ active: currentBoard === 'qna' }">
        <i class="fa-solid fa-circle-question"></i> 상품문의
      </router-link>
      <router-link to="/board/faq" :class="{ active: currentBoard === 'faq' }">
        <i class="fa-solid fa-circle-info"></i> 자주묻는질문 (FAQ)
      </router-link>
    </div>

    <!-- 1. Notice Board -->
    <div v-if="currentBoard === 'notice'" class="board-panel">
      <!-- Notice Detail Modal -->
      <div v-if="selectedNotice" class="notice-detail-card">
        <div class="detail-header">
          <span class="badge badge-hit">공지</span>
          <h3>{{ selectedNotice.title }}</h3>
          <span class="detail-date">{{ formatDate(selectedNotice.created_at) }} | 조회수: {{ selectedNotice.views || 1 }}</span>
        </div>
        <div class="detail-body" v-html="selectedNotice.content"></div>
        <div class="detail-actions">
          <button class="btn btn-outline btn-sm" @click="selectedNotice = null">목록으로 돌아가기</button>
        </div>
      </div>

      <!-- Notice List Table -->
      <table v-else class="mall-table">
        <thead>
          <tr>
            <th style="width: 70px;">번호</th>
            <th>제목</th>
            <th style="width: 100px;">작성자</th>
            <th style="width: 120px;">작성일</th>
            <th style="width: 80px;">조회수</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(n, idx) in notices" :key="n.id || n._id" class="clickable-row" @click="openNotice(n)">
            <td style="text-align: center;">{{ notices.length - idx }}</td>
            <td>
              <span class="badge badge-hit mr-2">공지</span>
              <strong>{{ n.title }}</strong>
            </td>
            <td style="text-align: center;">강원약초</td>
            <td style="text-align: center;">{{ formatDate(n.created_at) }}</td>
            <td style="text-align: center;">{{ n.views || 1 }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- 2. Reviews Board -->
    <div v-if="currentBoard === 'review'" class="board-panel">
      <div class="panel-desc">
        강원약초를 직접 드셔보신 고객님들의 진솔하고 생생한 구매후기입니다.
      </div>
      <div class="reviews-grid">
        <div v-for="rev in allReviews" :key="rev.id || rev._id" class="review-board-card">
          <div class="rev-card-header">
            <span class="stars">{{ '★'.repeat(rev.rating) }}{{ '☆'.repeat(5 - rev.rating) }}</span>
            <span class="prod-badge">{{ rev.product_name }}</span>
          </div>
          <h4 class="rev-title">{{ rev.title }}</h4>
          <p class="rev-content">{{ rev.content }}</p>
          <div class="rev-footer">
            <span>{{ rev.author }}</span>
            <span>{{ formatDate(rev.created_at) }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 3. Q&A Board -->
    <div v-if="currentBoard === 'qna'" class="board-panel">
      <div class="panel-desc">
        약초의 효능, 복용법, 배송 등에 관하여 고객님께서 문의하신 내용과 강원약초의 정성스러운 답변입니다.
      </div>
      <div class="qna-list-board">
        <div v-for="q in allQnas" :key="q.id || q._id" class="qna-card">
          <div class="q-header">
            <span class="status-badge" :class="q.status === '답변완료' ? 'done' : 'wait'">{{ q.status || '답변대기' }}</span>
            <strong>{{ q.title }}</strong>
            <span class="q-target">[{{ q.product_name }}]</span>
            <span class="q-date">{{ formatDate(q.created_at) }}</span>
          </div>
          <p class="q-text">{{ q.content }}</p>
          <div v-if="q.answer" class="a-box">
            <strong class="a-title"><i class="fa-solid fa-reply"></i> [강원약초 답변]</strong>
            <p>{{ q.answer }}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- 4. FAQ Board -->
    <div v-if="currentBoard === 'faq'" class="board-panel">
      <div class="faq-list">
        <div 
          v-for="faq in faqs" 
          :key="faq.id" 
          class="faq-card"
          :class="{ open: openFaqId === faq.id }"
        >
          <div class="faq-question" @click="toggleFaq(faq.id)">
            <span class="q-mark">Q</span>
            <span class="cat-tag">{{ faq.category }}</span>
            <span class="q-text">{{ faq.question }}</span>
            <i class="fa-solid" :class="openFaqId === faq.id ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
          </div>
          <div v-if="openFaqId === faq.id" class="faq-answer">
            <span class="a-mark">A</span>
            <p>{{ faq.answer }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import api from '../api'

const route = useRoute()
const currentBoard = computed(() => route.params.boardType || 'notice')

const notices = ref([])
const selectedNotice = ref(null)
const allReviews = ref([])
const allQnas = ref([])
const faqs = ref([])
const openFaqId = ref(1)

const loadBoardData = async () => {
  try {
    if (currentBoard.value === 'notice') {
      notices.value = await api.get('/board/notices')
    } else if (currentBoard.value === 'review') {
      allReviews.value = await api.get('/board/reviews')
    } else if (currentBoard.value === 'qna') {
      allQnas.value = await api.get('/board/qna')
    } else if (currentBoard.value === 'faq') {
      faqs.value = await api.get('/board/faq')
    }
  } catch (err) {
    console.error('Failed to load board data', err)
  }
}

const openNotice = async (n) => {
  try {
    const detail = await api.get(`/board/notices/${n.id || n._id}`)
    selectedNotice.value = detail
  } catch (err) {
    selectedNotice.value = n
  }
}

const toggleFaq = (id) => {
  openFaqId.value = openFaqId.value === id ? null : id
}

const formatDate = (isoStr) => {
  if (!isoStr) return ''
  return typeof isoStr === 'string' ? isoStr.substring(0, 10) : ''
}

watch(currentBoard, () => {
  selectedNotice.value = null
  loadBoardData()
})

onMounted(() => {
  loadBoardData()
})
</script>

<style scoped>
.board-view {
  padding: 30px 16px 80px 16px;
}
.page-title {
  font-size: 24px;
  font-weight: 800;
  color: #1a202c;
  margin-bottom: 24px;
  border-bottom: 2px solid #276735;
  padding-bottom: 12px;
}

.board-tabs {
  display: flex;
  border-bottom: 2px solid #276735;
  margin-bottom: 30px;
}
.board-tabs a {
  padding: 14px 24px;
  font-size: 15px;
  font-weight: 700;
  color: #64748b;
  border: 1px solid #e2e8f0;
  border-bottom: none;
  background: #f8fafc;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  gap: 8px;
}
.board-tabs a.active {
  background: #276735;
  color: #ffffff;
  border-color: #276735;
}

.board-panel {
  background: #ffffff;
}
.panel-desc {
  font-size: 14px;
  color: #64748b;
  margin-bottom: 20px;
  padding: 12px 16px;
  background-color: #f8fafc;
  border-left: 4px solid #276735;
}

/* Notice Detail */
.notice-detail-card {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 24px;
}
.detail-header {
  border-bottom: 1px solid #edf2f7;
  padding-bottom: 16px;
  margin-bottom: 20px;
}
.detail-header h3 {
  font-size: 20px;
  font-weight: 800;
  margin: 8px 0;
}
.detail-date {
  font-size: 12px;
  color: #94a3b8;
}
.detail-body {
  line-height: 1.8;
  font-size: 14px;
  color: #334155;
  margin-bottom: 24px;
}
.clickable-row {
  cursor: pointer;
}
.clickable-row:hover {
  background-color: #f1f5f9;
}
.mr-2 { margin-right: 8px; }

/* Reviews Grid */
.reviews-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
}
.review-board-card {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 20px;
  background: #ffffff;
  display: flex;
  flex-direction: column;
}
.rev-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}
.stars { color: #f59e0b; }
.prod-badge {
  font-size: 11px;
  color: #276735;
  background: #eef7f0;
  padding: 2px 8px;
  border-radius: 4px;
  font-weight: 600;
}
.rev-title {
  font-size: 15px;
  font-weight: 700;
  margin-bottom: 6px;
}
.rev-content {
  font-size: 13px;
  color: #475569;
  line-height: 1.5;
  flex: 1;
}
.rev-footer {
  display: flex;
  justify-content: space-between;
  font-size: 11px;
  color: #94a3b8;
  margin-top: 14px;
  border-top: 1px solid #edf2f7;
  padding-top: 8px;
}

/* Q&A List */
.qna-list-board {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.qna-card {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 16px 20px;
}
.q-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 8px;
}
.status-badge {
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 4px;
  font-weight: bold;
}
.status-badge.wait { background: #e2e8f0; color: #475569; }
.status-badge.done { background: #276735; color: #ffffff; }
.q-target { font-size: 12px; color: #276735; font-weight: 600; }
.q-date { font-size: 11px; color: #94a3b8; margin-left: auto; }
.q-text { font-size: 13px; color: #334155; }
.a-box {
  margin-top: 12px;
  padding: 12px 16px;
  background: #eef7f0;
  border-left: 4px solid #276735;
  border-radius: 4px;
}
.a-title { font-size: 12px; color: #276735; display: block; margin-bottom: 4px; }

/* FAQ */
.faq-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.faq-card {
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  overflow: hidden;
}
.faq-question {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px 20px;
  background: #f8fafc;
  cursor: pointer;
  font-size: 14px;
  font-weight: 700;
  color: #1e293b;
}
.q-mark {
  width: 24px;
  height: 24px;
  background: #276735;
  color: #ffffff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: bold;
}
.cat-tag {
  background: #e2e8f0;
  color: #475569;
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 4px;
}
.faq-question .q-text { flex: 1; }
.faq-answer {
  padding: 20px;
  background: #ffffff;
  display: flex;
  gap: 12px;
  border-top: 1px solid #e2e8f0;
  font-size: 13px;
  color: #334155;
  line-height: 1.7;
}
.a-mark {
  width: 24px;
  height: 24px;
  background: #c04928;
  color: #ffffff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: bold;
  flex-shrink: 0;
}

@media (max-width: 768px) {
  .reviews-grid {
    grid-template-columns: 1fr;
  }
}
</style>
