<template>
  <div class="checkout-view container">
    <!-- Steps -->
    <div class="order-steps">
      <div class="step">01 장바구니</div>
      <div class="step-arrow"><i class="fa-solid fa-angle-right"></i></div>
      <div class="step active">02 주문/결제</div>
      <div class="step-arrow"><i class="fa-solid fa-angle-right"></i></div>
      <div class="step">03 주문완료</div>
    </div>

    <h2 class="page-title">주문서 작성 / 결제</h2>

    <!-- Order Items Summary Table -->
    <div class="checkout-section">
      <h3 class="section-sub-title">1. 주문 상품 확인</h3>
      <table class="mall-table">
        <thead>
          <tr>
            <th>상품정보</th>
            <th style="width: 100px;">수량</th>
            <th style="width: 120px;">상품금액</th>
            <th style="width: 120px;">배송구분</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in cartStore.items" :key="item.key">
            <td>
              <div class="item-desc-cell">
                <img :src="item.image || '/static/images/p_mushroom_horse.jpg'" class="item-mini-thumb" />
                <div>
                  <strong>{{ item.name }}</strong>
                  <div class="item-opt">옵션: {{ item.option_name }}</div>
                </div>
              </div>
            </td>
            <td style="text-align: center;">{{ item.qty }}개</td>
            <td style="text-align: center;">
              <strong>{{ ((item.price || 0) * (item.qty || 1)).toLocaleString() }}</strong>원
            </td>
            <td style="text-align: center;">산지직송 택배</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Form Grid: Buyer / Shipping / Payment -->
    <form @submit.prevent="submitOrder">
      <div class="checkout-grid">
        <!-- Left: Form Inputs -->
        <div class="form-inputs-col">
          <!-- Buyer Info -->
          <div class="checkout-card">
            <h3 class="card-title"><i class="fa-solid fa-user text-green"></i> 주문자 정보</h3>
            <div class="card-body">
              <div class="form-row">
                <label>주문자명 <span class="req">*</span></label>
                <input type="text" v-model="form.buyer_name" class="form-input" required />
              </div>
              <div class="form-row">
                <label>연락처 <span class="req">*</span></label>
                <input type="tel" v-model="form.buyer_phone" placeholder="010-0000-0000" class="form-input" required />
              </div>
              <div class="form-row">
                <label>이메일</label>
                <input type="email" v-model="form.buyer_email" placeholder="example@email.com" class="form-input" />
              </div>
            </div>
          </div>

          <!-- Shipping Info -->
          <div class="checkout-card">
            <div class="card-title-row">
              <h3 class="card-title"><i class="fa-solid fa-truck-fast text-green"></i> 배송지 정보</h3>
              <label class="copy-buyer-label">
                <input type="checkbox" @change="copyBuyerInfo" /> 주문자 정보와 동일
              </label>
            </div>
            <div class="card-body">
              <div class="form-row">
                <label>받는 분 <span class="req">*</span></label>
                <input type="text" v-model="form.recipient_name" class="form-input" required />
              </div>
              <div class="form-row">
                <label>연락처 <span class="req">*</span></label>
                <input type="tel" v-model="form.recipient_phone" placeholder="010-0000-0000" class="form-input" required />
              </div>
              <div class="form-row">
                <label>우편번호</label>
                <input type="text" v-model="form.recipient_postcode" placeholder="12345" class="form-input postcode" />
              </div>
              <div class="form-row">
                <label>배송지 주소 <span class="req">*</span></label>
                <input type="text" v-model="form.shipping_address" placeholder="도로명 또는 지번 주소 상세히 입력" class="form-input" required />
              </div>
              <div class="form-row">
                <label>배송 메모</label>
                <input type="text" v-model="form.shipping_memo" placeholder="예: 부재 시 문 앞에 놓아주세요" class="form-input" />
              </div>
            </div>
          </div>

          <!-- Points Usage -->
          <div v-if="authStore.isLoggedIn" class="checkout-card">
            <h3 class="card-title"><i class="fa-solid fa-coins text-gold"></i> 적립금 사용</h3>
            <div class="card-body">
              <div class="point-usage-row">
                <span>보유 적립금: <strong>{{ (authStore.userPoints || 0).toLocaleString() }}P</strong></span>
                <div class="point-input-wrap">
                  <input 
                    type="number" 
                    v-model.number="form.used_points" 
                    min="0" 
                    :max="authStore.userPoints"
                    class="form-input point-input"
                  />
                  <button type="button" class="btn btn-outline btn-sm" @click="useAllPoints">전액사용</button>
                </div>
              </div>
            </div>
          </div>

          <!-- Payment Method Selection -->
          <div class="checkout-card">
            <h3 class="card-title"><i class="fa-solid fa-credit-card text-green"></i> 결제 수단 선택</h3>
            <div class="card-body">
              <div class="pay-methods-grid">
                <label class="pay-method-pill" :class="{ selected: form.payment_method === 'bank_transfer' }">
                  <input type="radio" v-model="form.payment_method" value="bank_transfer" />
                  <span>무통장 입금</span>
                </label>
                <label class="pay-method-pill" :class="{ selected: form.payment_method === 'card' }">
                  <input type="radio" v-model="form.payment_method" value="card" />
                  <span>신용카드 결제</span>
                </label>
                <label class="pay-method-pill" :class="{ selected: form.payment_method === 'simple_pay' }">
                  <input type="radio" v-model="form.payment_method" value="simple_pay" />
                  <span>간편결제 (카카오/네이버)</span>
                </label>
              </div>

              <!-- Bank transfer specific info -->
              <div v-if="form.payment_method === 'bank_transfer'" class="bank-details-box">
                <p><strong>입금은행:</strong> 농협은행 302-0851-0319-21 (예금주: 강영자(강원약초))</p>
                <div class="form-row mt-2">
                  <label>입금자명</label>
                  <input type="text" v-model="form.depositor_name" class="form-input" placeholder="실제 입금하실 분 성명" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Right: Order Summary Sidebar -->
        <div class="summary-sidebar-col">
          <div class="summary-card sticky-sidebar">
            <h3 class="sidebar-title">최종 결제 금액</h3>
            <div class="sidebar-rows">
              <div class="s-row">
                <span>총 상품금액</span>
                <span>{{ cartStore.itemTotal.toLocaleString() }}원</span>
              </div>
              <div class="s-row">
                <span>배송비</span>
                <span>{{ cartStore.shippingFee === 0 ? '0원 (무료)' : `${cartStore.shippingFee.toLocaleString()}원` }}</span>
              </div>
              <div v-if="form.used_points > 0" class="s-row point-minus">
                <span>적립금 사용</span>
                <span>-{{ form.used_points.toLocaleString() }}원</span>
              </div>
              <div class="s-row total-highlight">
                <span>최종 결제 금액</span>
                <span class="total-big">{{ finalPayAmount.toLocaleString() }}원</span>
              </div>
            </div>

            <div class="points-reward-box">
              <i class="fa-solid fa-gift text-green"></i> 구매 시 <strong>{{ expectedEarnedPoints.toLocaleString() }}P</strong> (1%) 적립 예정
            </div>

            <button type="submit" class="btn btn-primary btn-lg pay-submit-btn" :disabled="submitting">
              <span v-if="submitting"><i class="fa-solid fa-spinner fa-spin"></i> 주문 처리 중...</span>
              <span v-else>{{ finalPayAmount.toLocaleString() }}원 결제하기</span>
            </button>
          </div>
        </div>
      </div>
    </form>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useCartStore } from '../stores/cart'
import { useAuthStore } from '../stores/auth'
import api from '../api'

const router = useRouter()
const cartStore = useCartStore()
const authStore = useAuthStore()

const submitting = ref(false)

const form = ref({
  buyer_name: authStore.user?.name || '',
  buyer_phone: authStore.user?.phone || '',
  buyer_email: authStore.user?.email || '',
  recipient_name: authStore.user?.name || '',
  recipient_phone: authStore.user?.phone || '',
  recipient_postcode: '',
  shipping_address: authStore.user?.address || '',
  shipping_memo: '',
  payment_method: 'bank_transfer',
  depositor_name: authStore.user?.name || '',
  used_points: 0
})

const copyBuyerInfo = (e) => {
  if (e.target.checked) {
    form.value.recipient_name = form.value.buyer_name
    form.value.recipient_phone = form.value.buyer_phone
  }
}

const useAllPoints = () => {
  const maxCanUse = Math.min(
    authStore.userPoints || 0,
    cartStore.itemTotal + cartStore.shippingFee
  )
  form.value.used_points = maxCanUse
}

const finalPayAmount = computed(() => {
  const base = cartStore.itemTotal + cartStore.shippingFee
  return Math.max(0, base - (form.value.used_points || 0))
})

const expectedEarnedPoints = computed(() => {
  return Math.floor(cartStore.itemTotal * 0.01)
})

const submitOrder = async () => {
  if (cartStore.items.length === 0) {
    alert('주문할 상품이 없습니다.')
    router.push('/')
    return
  }

  submitting.value = true
  try {
    const payload = {
      items: cartStore.items,
      ...form.value
    }
    const res = await api.post('/orders', payload)
    
    // Clear cart
    cartStore.clearCart()

    // Refresh user points if member
    if (authStore.isLoggedIn) {
      await authStore.fetchMe()
    }

    router.push(`/order-complete/${res.order.order_number}`)
  } catch (err) {
    alert(err.message)
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  if (cartStore.items.length === 0) {
    alert('장바구니가 비어 있습니다.')
    router.push('/cart')
  }
})
</script>

<style scoped>
.checkout-view {
  padding: 30px 16px 80px 16px;
}

.order-steps {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 12px;
  margin-bottom: 20px;
  font-size: 14px;
  color: #94a3b8;
}
.order-steps .step.active {
  color: #276735;
  font-weight: 800;
}
.step-arrow {
  font-size: 11px;
}

.page-title {
  font-size: 24px;
  font-weight: 800;
  color: #1a202c;
  margin-bottom: 24px;
  border-bottom: 2px solid #276735;
  padding-bottom: 12px;
}

.checkout-section {
  margin-bottom: 36px;
}
.section-sub-title {
  font-size: 16px;
  font-weight: 700;
  margin-bottom: 12px;
  color: #334155;
}

.item-desc-cell {
  display: flex;
  align-items: center;
  gap: 12px;
}
.item-mini-thumb {
  width: 50px;
  height: 50px;
  object-fit: cover;
  border-radius: 4px;
  border: 1px solid #e2e8f0;
}
.item-opt {
  font-size: 12px;
  color: #64748b;
  margin-top: 2px;
}

/* Grid */
.checkout-grid {
  display: grid;
  grid-template-columns: 1fr 380px;
  gap: 32px;
}

/* Cards */
.checkout-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
}
.card-title-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  border-bottom: 1px solid #edf2f7;
  padding-bottom: 10px;
}
.card-title {
  font-size: 16px;
  font-weight: 700;
  color: #1e293b;
  display: flex;
  align-items: center;
  gap: 8px;
}
.copy-buyer-label {
  font-size: 13px;
  color: #64748b;
  cursor: pointer;
}

.form-row {
  margin-bottom: 14px;
}
.form-row label {
  display: block;
  font-size: 13px;
  font-weight: 600;
  color: #475569;
  margin-bottom: 4px;
}
.req {
  color: #ef4444;
}
.postcode {
  max-width: 140px;
}

/* Points */
.point-usage-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
}
.point-input-wrap {
  display: flex;
  gap: 8px;
  align-items: center;
}
.point-input {
  width: 120px;
  text-align: right;
}

/* Payment Methods */
.pay-methods-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
}
.pay-method-pill {
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  padding: 12px 8px;
  text-align: center;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  background-color: #f8fafc;
  transition: all 0.2s;
}
.pay-method-pill.selected {
  border-color: #276735;
  background-color: #eef7f0;
  color: #276735;
}
.bank-details-box {
  margin-top: 14px;
  padding: 14px;
  background: #f8fafc;
  border: 1px dashed #cbd5e1;
  border-radius: 6px;
  font-size: 13px;
}
.mt-2 {
  margin-top: 8px;
}

/* Sidebar */
.sticky-sidebar {
  position: sticky;
  top: 20px;
}
.summary-card {
  background-color: #ffffff;
  border: 2px solid #276735;
  border-radius: 8px;
  padding: 24px;
}
.sidebar-title {
  font-size: 18px;
  font-weight: 800;
  color: #1e293b;
  border-bottom: 2px solid #edf2f7;
  padding-bottom: 12px;
  margin-bottom: 16px;
}
.sidebar-rows {
  display: flex;
  flex-direction: column;
  gap: 12px;
  font-size: 14px;
}
.s-row {
  display: flex;
  justify-content: space-between;
  color: #475569;
}
.point-minus {
  color: #ef4444;
}
.total-highlight {
  border-top: 1px solid #e2e8f0;
  padding-top: 14px;
  margin-top: 6px;
  font-size: 16px;
  font-weight: 700;
  color: #1e293b;
}
.total-big {
  color: #c04928;
  font-size: 24px;
  font-weight: 900;
}
.points-reward-box {
  margin: 16px 0;
  padding: 10px;
  background: #eef7f0;
  border-radius: 6px;
  font-size: 12px;
  color: #276735;
  text-align: center;
}
.pay-submit-btn {
  width: 100%;
  padding: 16px;
  font-size: 17px;
  font-weight: 800;
}

@media (max-width: 900px) {
  .checkout-grid {
    grid-template-columns: 1fr;
  }
}
</style>
