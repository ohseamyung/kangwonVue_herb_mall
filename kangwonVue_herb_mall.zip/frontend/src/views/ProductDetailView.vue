<template>
  <div v-if="loading" class="detail-loading container">
    <i class="fa-solid fa-spinner fa-spin"></i> 상품 정보를 불러오는 중입니다...
  </div>
  <div v-else-if="!product" class="detail-error container">
    <p>해당 상품 정보를 찾을 수 없습니다.</p>
    <router-link to="/" class="btn btn-primary">홈으로 이동</router-link>
  </div>
  <div v-else class="product-detail-view container">
    <!-- Breadcrumb -->
    <div class="breadcrumb">
      <router-link to="/">홈</router-link>
      <i class="fa-solid fa-angle-right sep"></i>
      <router-link :to="`/category/${product.category}`">{{ product.sub_category || '약초' }}</router-link>
      <i class="fa-solid fa-angle-right sep"></i>
      <span class="current">{{ product.name }}</span>
    </div>

    <!-- Product Main Top Area -->
    <div class="product-top-grid">
      <!-- Left: Image Gallery -->
      <div class="image-gallery-area">
        <div class="main-image-wrap">
          <img :src="product.image || '/static/images/p_mushroom_horse.jpg'" :alt="product.name" class="main-img" />
          <span v-if="product.badge" class="badge-overlay">{{ product.badge }}</span>
        </div>
      </div>

      <!-- Right: Product Purchase Form -->
      <div class="purchase-info-area">
        <div class="product-header-info">
          <div class="sub-category-tag">{{ product.sub_category || '강원약초 산지직송' }}</div>
          <h1 class="product-title">{{ product.name }}</h1>
          <p v-if="product.summary" class="product-summary-text">{{ product.summary }}</p>
        </div>

        <div class="price-spec-box">
          <div v-if="product.original_price && product.original_price > product.price" class="spec-row">
            <span class="spec-label">소비자가</span>
            <span class="spec-val strikethrough">{{ product.original_price.toLocaleString() }}원</span>
          </div>
          <div class="spec-row sale-highlight">
            <span class="spec-label">판매가</span>
            <span class="spec-val price-big">
              <strong>{{ product.price.toLocaleString() }}</strong>원
              <span v-if="discountRate > 0" class="discount-badge">{{ discountRate }}% 할인</span>
            </span>
          </div>
          <div class="spec-row">
            <span class="spec-label">배송비</span>
            <span class="spec-val">
              3,200원 <span class="free-tip">(50,000원 이상 구매 시 무료배송)</span>
            </span>
          </div>
          <div class="spec-row">
            <span class="spec-label">원산지</span>
            <span class="spec-val">{{ product.origin || '국산 (강원도)' }}</span>
          </div>
          <div class="spec-row">
            <span class="spec-label">적립금</span>
            <span class="spec-val text-green font-bold">
              1% ({{ Math.floor(product.price * 0.01).toLocaleString() }}원 적립)
            </span>
          </div>
          <div class="spec-row">
            <span class="spec-label">포장/중량</span>
            <span class="spec-val">{{ product.weight || '규격별 상이' }}</span>
          </div>
        </div>

        <!-- Option Selection -->
        <div v-if="product.options && product.options.length > 0" class="option-select-row">
          <label class="option-label">상품 선택</label>
          <select v-model="selectedOption" class="form-input">
            <option v-for="(opt, idx) in product.options" :key="idx" :value="opt">
              {{ opt.name }} {{ opt.price_diff > 0 ? `(+${opt.price_diff.toLocaleString()}원)` : '' }}
            </option>
          </select>
        </div>

        <!-- Quantity Selector -->
        <div class="quantity-row">
          <span class="qty-label">수량</span>
          <div class="qty-controller">
            <button class="qty-btn" @click="changeQty(-1)"><i class="fa-solid fa-minus"></i></button>
            <input type="number" v-model.number="quantity" min="1" class="qty-input" />
            <button class="qty-btn" @click="changeQty(1)"><i class="fa-solid fa-plus"></i></button>
          </div>
        </div>

        <!-- Total Price Summary -->
        <div class="total-price-box">
          <span class="total-label">총 상품금액 :</span>
          <span class="total-amount">
            <strong>{{ totalAmount.toLocaleString() }}</strong>원
          </span>
        </div>

        <!-- Action Buttons -->
        <div class="action-buttons-group">
          <button class="btn btn-outline btn-wish" @click="toggleWish">
            <i class="fa-regular fa-heart"></i>
          </button>
          <button class="btn btn-outline btn-cart" @click="addToCart">
            <i class="fa-solid fa-cart-shopping"></i> 장바구니
          </button>
          <button class="btn btn-primary btn-buy" @click="buyNow">
            바로구매 <i class="fa-solid fa-chevron-right"></i>
          </button>
        </div>
      </div>
    </div>

    <!-- Detail Tabs -->
    <div class="detail-tabs-area">
      <div class="tab-headers">
        <button 
          class="tab-btn" 
          :class="{ active: currentTab === 'info' }" 
          @click="currentTab = 'info'"
        >상품상세정보</button>
        <button 
          class="tab-btn" 
          :class="{ active: currentTab === 'reviews' }" 
          @click="currentTab = 'reviews'"
        >구매후기 ({{ reviews.length }})</button>
        <button 
          class="tab-btn" 
          :class="{ active: currentTab === 'qna' }" 
          @click="currentTab = 'qna'"
        >상품문의 ({{ qnas.length }})</button>
        <button 
          class="tab-btn" 
          :class="{ active: currentTab === 'shipping' }" 
          @click="currentTab = 'shipping'"
        >배송/교환/반품안내</button>
      </div>

      <!-- Tab Content 1: Info -->
      <div v-if="currentTab === 'info'" class="tab-pane info-pane">
        <div class="herb-story-banner">
          <h3>강원약초 산지직송 명품 안내</h3>
          <p>강원도 해발 600m 이상의 험준한 산악지대에서 청정 자연의 기운을 그대로 담아 채취한 최고 등급의 약초입니다.</p>
        </div>
        <div class="product-rich-desc" v-html="product.description || '<p>상세설명이 준비중입니다.</p>'"></div>
      </div>

      <!-- Tab Content 2: Reviews -->
      <div v-if="currentTab === 'reviews'" class="tab-pane reviews-pane">
        <div class="pane-header">
          <h3>고객 구매후기</h3>
          <button class="btn btn-primary btn-sm" @click="showReviewForm = !showReviewForm">
            <i class="fa-solid fa-pen"></i> 후기 작성하기
          </button>
        </div>

        <!-- Review Write Form -->
        <div v-if="showReviewForm" class="review-form-card">
          <h4>구매후기 작성</h4>
          <form @submit.prevent="submitReview">
            <div class="form-group">
              <label>별점</label>
              <select v-model="newReview.rating" class="form-input">
                <option :value="5">★★★★★ (5점 - 아주 만족해요)</option>
                <option :value="4">★★★★☆ (4점 - 만족해요)</option>
                <option :value="3">★★★☆☆ (3점 - 보통이에요)</option>
                <option :value="2">★★☆☆☆ (2점 - 아쉬워요)</option>
                <option :value="1">★☆☆☆☆ (1점 - 실망이에요)</option>
              </select>
            </div>
            <div class="form-group">
              <label>제목</label>
              <input type="text" v-model="newReview.title" placeholder="한줄 요약을 입력하세요" class="form-input" required />
            </div>
            <div class="form-group">
              <label>내용</label>
              <textarea v-model="newReview.content" rows="4" placeholder="상품에 대한 솔직한 후기를 남겨주세요." class="form-input" required></textarea>
            </div>
            <div class="form-actions">
              <button type="button" class="btn btn-outline btn-sm" @click="showReviewForm = false">취소</button>
              <button type="submit" class="btn btn-primary btn-sm">등록하기</button>
            </div>
          </form>
        </div>

        <div v-if="reviews.length === 0" class="no-items">
          첫 번째 구매후기의 주인공이 되어보세요!
        </div>
        <div v-else class="reviews-list">
          <div v-for="rev in reviews" :key="rev.id || rev._id" class="review-item">
            <div class="review-meta">
              <span class="stars">{{ '★'.repeat(rev.rating) }}{{ '☆'.repeat(5 - rev.rating) }}</span>
              <span class="author">{{ rev.author }}</span>
              <span class="date">{{ formatDate(rev.created_at) }}</span>
            </div>
            <h4 class="review-title">{{ rev.title }}</h4>
            <p class="review-content">{{ rev.content }}</p>
          </div>
        </div>
      </div>

      <!-- Tab Content 3: Q&A -->
      <div v-if="currentTab === 'qna'" class="tab-pane qna-pane">
        <div class="pane-header">
          <h3>상품 문의 (Q&A)</h3>
          <button class="btn btn-primary btn-sm" @click="showQnaForm = !showQnaForm">
            <i class="fa-solid fa-question"></i> 문의글 남기기
          </button>
        </div>

        <!-- Q&A Write Form -->
        <div v-if="showQnaForm" class="review-form-card">
          <h4>상품 문의 작성</h4>
          <form @submit.prevent="submitQna">
            <div class="form-group">
              <label>제목</label>
              <input type="text" v-model="newQna.title" placeholder="문의 제목을 입력하세요" class="form-input" required />
            </div>
            <div class="form-group">
              <label>문의내용</label>
              <textarea v-model="newQna.content" rows="4" placeholder="복용법, 배송일정, 옵션 등 문의사항을 남겨주세요." class="form-input" required></textarea>
            </div>
            <div class="form-actions">
              <button type="button" class="btn btn-outline btn-sm" @click="showQnaForm = false">취소</button>
              <button type="submit" class="btn btn-primary btn-sm">등록하기</button>
            </div>
          </form>
        </div>

        <div v-if="qnas.length === 0" class="no-items">
          등록된 상품 문의가 없습니다.
        </div>
        <div v-else class="qna-list">
          <div v-for="q in qnas" :key="q.id || q._id" class="qna-item">
            <div class="q-header">
              <span class="status-badge" :class="q.status === '답변완료' ? 'done' : 'wait'">{{ q.status || '답변대기' }}</span>
              <strong>{{ q.title }}</strong>
              <span class="q-author">{{ q.author }} | {{ formatDate(q.created_at) }}</span>
            </div>
            <p class="q-body">{{ q.content }}</p>
            <div v-if="q.answer" class="a-box">
              <span class="a-label"><i class="fa-solid fa-reply"></i> [강원약초 답변]</span>
              <p class="a-text">{{ q.answer }}</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Tab Content 4: Shipping Info -->
      <div v-if="currentTab === 'shipping'" class="tab-pane shipping-pane">
        <h4>■ 배송 안내</h4>
        <ul class="guide-list">
          <li><strong>배송업체:</strong> 우체국택배 / 로젠택배</li>
          <li><strong>배송비:</strong> 3,200원 (50,000원 이상 주문 시 무료배송)</li>
          <li><strong>출고시간:</strong> 평일 오후 2시 이전 결제 완료 건은 산지에서 당일 신선 포장 발송됩니다.</li>
          <li><strong>배송기간:</strong> 발송일로부터 평균 1~2영업일 이내 수령 가능합니다.</li>
        </ul>
        <br />
        <h4>■ 교환 및 반품 안내</h4>
        <ul class="guide-list">
          <li>농산물 및 천연 약재의 특성상 단순 변심에 의한 반품은 상품 수령 후 7일 이내에만 가능하며 왕복 배송비는 고객 부담입니다.</li>
          <li>포장 개봉 및 상품 훼손 시 교환/반품이 불가능합니다.</li>
          <li>배송 중 파손이나 상품 하자의 경우 100% 무상 교환 및 환불을 보장합니다.</li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useCartStore } from '../stores/cart'
import api from '../api'

const route = useRoute()
const router = useRouter()
const cartStore = useCartStore()

const product = ref(null)
const loading = ref(true)
const selectedOption = ref(null)
const quantity = ref(1)
const currentTab = ref('info')

const reviews = ref([])
const qnas = ref([])
const showReviewForm = ref(false)
const showQnaForm = ref(false)

const newReview = ref({ rating: 5, title: '', content: '' })
const newQna = ref({ title: '', content: '' })

const loadProductData = async () => {
  loading.value = true
  try {
    const res = await api.get(`/products/${route.params.id}`)
    product.value = res.product
    if (product.value.options && product.value.options.length > 0) {
      selectedOption.value = product.value.options[0]
    }
    
    // Load reviews & Q&As
    const [revs, qs] = await Promise.all([
      api.get(`/products/${route.params.id}/reviews`),
      api.get(`/products/${route.params.id}/qna`)
    ])
    reviews.value = revs
    qnas.value = qs
  } catch (err) {
    console.error('Failed to load product detail', err)
  } finally {
    loading.value = false
  }
}

const discountRate = computed(() => {
  if (product.value?.original_price && product.value.original_price > product.value.price) {
    return Math.round(((product.value.original_price - product.value.price) / product.value.original_price) * 100)
  }
  return 0
})

const totalAmount = computed(() => {
  if (!product.value) return 0
  const unitPrice = product.value.price + (selectedOption.value?.price_diff || 0)
  return unitPrice * quantity.value
})

const changeQty = (delta) => {
  quantity.value = Math.max(1, quantity.value + delta)
}

const addToCart = () => {
  cartStore.addItem({
    product: product.value,
    option: selectedOption.value,
    qty: quantity.value
  })
  if (confirm('장바구니에 담겼습니다! 장바구니로 이동하시겠습니까?')) {
    router.push('/cart')
  }
}

const buyNow = () => {
  cartStore.addItem({
    product: product.value,
    option: selectedOption.value,
    qty: quantity.value
  })
  router.push('/checkout')
}

const toggleWish = () => {
  alert('찜 목록에 추가되었습니다!')
}

const submitReview = async () => {
  try {
    await api.post(`/products/${route.params.id}/reviews`, newReview.value)
    alert('구매후기가 등록되었습니다!')
    showReviewForm.value = false
    newReview.value = { rating: 5, title: '', content: '' }
    reviews.value = await api.get(`/products/${route.params.id}/reviews`)
  } catch (err) {
    alert(err.message)
  }
}

const submitQna = async () => {
  try {
    await api.post(`/products/${route.params.id}/qna`, newQna.value)
    alert('문의가 등록되었습니다! 빠른 시일 내에 답변드리겠습니다.')
    showQnaForm.value = false
    newQna.value = { title: '', content: '' }
    qnas.value = await api.get(`/products/${route.params.id}/qna`)
  } catch (err) {
    alert(err.message)
  }
}

const formatDate = (isoStr) => {
  if (!isoStr) return ''
  return isoStr.substring(0, 10)
}

watch(() => route.params.id, () => {
  loadProductData()
})

onMounted(() => {
  loadProductData()
})
</script>

<style scoped>
.product-detail-view {
  padding: 24px 16px 80px 16px;
}
.breadcrumb {
  font-size: 12px;
  color: #64748b;
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 24px;
}
.sep {
  font-size: 10px;
  color: #cbd5e1;
}

/* Top Grid */
.product-top-grid {
  display: grid;
  grid-template-columns: 480px 1fr;
  gap: 48px;
  margin-bottom: 60px;
}
.image-gallery-area .main-image-wrap {
  position: relative;
  border-radius: 12px;
  overflow: hidden;
  border: 1px solid #e2e8f0;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}
.main-img {
  width: 100%;
  aspect-ratio: 1;
  object-fit: cover;
  display: block;
}
.badge-overlay {
  position: absolute;
  top: 14px;
  left: 14px;
  background-color: #276735;
  color: #ffffff;
  font-size: 12px;
  font-weight: bold;
  padding: 4px 10px;
  border-radius: 4px;
}

/* Info Area */
.sub-category-tag {
  font-size: 13px;
  color: #276735;
  font-weight: 700;
  margin-bottom: 6px;
}
.product-title {
  font-size: 24px;
  font-weight: 800;
  color: #1a202c;
  line-height: 1.35;
  margin-bottom: 10px;
}
.product-summary-text {
  font-size: 13px;
  color: #64748b;
  line-height: 1.5;
  margin-bottom: 20px;
}

/* Price Spec */
.price-spec-box {
  background-color: #f8fafc;
  border-top: 2px solid #276735;
  border-bottom: 1px solid #e2e8f0;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  font-size: 13px;
}
.spec-row {
  display: flex;
  align-items: center;
}
.spec-label {
  width: 90px;
  color: #64748b;
  font-weight: 600;
}
.spec-val {
  color: #1e293b;
}
.strikethrough {
  text-decoration: line-through;
  color: #94a3b8;
}
.price-big {
  color: #c04928;
}
.price-big strong {
  font-size: 24px;
  font-weight: 900;
}
.discount-badge {
  background-color: #c04928;
  color: #ffffff;
  font-size: 11px;
  font-weight: bold;
  padding: 2px 6px;
  border-radius: 4px;
  margin-left: 8px;
}
.free-tip {
  font-size: 12px;
  color: #276735;
  font-weight: 600;
}

/* Options & Qty */
.option-select-row, .quantity-row {
  margin-top: 16px;
  display: flex;
  align-items: center;
  gap: 16px;
}
.option-label, .qty-label {
  width: 74px;
  font-size: 13px;
  font-weight: 700;
  color: #334155;
}
.qty-controller {
  display: flex;
  align-items: center;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  overflow: hidden;
}
.qty-btn {
  width: 36px;
  height: 36px;
  background-color: #f8fafc;
  color: #334155;
  display: flex;
  align-items: center;
  justify-content: center;
}
.qty-btn:hover {
  background-color: #e2e8f0;
}
.qty-input {
  width: 50px;
  height: 36px;
  border: none;
  text-align: center;
  font-weight: bold;
  font-size: 14px;
  outline: none;
}

/* Total Box */
.total-price-box {
  margin-top: 24px;
  padding: 16px 20px;
  background-color: #eef7f0;
  border-radius: 8px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.total-label {
  font-size: 14px;
  font-weight: 700;
  color: #276735;
}
.total-amount {
  color: #c04928;
  font-size: 16px;
}
.total-amount strong {
  font-size: 26px;
  font-weight: 900;
}

/* Actions */
.action-buttons-group {
  margin-top: 20px;
  display: flex;
  gap: 10px;
}
.btn-wish {
  width: 52px;
  font-size: 20px;
  color: #64748b;
}
.btn-cart {
  flex: 1;
  border-color: #276735;
  color: #276735;
  font-size: 16px;
  font-weight: 700;
}
.btn-cart:hover {
  background-color: #eef7f0;
}
.btn-buy {
  flex: 1.5;
  font-size: 16px;
  font-weight: 800;
  background-color: #276735;
}

/* Tabs */
.detail-tabs-area {
  margin-top: 40px;
}
.tab-headers {
  display: flex;
  border-bottom: 2px solid #276735;
}
.tab-btn {
  flex: 1;
  padding: 16px;
  font-size: 15px;
  font-weight: 700;
  color: #64748b;
  background-color: #f8fafc;
  border: 1px solid #e2e8f0;
  border-bottom: none;
  transition: all 0.2s;
}
.tab-btn.active {
  background-color: #276735;
  color: #ffffff;
  border-color: #276735;
}

.tab-pane {
  padding: 36px 16px;
  border: 1px solid #e2e8f0;
  border-top: none;
  background: #ffffff;
}

/* Story Banner */
.herb-story-banner {
  background: linear-gradient(135deg, #1b4925, #276735);
  color: #ffffff;
  padding: 24px 28px;
  border-radius: 8px;
  margin-bottom: 30px;
}
.herb-story-banner h3 {
  font-size: 18px;
  font-weight: 800;
  margin-bottom: 6px;
}
.herb-story-banner p {
  font-size: 13px;
  color: #d1fae5;
}

.product-rich-desc {
  line-height: 1.8;
  font-size: 15px;
  color: #334155;
}

/* Reviews & QnA */
.pane-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}
.review-form-card {
  background-color: #f8fafc;
  padding: 20px;
  border-radius: 8px;
  border: 1px solid #cbd5e1;
  margin-bottom: 24px;
}
.review-form-card h4 {
  margin-bottom: 12px;
  font-size: 15px;
}
.form-group {
  margin-bottom: 12px;
}
.form-group label {
  display: block;
  font-size: 12px;
  font-weight: bold;
  margin-bottom: 4px;
}
.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
.no-items {
  text-align: center;
  padding: 40px;
  color: #94a3b8;
  font-size: 14px;
}
.review-item {
  border-bottom: 1px solid #edf2f7;
  padding: 16px 0;
}
.review-meta {
  display: flex;
  gap: 12px;
  font-size: 12px;
  color: #64748b;
  margin-bottom: 6px;
}
.stars {
  color: #f59e0b;
}
.review-title {
  font-size: 14px;
  font-weight: 700;
  margin-bottom: 4px;
}
.review-content {
  font-size: 13px;
  color: #475569;
}

/* QnA Items */
.qna-item {
  border-bottom: 1px solid #edf2f7;
  padding: 16px 0;
}
.q-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 6px;
}
.status-badge {
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 4px;
  font-weight: bold;
}
.status-badge.wait {
  background: #e2e8f0;
  color: #475569;
}
.status-badge.done {
  background: #276735;
  color: #ffffff;
}
.q-author {
  font-size: 12px;
  color: #94a3b8;
  margin-left: auto;
}
.q-body {
  font-size: 13px;
  color: #334155;
}
.a-box {
  margin-top: 10px;
  padding: 12px 16px;
  background: #eef7f0;
  border-radius: 6px;
  border-left: 4px solid #276735;
}
.a-label {
  font-size: 12px;
  font-weight: bold;
  color: #276735;
  display: block;
  margin-bottom: 4px;
}
.a-text {
  font-size: 13px;
  color: #1e293b;
}

/* Shipping Guide */
.guide-list {
  padding-left: 20px;
  font-size: 13px;
  color: #475569;
  line-height: 1.8;
  list-style: disc;
}

@media (max-width: 900px) {
  .product-top-grid {
    grid-template-columns: 1fr;
    gap: 24px;
  }
}
</style>
