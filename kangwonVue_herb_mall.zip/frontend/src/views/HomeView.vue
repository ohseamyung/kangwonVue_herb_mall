<template>
  <div class="home-view">
    <!-- 1. Hero Banner Slider -->
    <BannerSlider />

    <!-- 2. Notice Rolling Ticker Bar -->
    <div class="notice-ticker-bar">
      <div class="container ticker-inner">
        <div class="ticker-label">
          <i class="fa-solid fa-bullhorn text-gold"></i>
          <span>공지사항</span>
        </div>
        <div class="ticker-content">
          <router-link :to="`/board/notice`" class="ticker-link">
            [이벤트] 신규 회원가입 시 2,000원 적립금 즉시 증정 & 5만원 이상 전상품 무료배송!
          </router-link>
        </div>
        <div class="ticker-more">
          <router-link to="/board/notice">더보기 <i class="fa-solid fa-angle-right"></i></router-link>
        </div>
      </div>
    </div>

    <!-- 3. Category Shortcut Icons Bar -->
    <section class="category-icon-bar">
      <div class="container">
        <div class="icon-grid">
          <router-link 
            v-for="cat in categories.slice(0, 8)" 
            :key="cat.slug"
            :to="`/category/${cat.slug}`"
            class="cat-icon-card"
          >
            <div class="icon-circle">
              <i class="fa-solid" :class="cat.icon || 'fa-leaf'"></i>
            </div>
            <span class="cat-label">{{ cat.name }}</span>
          </router-link>
        </div>
      </div>
    </section>

    <!-- 4. MD's Pick Section -->
    <section class="home-section">
      <div class="container">
        <div class="section-header">
          <h2>강원약초 MD 추천 베스트</h2>
          <p>심마니가 직접 선별한 강원도 최고의 자연산 토종 명품</p>
        </div>

        <div v-if="loading" class="loading-state">
          <i class="fa-solid fa-spinner fa-spin"></i> 상품을 불러오는 중입니다...
        </div>
        <div v-else class="product-grid">
          <ProductCard 
            v-for="prod in mdProducts" 
            :key="prod.id || prod._id" 
            :product="prod" 
          />
        </div>
      </div>
    </section>

    <!-- 5. Promotional Middle Banner -->
    <section class="promo-strip">
      <div class="container strip-inner">
        <div class="strip-left">
          <span class="strip-badge">20년 전통 채취 비법</span>
          <h3>자연이 빚어낸 천연의 보약, 100% 자연산 야생 버섯 & 토종 약초</h3>
          <p>산화방지제, 인공색소, 방부제 일체 불포함! 자연 그대로 건조하여 배송합니다.</p>
        </div>
        <router-link to="/category/wild-mushrooms" class="strip-btn">
          야생 버섯전 바로가기 <i class="fa-solid fa-arrow-right"></i>
        </router-link>
      </div>
    </section>

    <!-- 6. Special Exhibition: 수제 액기스 & 한방차 -->
    <section class="home-section bg-warm">
      <div class="container">
        <div class="section-header">
          <h2>수제 액기스 & 전통 한방차 세트</h2>
          <p>원적외선 48시간 저온 추출로 맛과 영양을 살린 수제 건강즙</p>
        </div>

        <div class="product-grid">
          <ProductCard 
            v-for="prod in extractProducts" 
            :key="prod.id || prod._id" 
            :product="prod" 
          />
        </div>
      </div>
    </section>

    <!-- 7. Best Ranking Section -->
    <section class="home-section">
      <div class="container">
        <div class="section-header">
          <h2>고객 재구매율 1위 인기상품</h2>
          <p>강원약초를 찾아주신 분들께 검증된 베스트셀러</p>
        </div>

        <div class="product-grid">
          <ProductCard 
            v-for="prod in bestProducts" 
            :key="prod.id || prod._id" 
            :product="prod" 
          />
        </div>

        <div class="more-products-wrap">
          <router-link to="/products" class="btn btn-outline btn-lg">
            전체 상품 더보기 <i class="fa-solid fa-chevron-right"></i>
          </router-link>
        </div>
      </div>
    </section>

    <!-- 8. Trust & Guarantee Badges -->
    <section class="trust-guarantee-bar">
      <div class="container guarantee-grid">
        <div class="guarantee-item">
          <div class="guarantee-icon"><i class="fa-solid fa-mountain"></i></div>
          <div class="guarantee-text">
            <strong>100% 강원도 자연산</strong>
            <p>청정 고지대 야생 토종 약초 채취</p>
          </div>
        </div>
        <div class="guarantee-item">
          <div class="guarantee-icon"><i class="fa-solid fa-flask"></i></div>
          <div class="guarantee-text">
            <strong>순수 무첨가 원칙</strong>
            <p>방부제·합성착향료 0%</p>
          </div>
        </div>
        <div class="guarantee-item">
          <div class="guarantee-icon"><i class="fa-solid fa-truck-fast"></i></div>
          <div class="guarantee-text">
            <strong>산지직송 빠른배송</strong>
            <p>오후 2시 이전 주문 당일 발송</p>
          </div>
        </div>
        <div class="guarantee-item">
          <div class="guarantee-icon"><i class="fa-solid fa-shield-halved"></i></div>
          <div class="guarantee-text">
            <strong>100% 품질 책임제</strong>
            <p>상품 하자 시 즉시 무상 교환</p>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import BannerSlider from '../components/BannerSlider.vue'
import ProductCard from '../components/ProductCard.vue'
import api from '../api'

const loading = ref(true)
const categories = ref([])
const mdProducts = ref([])
const extractProducts = ref([])
const bestProducts = ref([])

onMounted(async () => {
  loading.value = true
  try {
    const [cats, prodsRes] = await Promise.all([
      api.get('/categories'),
      api.get('/products?limit=16')
    ])
    categories.value = cats
    const allProds = prodsRes.products || []

    mdProducts.value = allProds.filter(p => p.is_md).slice(0, 4)
    if (mdProducts.value.length < 4) {
      mdProducts.value = allProds.slice(0, 4)
    }

    extractProducts.value = allProds.filter(p => 
      p.category === 'liquid-extract' || p.category === 'ssanghwa-tea' || p.category === 'sipjeon-tea'
    ).slice(0, 4)

    bestProducts.value = allProds.filter(p => p.is_best).slice(0, 8)
  } catch (err) {
    console.error('Failed to load home data', err)
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
/* Notice Ticker */
.notice-ticker-bar {
  background-color: #1e293b;
  color: #ffffff;
  padding: 10px 0;
  font-size: 13px;
}
.ticker-inner {
  display: flex;
  align-items: center;
  gap: 16px;
}
.ticker-label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-weight: bold;
  white-space: nowrap;
}
.text-gold {
  color: #f59e0b;
}
.ticker-content {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ticker-link {
  color: #cbd5e1;
  transition: color 0.2s;
}
.ticker-link:hover {
  color: #ffffff;
  text-decoration: underline;
}
.ticker-more a {
  color: #94a3b8;
  font-size: 12px;
  white-space: nowrap;
}
.ticker-more a:hover {
  color: #ffffff;
}

/* Category Shortcut Bar */
.category-icon-bar {
  padding: 24px 0 12px 0;
  border-bottom: 1px solid #edf2f7;
}
.icon-grid {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 12px;
}
.cat-icon-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 10px 4px;
  border-radius: 8px;
  transition: transform 0.2s, background-color 0.2s;
}
.cat-icon-card:hover {
  background-color: #eef7f0;
  transform: translateY(-2px);
}
.icon-circle {
  width: 52px;
  height: 52px;
  background-color: #f1f5f9;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #276735;
  font-size: 20px;
  transition: background-color 0.2s, color 0.2s;
}
.cat-icon-card:hover .icon-circle {
  background-color: #276735;
  color: #ffffff;
}
.cat-label {
  font-size: 12px;
  font-weight: 600;
  color: #334155;
  text-align: center;
  word-break: keep-all;
}

/* Home Section */
.home-section {
  padding: 50px 0;
}
.home-section.bg-warm {
  background-color: #f8fafc;
}
.loading-state {
  text-align: center;
  padding: 40px;
  color: #64748b;
  font-size: 15px;
}

/* Promo Strip */
.promo-strip {
  background: linear-gradient(135deg, #1e4b28, #112d18);
  color: #ffffff;
  padding: 36px 0;
  margin: 10px 0;
}
.strip-inner {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 20px;
}
.strip-badge {
  display: inline-block;
  background-color: #c04928;
  color: #ffffff;
  font-size: 11px;
  font-weight: bold;
  padding: 3px 8px;
  border-radius: 4px;
  margin-bottom: 8px;
}
.strip-left h3 {
  font-size: 22px;
  font-weight: 800;
  margin-bottom: 6px;
}
.strip-left p {
  font-size: 14px;
  color: #cbd5e1;
}
.strip-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background-color: #ffffff;
  color: #1e4b28;
  font-weight: 700;
  font-size: 14px;
  padding: 12px 24px;
  border-radius: 6px;
  white-space: nowrap;
  transition: background-color 0.2s;
}
.strip-btn:hover {
  background-color: #f1f5f9;
}

.more-products-wrap {
  text-align: center;
  margin-top: 36px;
}

/* Guarantee Bar */
.trust-guarantee-bar {
  background-color: #ffffff;
  border-top: 1px solid #e2e8f0;
  padding: 36px 0;
}
.guarantee-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
}
.guarantee-item {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 12px;
}
.guarantee-icon {
  width: 48px;
  height: 48px;
  background-color: #eef7f0;
  color: #276735;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
  flex-shrink: 0;
}
.guarantee-text strong {
  display: block;
  font-size: 14px;
  color: #1e293b;
  margin-bottom: 2px;
}
.guarantee-text p {
  font-size: 12px;
  color: #64748b;
}

@media (max-width: 900px) {
  .icon-grid {
    grid-template-columns: repeat(4, 1fr);
  }
  .strip-inner {
    flex-direction: column;
    align-items: flex-start;
  }
  .guarantee-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>
