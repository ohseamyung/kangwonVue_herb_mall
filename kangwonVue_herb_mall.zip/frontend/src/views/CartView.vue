<template>
  <div class="cart-view container">
    <!-- Steps -->
    <div class="order-steps">
      <div class="step active">01 장바구니</div>
      <div class="step-arrow"><i class="fa-solid fa-angle-right"></i></div>
      <div class="step">02 주문/결제</div>
      <div class="step-arrow"><i class="fa-solid fa-angle-right"></i></div>
      <div class="step">03 주문완료</div>
    </div>

    <!-- Free shipping gauge -->
    <div class="free-shipping-gauge-box">
      <div class="gauge-text">
        <i class="fa-solid fa-truck-fast text-green"></i>
        <span v-if="cartStore.shippingFee === 0">
          축하합니다! <strong>무료배송</strong> 혜택을 받으실 수 있습니다.
        </span>
        <span v-else>
          <strong>{{ cartStore.freeShippingRemaining.toLocaleString() }}원</strong> 더 담으시면 <strong>무료배송</strong>입니다!
        </span>
      </div>
      <div class="gauge-bar">
        <div 
          class="gauge-fill"
          :style="{ width: `${Math.min(100, (cartStore.itemTotal / 50000) * 100)}%` }"
        ></div>
      </div>
    </div>

    <!-- Empty State -->
    <div v-if="cartStore.items.length === 0" class="empty-cart-box">
      <i class="fa-solid fa-cart-shopping empty-icon"></i>
      <h3>장바구니가 비어있습니다.</h3>
      <p>강원약초의 신선하고 건강한 자연산 약초를 둘러보세요.</p>
      <router-link to="/" class="btn btn-primary btn-lg">쇼핑하러 가기</router-link>
    </div>

    <!-- Cart Items Table -->
    <div v-else class="cart-table-wrap">
      <table class="mall-table">
        <thead>
          <tr>
            <th style="width: 80px;">이미지</th>
            <th>상품정보</th>
            <th style="width: 120px;">판매가</th>
            <th style="width: 140px;">수량</th>
            <th style="width: 130px;">합계</th>
            <th style="width: 80px;">선택</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in cartStore.items" :key="item.key">
            <td style="text-align: center;">
              <img :src="item.image || '/static/images/p_mushroom_horse.jpg'" class="cart-thumb" />
            </td>
            <td>
              <router-link :to="`/product/${item.product_id}`" class="item-name">
                {{ item.name }}
              </router-link>
              <div class="item-option">선택옵션: {{ item.option_name }}</div>
            </td>
            <td style="text-align: center;">
              {{ item.price.toLocaleString() }}원
            </td>
            <td style="text-align: center;">
              <div class="qty-inline">
                <button class="qty-btn" @click="cartStore.updateQty(item.key, item.qty - 1)">-</button>
                <span class="qty-num">{{ item.qty }}</span>
                <button class="qty-btn" @click="cartStore.updateQty(item.key, item.qty + 1)">+</button>
              </div>
            </td>
            <td style="text-align: center;" class="item-total-col">
              <strong>{{ ((item.price || 0) * (item.qty || 1)).toLocaleString() }}</strong>원
            </td>
            <td style="text-align: center;">
              <button class="btn-delete" @click="cartStore.removeItem(item.key)" title="삭제">
                <i class="fa-solid fa-trash-can"></i>
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- Cart Actions -->
      <div class="cart-sub-actions">
        <button class="btn btn-outline btn-sm" @click="confirmClear">
          <i class="fa-solid fa-trash"></i> 장바구니 비우기
        </button>
        <router-link to="/" class="btn btn-outline btn-sm">
          <i class="fa-solid fa-arrow-left"></i> 쇼핑 계속하기
        </router-link>
      </div>

      <!-- Total Summary Calculation Box -->
      <div class="cart-total-bill-box">
        <div class="bill-col">
          <span class="bill-title">총 상품금액</span>
          <span class="bill-price">{{ cartStore.itemTotal.toLocaleString() }}원</span>
        </div>
        <div class="bill-operator">+</div>
        <div class="bill-col">
          <span class="bill-title">배송비</span>
          <span class="bill-price">
            {{ cartStore.shippingFee === 0 ? '무료' : `${cartStore.shippingFee.toLocaleString()}원` }}
          </span>
        </div>
        <div class="bill-operator">=</div>
        <div class="bill-col final">
          <span class="bill-title">총 결제예정금액</span>
          <span class="bill-price-big">{{ cartStore.finalTotal.toLocaleString() }}원</span>
        </div>
      </div>

      <!-- Checkout Button -->
      <div class="cart-checkout-actions">
        <router-link to="/checkout" class="btn btn-primary btn-lg checkout-btn">
          주문서 작성하기 <i class="fa-solid fa-chevron-right"></i>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useCartStore } from '../stores/cart'

const cartStore = useCartStore()

const confirmClear = () => {
  if (confirm('장바구니의 모든 상품을 삭제하시겠습니까?')) {
    cartStore.clearCart()
  }
}
</script>

<style scoped>
.cart-view {
  padding: 30px 16px 80px 16px;
}

/* Steps */
.order-steps {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 12px;
  margin-bottom: 24px;
  font-size: 14px;
  color: #94a3b8;
}
.order-steps .step.active {
  color: #276735;
  font-weight: 800;
}
.step-arrow {
  font-size: 11px;
}

/* Free Shipping Gauge */
.free-shipping-gauge-box {
  background-color: #eef7f0;
  border: 1px solid #bbf7d0;
  border-radius: 8px;
  padding: 16px 20px;
  margin-bottom: 28px;
}
.gauge-text {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #1e3a24;
  margin-bottom: 8px;
}
.gauge-bar {
  width: 100%;
  height: 8px;
  background-color: #dcfce7;
  border-radius: 4px;
  overflow: hidden;
}
.gauge-fill {
  height: 100%;
  background: linear-gradient(90deg, #22c55e, #16a34a);
  border-radius: 4px;
  transition: width 0.3s ease;
}

/* Empty */
.empty-cart-box {
  text-align: center;
  padding: 80px 20px;
  background-color: #f8fafc;
  border: 1px dashed #cbd5e1;
  border-radius: 8px;
}
.empty-icon {
  font-size: 56px;
  color: #cbd5e1;
  margin-bottom: 16px;
}
.empty-cart-box h3 {
  font-size: 20px;
  color: #1e293b;
  margin-bottom: 8px;
}
.empty-cart-box p {
  font-size: 14px;
  color: #64748b;
  margin-bottom: 24px;
}

/* Table */
.cart-thumb {
  width: 60px;
  height: 60px;
  object-fit: cover;
  border-radius: 4px;
  border: 1px solid #e2e8f0;
}
.item-name {
  font-weight: 700;
  color: #1e293b;
}
.item-name:hover {
  color: #276735;
}
.item-option {
  font-size: 12px;
  color: #64748b;
  margin-top: 4px;
}
.qty-inline {
  display: inline-flex;
  align-items: center;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  overflow: hidden;
}
.qty-btn {
  width: 28px;
  height: 28px;
  background: #f8fafc;
  font-weight: bold;
}
.qty-num {
  width: 36px;
  text-align: center;
  font-weight: bold;
  font-size: 13px;
}
.item-total-col strong {
  color: #c04928;
}
.btn-delete {
  color: #94a3b8;
  font-size: 15px;
}
.btn-delete:hover {
  color: #ef4444;
}

.cart-sub-actions {
  display: flex;
  justify-content: space-between;
  margin-top: 16px;
}

/* Bill Box */
.cart-total-bill-box {
  background-color: #f8fafc;
  border: 2px solid #276735;
  border-radius: 8px;
  padding: 24px;
  display: flex;
  justify-content: space-around;
  align-items: center;
  margin-top: 36px;
}
.bill-col {
  text-align: center;
}
.bill-title {
  display: block;
  font-size: 13px;
  color: #64748b;
  margin-bottom: 6px;
}
.bill-price {
  font-size: 18px;
  font-weight: 700;
  color: #1e293b;
}
.bill-operator {
  font-size: 24px;
  font-weight: bold;
  color: #94a3b8;
}
.bill-col.final .bill-title {
  color: #276735;
  font-weight: 700;
}
.bill-price-big {
  font-size: 26px;
  font-weight: 900;
  color: #c04928;
}

.cart-checkout-actions {
  text-align: center;
  margin-top: 36px;
}
.checkout-btn {
  padding: 16px 60px;
  font-size: 18px;
  font-weight: 800;
}
</style>
