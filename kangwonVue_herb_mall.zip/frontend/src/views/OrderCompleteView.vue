<template>
  <div class="complete-view container">
    <!-- Steps -->
    <div class="order-steps">
      <div class="step">01 장바구니</div>
      <div class="step-arrow"><i class="fa-solid fa-angle-right"></i></div>
      <div class="step">02 주문/결제</div>
      <div class="step-arrow"><i class="fa-solid fa-angle-right"></i></div>
      <div class="step active">03 주문완료</div>
    </div>

    <div v-if="loading" class="complete-loading">
      <i class="fa-solid fa-spinner fa-spin"></i> 주문 정보를 불러오는 중입니다...
    </div>

    <div v-else-if="order" class="complete-content">
      <!-- Success Icon & Message -->
      <div class="success-banner">
        <div class="success-icon"><i class="fa-solid fa-check"></i></div>
        <h2>주문이 성공적으로 완료되었습니다!</h2>
        <p>강원약초를 이용해 주셔서 진심으로 감사드립니다. 정성을 다해 안전하게 배송해 드리겠습니다.</p>
        <div class="order-num-box">
          주문번호: <strong>{{ order.order_number }}</strong>
        </div>
      </div>

      <!-- Deposit Box if Bank Transfer -->
      <div v-if="order.payment_method === 'bank_transfer'" class="bank-deposit-card">
        <h3><i class="fa-solid fa-building-columns text-green"></i> 무통장 입금 안내</h3>
        <div class="bank-info-grid">
          <div class="bank-info-row">
            <span class="label">입금은행</span>
            <span class="val">농협은행</span>
          </div>
          <div class="bank-info-row">
            <span class="label">계좌번호</span>
            <span class="val font-bold text-lg">302-0851-0319-21</span>
          </div>
          <div class="bank-info-row">
            <span class="label">예금주</span>
            <span class="val">강영자(강원약초)</span>
          </div>
          <div class="bank-info-row">
            <span class="label">입금금액</span>
            <span class="val price-big">{{ order.final_total?.toLocaleString() }}원</span>
          </div>
          <div class="bank-info-row">
            <span class="label">입금자명</span>
            <span class="val">{{ order.depositor_name || order.buyer_name }}</span>
          </div>
        </div>
        <p class="bank-tip-text">
          ※ 주문 후 48시간 이내에 미입금 시 주문이 자동 취소될 수 있습니다.
        </p>
      </div>

      <!-- Details Summary -->
      <div class="details-summary-card">
        <h3>배송 및 결제 정보</h3>
        <table class="mall-table">
          <tbody>
            <tr>
              <th style="width: 140px;">받는 분</th>
              <td>{{ order.recipient_name }}</td>
            </tr>
            <tr>
              <th>연락처</th>
              <td>{{ order.recipient_phone }}</td>
            </tr>
            <tr>
              <th>배송지 주소</th>
              <td>{{ order.shipping_address }}</td>
            </tr>
            <tr>
              <th>결제 수단</th>
              <td>{{ order.payment_method === 'bank_transfer' ? '무통장입금' : '카드/간편결제' }}</td>
            </tr>
            <tr>
              <th>결제 금액</th>
              <td><strong>{{ order.final_total?.toLocaleString() }}원</strong></td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Buttons -->
      <div class="complete-actions">
        <router-link to="/" class="btn btn-outline btn-lg">홈으로 이동</router-link>
        <router-link to="/mypage" class="btn btn-primary btn-lg">주문내역 확인</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import api from '../api'

const route = useRoute()
const order = ref(null)
const loading = ref(true)

onMounted(async () => {
  try {
    const res = await api.get(`/orders/${route.params.orderNumber}`)
    order.value = res
  } catch (err) {
    console.error('Order load error', err)
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.complete-view {
  padding: 30px 16px 80px 16px;
}
.order-steps {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 12px;
  margin-bottom: 30px;
  font-size: 14px;
  color: #94a3b8;
}
.order-steps .step.active {
  color: #276735;
  font-weight: 800;
}
.step-arrow {
  font-size: 11px;
}

.complete-loading {
  text-align: center;
  padding: 80px;
  color: #64748b;
}

.success-banner {
  text-align: center;
  background-color: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 40px 20px;
  margin-bottom: 30px;
}
.success-icon {
  width: 64px;
  height: 64px;
  background-color: #276735;
  color: #ffffff;
  font-size: 28px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px auto;
}
.success-banner h2 {
  font-size: 24px;
  font-weight: 800;
  color: #1a202c;
  margin-bottom: 8px;
}
.success-banner p {
  font-size: 14px;
  color: #64748b;
  margin-bottom: 20px;
}
.order-num-box {
  display: inline-block;
  background-color: #ffffff;
  border: 1px solid #cbd5e1;
  padding: 8px 24px;
  border-radius: 20px;
  font-size: 15px;
}
.order-num-box strong {
  color: #c04928;
}

/* Bank */
.bank-deposit-card {
  background-color: #eef7f0;
  border: 2px solid #276735;
  border-radius: 8px;
  padding: 24px;
  margin-bottom: 30px;
}
.bank-deposit-card h3 {
  font-size: 18px;
  color: #1e3a24;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.bank-info-grid {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.bank-info-row {
  display: flex;
  font-size: 14px;
}
.bank-info-row .label {
  width: 100px;
  color: #52795d;
  font-weight: 600;
}
.bank-info-row .val {
  color: #1e293b;
}
.text-lg {
  font-size: 16px;
}
.font-bold {
  font-weight: bold;
}
.price-big {
  color: #c04928;
  font-size: 18px;
  font-weight: 900;
}
.bank-tip-text {
  font-size: 12px;
  color: #4a6b52;
  margin-top: 14px;
  padding-top: 10px;
  border-top: 1px dashed #a7d3b0;
}

/* Details */
.details-summary-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 24px;
  margin-bottom: 36px;
}
.details-summary-card h3 {
  font-size: 16px;
  font-weight: 700;
  margin-bottom: 16px;
}

.complete-actions {
  display: flex;
  justify-content: center;
  gap: 16px;
}
</style>
