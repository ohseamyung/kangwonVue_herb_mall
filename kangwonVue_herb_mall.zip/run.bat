@echo off
chcp 65001 > nul
echo ==================================================
echo   강원약초 (kangwons.com) 쇼핑몰 서버 실행
echo   스택: Python + Flask + Vue 3 + MongoDB
echo ==================================================
echo.
echo 1. MongoDB 연결 상태 확인 및 데이터베이스 점검...
python -c "from db import get_db; get_db().command('ping')" > nul 2>&1
if %errorlevel% neq 0 (
    echo [경고] MongoDB 서비스가 실행되어 있지 않습니다!
    echo MongoDB를 먼저 실행해주세요 (mongod).
    pause
    exit /b
)

echo 2. 강원약초 쇼핑몰 서버 구동 중...
echo    접속 주소: http://127.0.0.1:5000/
echo    관리자 계정: admin / admin1234
echo    테스트 회원: testuser / 1234
echo.
start http://127.0.0.1:5000/
python app.py
pause
