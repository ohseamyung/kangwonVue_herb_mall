from pymongo import MongoClient
from bson.objectid import ObjectId
from config import Config

client = None
db = None

def get_db():
    global client, db
    if db is None:
        client = MongoClient(Config.MONGODB_URI, serverSelectionTimeoutMS=3000)
        db = client[Config.DB_NAME]
    return db

def to_object_id(id_str):
    try:
        return ObjectId(id_str)
    except Exception:
        return None

# Collections helper
def col_products():
    return get_db()['products']

def col_categories():
    return get_db()['categories']

def col_users():
    return get_db()['users']

def col_orders():
    return get_db()['orders']

def col_reviews():
    return get_db()['reviews']

def col_qna():
    return get_db()['qna']

def col_notices():
    return get_db()['notices']

def col_banners():
    return get_db()['banners']

def serialize_doc(doc):
    if not doc:
        return None
    res = {}
    for k, v in doc.items():
        if k == '_id':
            res['id'] = str(v)
            res['_id'] = str(v)
        elif isinstance(v, ObjectId):
            res[k] = str(v)
        elif hasattr(v, 'isoformat'):
            res[k] = v.isoformat()
        elif isinstance(v, list):
            res[k] = [serialize_doc(item) if isinstance(item, dict) else str(item) if isinstance(item, ObjectId) else item for item in v]
        elif isinstance(v, dict):
            res[k] = serialize_doc(v)
        else:
            res[k] = v
    return res

def serialize_docs(docs):
    return [serialize_doc(d) for d in docs]

