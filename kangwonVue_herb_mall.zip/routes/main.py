from flask import Blueprint, render_template, request, jsonify
from db import col_products, col_categories, col_banners, col_notices, col_reviews
from config import Config

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    banners = list(col_banners().find())
    categories = list(col_categories().find().sort('order', 1))
    
    # MD's Pick, Best, New products
    md_products = list(col_products().find({'is_md': True}).limit(8))
    best_products = list(col_products().find({'is_best': True}).limit(8))
    new_products = list(col_products().find().sort('created_at', -1).limit(8))
    
    # Recent notices and reviews for footer / home boards
    recent_notices = list(col_notices().find().sort('created_at', -1).limit(5))
    recent_reviews = list(col_reviews().find().sort('created_at', -1).limit(4))
    
    return render_template('index.html',
                           banners=banners,
                           categories=categories,
                           md_products=md_products,
                           best_products=best_products,
                           new_products=new_products,
                           recent_notices=recent_notices,
                           recent_reviews=recent_reviews,
                           config=Config)

@main_bp.route('/category/<slug>')
def category_view(slug):
    category = col_categories().find_one({'slug': slug})
    categories = list(col_categories().find().sort('order', 1))
    
    sort_by = request.args.get('sort', 'popular')
    query = {}
    
    if slug == 'best-items':
        query = {'is_best': True}
        cat_name = 'BEST 인기상품'
    elif category:
        query = {'category': slug}
        cat_name = category.get('name', '상품 목록')
    else:
        cat_name = '전체 상품'
        
    sort_criteria = [('is_best', -1), ('rating', -1)]
    if sort_by == 'new':
        sort_criteria = [('created_at', -1)]
    elif sort_by == 'price_asc':
        sort_criteria = [('price', 1)]
    elif sort_by == 'price_desc':
        sort_criteria = [('price', -1)]
    elif sort_by == 'rating':
        sort_criteria = [('rating', -1)]
        
    products = list(col_products().find(query).sort(sort_criteria))
    
    return render_template('product_list.html',
                           category=category,
                           current_slug=slug,
                           cat_name=cat_name,
                           categories=categories,
                           products=products,
                           sort_by=sort_by,
                           total_count=len(products),
                           config=Config)

@main_bp.route('/search')
def search():
    keyword = request.args.get('q', '').strip()
    sort_by = request.args.get('sort', 'popular')
    categories = list(col_categories().find().sort('order', 1))
    
    if keyword:
        regex = {'$regex': keyword, '$options': 'i'}
        query = {'$or': [
            {'name': regex},
            {'summary': regex},
            {'description': regex},
            {'origin': regex},
            {'sub_category': regex}
        ]}
    else:
        query = {}
        
    sort_criteria = [('created_at', -1)]
    if sort_by == 'price_asc':
        sort_criteria = [('price', 1)]
    elif sort_by == 'price_desc':
        sort_criteria = [('price', -1)]
    elif sort_by == 'rating':
        sort_criteria = [('rating', -1)]
        
    products = list(col_products().find(query).sort(sort_criteria))
    
    return render_template('product_list.html',
                           keyword=keyword,
                           cat_name=f"'{keyword}' 검색 결과" if keyword else "전체 상품",
                           categories=categories,
                           products=products,
                           sort_by=sort_by,
                           total_count=len(products),
                           config=Config)

@main_bp.route('/company')
def company():
    return render_template('shopinfo/company.html', config=Config)

@main_bp.route('/guide')
def guide():
    return render_template('shopinfo/guide.html', config=Config)
