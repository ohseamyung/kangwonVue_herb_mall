import datetime
import random
import re
from flask import Blueprint, request, jsonify, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from bson.objectid import ObjectId

from config import Config
from db import (
    col_products, col_categories, col_users, col_orders, 
    col_reviews, col_qna, col_notices, col_banners, 
    to_object_id, serialize_doc, serialize_docs
)
from auth_helper import generate_token, get_current_user, login_required, admin_required

api_bp = Blueprint('api', __name__, url_prefix='/api')

# ==============================================================================
# 1. Config, Banners, Categories
# ==============================================================================
@api_bp.route('/config', methods=['GET'])
def get_config():
    return jsonify({
        'store_name': Config.STORE_NAME,
        'store_desc': Config.STORE_DESC,
        'tel_primary': Config.TEL_PRIMARY,
        'tel_mobile': Config.TEL_MOBILE,
        'hours': Config.HOURS,
        'bank_name': Config.BANK_NAME,
        'bank_account': Config.BANK_ACCOUNT,
        'bank_holder': Config.BANK_HOLDER,
        'address': Config.ADDRESS,
        'ceo': Config.CEO,
        'email': Config.EMAIL,
        'biz_number': Config.BIZ_NUMBER,
        'commerce_number': Config.COMMERCE_NUMBER,
        'free_shipping_threshold': Config.FREE_SHIPPING_THRESHOLD,
        'shipping_fee': Config.SHIPPING_FEE,
        'signup_point': Config.SIGNUP_POINT,
        'point_earn_rate': Config.POINT_EARN_RATE
    })

@api_bp.route('/banners', methods=['GET'])
def get_banners():
    banners = list(col_banners().find())
    return jsonify(serialize_docs(banners))

@api_bp.route('/categories', methods=['GET'])
def get_categories():
    categories = list(col_categories().find().sort('order', 1))
    
    # Calculate count for each category
    result = []
    for cat in categories:
        cat_data = serialize_doc(cat)
        slug = cat.get('slug')
        if slug == 'best-items':
            count = col_products().count_documents({'is_best': True})
        else:
            count = col_products().count_documents({'category': slug})
        cat_data['product_count'] = count
        result.append(cat_data)
        
    return jsonify(result)

# ==============================================================================
# 2. Products API
# ==============================================================================
@api_bp.route('/products', methods=['GET'])
def get_products():
    category = request.args.get('category')
    search = request.args.get('search', '').strip()
    sort_type = request.args.get('sort', 'default')
    badge = request.args.get('badge')
    is_best = request.args.get('is_best')
    is_new = request.args.get('is_new')
    is_md = request.args.get('is_md')
    limit = int(request.args.get('limit', 0))
    page = int(request.args.get('page', 1))
    page_size = int(request.args.get('page_size', 20))

    query = {}
    
    if category and category != 'all':
        if category == 'best-items':
            query['is_best'] = True
        else:
            query['category'] = category
            
    if search:
        search_regex = {'$regex': re.escape(search), '$options': 'i'}
        query['$or'] = [
            {'name': search_regex},
            {'summary': search_regex},
            {'origin': search_regex},
            {'sub_category': search_regex}
        ]
        
    if is_best == 'true':
        query['is_best'] = True
    if is_new == 'true':
        query['is_new'] = True
    if is_md == 'true':
        query['is_md'] = True
    if badge:
        query['badge'] = badge

    # Sort
    sort_field = [('created_at', -1)]
    if sort_type == 'price_asc':
        sort_field = [('price', 1)]
    elif sort_type == 'price_desc':
        sort_field = [('price', -1)]
    elif sort_type == 'best' or sort_type == 'sales':
        sort_field = [('is_best', -1), ('review_count', -1)]
    elif sort_type == 'rating':
        sort_field = [('rating', -1)]
    elif sort_type == 'new':
        sort_field = [('created_at', -1)]

    total = col_products().count_documents(query)

    cursor = col_products().find(query).sort(sort_field)
    
    if limit > 0:
        cursor = cursor.limit(limit)
    else:
        cursor = cursor.skip((page - 1) * page_size).limit(page_size)

    products = list(cursor)
    
    return jsonify({
        'products': serialize_docs(products),
        'total': total,
        'page': page,
        'page_size': page_size,
        'total_pages': (total + page_size - 1) // page_size if page_size > 0 else 1
    })

@api_bp.route('/products/<product_id>', methods=['GET'])
def get_product(product_id):
    obj_id = to_object_id(product_id)
    if not obj_id:
        return jsonify({'error': '유효하지 않은 상품 ID입니다.'}), 404
        
    product = col_products().find_one({'_id': obj_id})
    if not product:
        return jsonify({'error': '상품을 찾을 수 없습니다.'}), 404

    # Related products
    related = list(col_products().find({
        'category': product.get('category'),
        '_id': {'$ne': obj_id}
    }).limit(4))

    return jsonify({
        'product': serialize_doc(product),
        'related': serialize_docs(related)
    })

@api_bp.route('/products/<product_id>/reviews', methods=['GET', 'POST'])
def handle_product_reviews(product_id):
    obj_id = to_object_id(product_id)
    if not obj_id:
        return jsonify({'error': '유효하지 않은 상품 ID입니다.'}), 404
        
    product = col_products().find_one({'_id': obj_id})
    if not product:
        return jsonify({'error': '상품을 찾을 수 없습니다.'}), 404

    if request.method == 'GET':
        reviews = list(col_reviews().find({
            '$or': [{'product_id': str(obj_id)}, {'product_name': product.get('name')}]
        }).sort('created_at', -1))
        return jsonify(serialize_docs(reviews))

    elif request.method == 'POST':
        data = request.get_json() or {}
        user = get_current_user()
        
        author = user.get('name') if user else data.get('author', '고객').strip()
        rating = int(data.get('rating', 5))
        title = data.get('title', '').strip()
        content = data.get('content', '').strip()

        if not content:
            return jsonify({'error': '후기 내용을 입력해주세요.'}), 400

        review_doc = {
            'product_id': str(obj_id),
            'product_name': product.get('name'),
            'author': author,
            'user_id': str(user['_id']) if user else None,
            'rating': rating,
            'title': title or content[:20],
            'content': content,
            'created_at': datetime.datetime.now()
        }
        
        col_reviews().insert_one(review_doc)
        
        # Update product review stats
        all_revs = list(col_reviews().find({'$or': [{'product_id': str(obj_id)}, {'product_name': product.get('name')}]}))
        avg_rating = round(sum(r.get('rating', 5) for r in all_revs) / len(all_revs), 1) if all_revs else 5.0
        col_products().update_one(
            {'_id': obj_id},
            {'$set': {'rating': avg_rating, 'review_count': len(all_revs)}}
        )

        return jsonify({'message': '구매후기가 성공적으로 등록되었습니다.', 'review': serialize_doc(review_doc)}), 201

@api_bp.route('/products/<product_id>/qna', methods=['GET', 'POST'])
def handle_product_qna(product_id):
    obj_id = to_object_id(product_id)
    if not obj_id:
        return jsonify({'error': '유효하지 않은 상품 ID입니다.'}), 404
        
    product = col_products().find_one({'_id': obj_id})
    if not product:
        return jsonify({'error': '상품을 찾을 수 없습니다.'}), 404

    if request.method == 'GET':
        qnas = list(col_qna().find({
            '$or': [{'product_id': str(obj_id)}, {'product_name': product.get('name')}]
        }).sort('created_at', -1))
        return jsonify(serialize_docs(qnas))

    elif request.method == 'POST':
        data = request.get_json() or {}
        user = get_current_user()
        
        author = user.get('name') if user else data.get('author', '고객').strip()
        title = data.get('title', '').strip()
        content = data.get('content', '').strip()
        is_secret = bool(data.get('is_secret', False))

        if not content or not title:
            return jsonify({'error': '제목과 문의 내용을 모두 입력해주세요.'}), 400

        qna_doc = {
            'product_id': str(obj_id),
            'product_name': product.get('name'),
            'author': author,
            'user_id': str(user['_id']) if user else None,
            'title': title,
            'content': content,
            'is_secret': is_secret,
            'status': '답변대기',
            'answer': None,
            'created_at': datetime.datetime.now()
        }
        col_qna().insert_one(qna_doc)
        return jsonify({'message': '상품 문의가 등록되었습니다.', 'qna': serialize_doc(qna_doc)}), 201

# ==============================================================================
# 3. Auth API (Register + 2000P, Login, Me)
# ==============================================================================
@api_bp.route('/auth/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    name = data.get('name', '').strip()
    email = data.get('email', '').strip()
    phone = data.get('phone', '').strip()
    address = data.get('address', '').strip()

    if not username or not password or not name:
        return jsonify({'error': '아이디, 비밀번호, 성명은 필수 입력 사항입니다.'}), 400

    if len(password) < 4:
        return jsonify({'error': '비밀번호는 최소 4자리 이상이어야 합니다.'}), 400

    if col_users().find_one({'username': username}):
        return jsonify({'error': '이미 존재하는 아이디입니다.'}), 409

    signup_points = Config.SIGNUP_POINT

    user_doc = {
        'username': username,
        'password': generate_password_hash(password),
        'name': name,
        'email': email,
        'phone': phone,
        'address': address,
        'role': 'user',
        'points': signup_points,
        'point_history': [
            {
                'amount': signup_points,
                'desc': '신규 회원가입 축하 적립금',
                'created_at': datetime.datetime.now()
            }
        ],
        'created_at': datetime.datetime.now()
    }

    res = col_users().insert_one(user_doc)
    user_doc['_id'] = res.inserted_id

    token = generate_token(user_doc)
    
    user_data = serialize_doc(user_doc)
    user_data.pop('password', None)

    return jsonify({
        'message': f'회원가입이 완료되었습니다! 축하 적립금 {signup_points:,}원이 지급되었습니다.',
        'token': token,
        'user': user_data
    }), 201

@api_bp.route('/auth/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()

    if not username or not password:
        return jsonify({'error': '아이디와 비밀번호를 입력해주세요.'}), 400

    user = col_users().find_one({'username': username})
    if not user or not check_password_hash(user.get('password', ''), password):
        return jsonify({'error': '아이디 또는 비밀번호가 일치하지 않습니다.'}), 401

    token = generate_token(user)
    user_data = serialize_doc(user)
    user_data.pop('password', None)

    return jsonify({
        'message': f'{user.get("name")}님 환영합니다!',
        'token': token,
        'user': user_data
    })

@api_bp.route('/auth/me', methods=['GET'])
def get_me():
    user = get_current_user()
    if not user:
        return jsonify({'error': '로그인이 필요합니다.'}), 401
        
    user_data = serialize_doc(user)
    user_data.pop('password', None)

    # Count orders
    orders_count = col_orders().count_documents({'user_id': str(user['_id'])})
    user_data['orders_count'] = orders_count

    return jsonify(user_data)

@api_bp.route('/auth/me', methods=['PUT'])
@login_required
def update_me(user):
    data = request.get_json() or {}
    update_fields = {}
    
    if 'name' in data:
        update_fields['name'] = data['name'].strip()
    if 'email' in data:
        update_fields['email'] = data['email'].strip()
    if 'phone' in data:
        update_fields['phone'] = data['phone'].strip()
    if 'address' in data:
        update_fields['address'] = data['address'].strip()
    if 'password' in data and len(data['password'].strip()) >= 4:
        update_fields['password'] = generate_password_hash(data['password'].strip())

    if update_fields:
        col_users().update_one({'_id': user['_id']}, {'$set': update_fields})
        
    updated_user = col_users().find_one({'_id': user['_id']})
    user_data = serialize_doc(updated_user)
    user_data.pop('password', None)

    return jsonify({'message': '회원정보가 수정되었습니다.', 'user': user_data})

# ==============================================================================
# 4. Orders API (Create, List, Detail, Non-member Lookup)
# ==============================================================================
@api_bp.route('/orders', methods=['POST'])
def create_order():
    data = request.get_json() or {}
    user = get_current_user()

    items = data.get('items', [])
    if not items:
        return jsonify({'error': '주문할 상품이 없습니다.'}), 400

    buyer_name = data.get('buyer_name', '').strip()
    buyer_phone = data.get('buyer_phone', '').strip()
    buyer_email = data.get('buyer_email', '').strip()
    
    recipient_name = data.get('recipient_name', '').strip()
    recipient_phone = data.get('recipient_phone', '').strip()
    recipient_postcode = data.get('recipient_postcode', '').strip()
    shipping_address = data.get('shipping_address', '').strip()
    shipping_memo = data.get('shipping_memo', '').strip()
    
    payment_method = data.get('payment_method', 'bank_transfer')
    deposit_bank = data.get('deposit_bank', f"{Config.BANK_NAME} {Config.BANK_ACCOUNT} ({Config.BANK_HOLDER})")
    depositor_name = data.get('depositor_name', buyer_name)
    used_points = int(data.get('used_points', 0))

    if not buyer_name or not buyer_phone or not recipient_name or not recipient_phone or not shipping_address:
        return jsonify({'error': '주문자 및 배송지 정보를 빠짐없이 입력해주세요.'}), 400

    # Calculate item total
    item_total = 0
    order_items = []
    for it in items:
        qty = int(it.get('qty', 1))
        unit_price = int(it.get('price', 0))
        item_sum = unit_price * qty
        item_total += item_sum
        order_items.append({
            'product_id': it.get('product_id'),
            'product_name': it.get('name'),
            'option_name': it.get('option_name', ''),
            'price': unit_price,
            'qty': qty,
            'total': item_sum,
            'image': it.get('image')
        })

    # Calculate shipping fee
    shipping_fee = 0 if item_total >= Config.FREE_SHIPPING_THRESHOLD else Config.SHIPPING_FEE

    # Validate point usage
    user_points = user.get('points', 0) if user else 0
    if used_points > 0:
        if not user:
            return jsonify({'error': '적립금은 회원만 사용하실 수 있습니다.'}), 400
        if used_points > user_points:
            return jsonify({'error': '보유하신 적립금을 초과하여 사용할 수 없습니다.'}), 400
        if used_points > (item_total + shipping_fee):
            used_points = item_total + shipping_fee

    final_total = max(0, item_total + shipping_fee - used_points)
    earned_points = int(item_total * Config.POINT_EARN_RATE)

    # Generate Order Number: KW + YYYYMMDD + random 5 digits
    now = datetime.datetime.now()
    order_number = f"KW{now.strftime('%Y%m%d')}-{random.randint(10000, 99999)}"

    order_doc = {
        'order_number': order_number,
        'user_id': str(user['_id']) if user else None,
        'is_guest': user is None,
        'buyer_name': buyer_name,
        'buyer_phone': buyer_phone,
        'buyer_email': buyer_email,
        'recipient_name': recipient_name,
        'recipient_phone': recipient_phone,
        'recipient_postcode': recipient_postcode,
        'shipping_address': shipping_address,
        'shipping_memo': shipping_memo,
        'items': order_items,
        'item_total': item_total,
        'shipping_fee': shipping_fee,
        'used_points': used_points,
        'earned_points': earned_points,
        'final_total': final_total,
        'payment_method': payment_method,
        'deposit_bank': deposit_bank,
        'depositor_name': depositor_name,
        'status': '입금대기' if payment_method == 'bank_transfer' else '결제완료',
        'created_at': now
    }

    res = col_orders().insert_one(order_doc)
    order_doc['_id'] = res.inserted_id

    # Update points if member
    if user and used_points > 0:
        col_users().update_one(
            {'_id': user['_id']},
            {
                '$inc': {'points': -used_points},
                '$push': {
                    'point_history': {
                        'amount': -used_points,
                        'desc': f'주문 {order_number} 결제 시 사용',
                        'created_at': now
                    }
                }
            }
        )

    return jsonify({
        'message': '주문이 성공적으로 접수되었습니다.',
        'order': serialize_doc(order_doc)
    }), 201

@api_bp.route('/orders', methods=['GET'])
@login_required
def get_user_orders(user):
    orders = list(col_orders().find({'user_id': str(user['_id'])}).sort('created_at', -1))
    return jsonify(serialize_docs(orders))

@api_bp.route('/orders/<order_id_or_number>', methods=['GET'])
def get_order_detail(order_id_or_number):
    user = get_current_user()
    
    query = {'$or': [{'order_number': order_id_or_number}]}
    obj_id = to_object_id(order_id_or_number)
    if obj_id:
        query['$or'].append({'_id': obj_id})
        
    order = col_orders().find_one(query)
    if not order:
        return jsonify({'error': '주문 정보를 찾을 수 없습니다.'}), 404

    # Security check: if member order, ensure same user or admin
    if order.get('user_id'):
        if not user or (user.get('role') != 'admin' and str(user['_id']) != order.get('user_id')):
            return jsonify({'error': '권한이 없습니다.'}), 403

    return jsonify(serialize_doc(order))

@api_bp.route('/orders/lookup', methods=['POST'])
def lookup_guest_order():
    data = request.get_json() or {}
    order_number = data.get('order_number', '').strip()
    phone = data.get('phone', '').strip().replace('-', '')

    if not order_number or not phone:
        return jsonify({'error': '주문번호와 연락처를 입력해주세요.'}), 400

    order = col_orders().find_one({'order_number': order_number})
    if not order:
        return jsonify({'error': '일치하는 주문 내역이 없습니다.'}), 404

    order_phone = order.get('buyer_phone', '').replace('-', '')
    if order_phone != phone:
        return jsonify({'error': '주문자 연락처가 일치하지 않습니다.'}), 404

    return jsonify(serialize_doc(order))

# ==============================================================================
# 5. Community & Board API (Notices, Reviews, Q&A, FAQ)
# ==============================================================================
@api_bp.route('/board/notices', methods=['GET'])
def get_notices():
    notices = list(col_notices().find().sort('created_at', -1))
    return jsonify(serialize_docs(notices))

@api_bp.route('/board/notices/<notice_id>', methods=['GET'])
def get_notice_detail(notice_id):
    obj_id = to_object_id(notice_id)
    if not obj_id:
        return jsonify({'error': '유효하지 않은 공지 ID입니다.'}), 404
        
    notice = col_notices().find_one({'_id': obj_id})
    if not notice:
        return jsonify({'error': '공지사항을 찾을 수 없습니다.'}), 404

    col_notices().update_one({'_id': obj_id}, {'$inc': {'views': 1}})
    notice['views'] = notice.get('views', 0) + 1
    return jsonify(serialize_doc(notice))

@api_bp.route('/board/reviews', methods=['GET'])
def get_all_reviews():
    limit = int(request.args.get('limit', 50))
    reviews = list(col_reviews().find().sort('created_at', -1).limit(limit))
    return jsonify(serialize_docs(reviews))

@api_bp.route('/board/qna', methods=['GET'])
def get_all_qna():
    qnas = list(col_qna().find().sort('created_at', -1).limit(50))
    return jsonify(serialize_docs(qnas))

@api_bp.route('/board/faq', methods=['GET'])
def get_faq():
    faqs = [
        {
            "id": 1,
            "category": "배송",
            "question": "배송은 얼마나 걸리며 배송비는 얼마인가요?",
            "answer": "강원약초는 평일 오후 2시 이전 결제 완료 건에 한해 당일 산지에서 정성껏 포장하여 발송해 드립니다. 보통 발송 다음 날(1~2영업일) 수령 가능하며, 기본 배송비는 3,200원이고 50,000원 이상 구매 시 무료배송입니다."
        },
        {
            "id": 2,
            "category": "약초/복용",
            "question": "자연산 약초는 어떻게 보관하고 복용해야 하나요?",
            "answer": "채취 후 자연 건조된 약초는 직사광선과 습기를 피해 통풍이 잘되는 서늘한 곳이나 냉장/냉동 보관하시면 1년 이상 신선하게 유지됩니다. 각 상품 상세페이지에 상세한 끓이는 법과 권장 복용량이 안내되어 있습니다."
        },
        {
            "id": 3,
            "category": "회원혜택",
            "question": "회원 가입 혜택과 적립금 사용 기준은 어떻게 되나요?",
            "answer": "신규 회원 가입 즉시 2,000원의 쇼핑 적립금이 자동 지급됩니다. 또한 구매하실 때마다 실 결제금액의 1%가 적립되며, 적립금은 첫 주문부터 바로 현금처럼 사용 가능합니다."
        },
        {
            "id": 4,
            "category": "주문/결제",
            "question": "무통장 입금 시 확인은 언제 되나요?",
            "answer": "무통장 입금(농협은행 302-0851-0319-21 강영자) 시 30분 단위로 입금자명과 금액을 자동 대조하여 입금확인 처리됩니다. 주문자명과 실제 입금자명이 다를 경우 고객센터(033-762-8114 / 010-8638-6380)로 연락 주시면 즉시 처리해 드립니다."
        },
        {
            "id": 5,
            "category": "교환/반품",
            "question": "교환 및 반품 규정은 어떻게 되나요?",
            "answer": "식품 특성상 개봉 및 훼손 시 교환/반품이 어려우나, 제품 하자나 배송 중 파손의 경우 수령 후 7일 이내 100% 무상 교환 및 환불해 드립니다."
        }
    ]
    return jsonify(faqs)

# ==============================================================================
# 6. Admin API (Stats, Product CRUD, Order Status Update)
# ==============================================================================
@api_bp.route('/admin/stats', methods=['GET'])
@admin_required
def get_admin_stats(user):
    total_orders = col_orders().count_documents({})
    total_products = col_products().count_documents({})
    total_users = col_users().count_documents({})

    all_orders = list(col_orders().find())
    total_sales = sum(o.get('final_total', 0) for o in all_orders if o.get('status') not in ['취소', '환불'])
    pending_orders = sum(1 for o in all_orders if o.get('status') == '입금대기')

    recent_orders = list(col_orders().find().sort('created_at', -1).limit(6))

    return jsonify({
        'total_orders': total_orders,
        'total_products': total_products,
        'total_users': total_users,
        'total_sales': total_sales,
        'pending_orders': pending_orders,
        'recent_orders': serialize_docs(recent_orders)
    })

@api_bp.route('/admin/products', methods=['GET', 'POST'])
@admin_required
def admin_manage_products(user):
    if request.method == 'GET':
        products = list(col_products().find().sort('created_at', -1))
        return jsonify(serialize_docs(products))

    elif request.method == 'POST':
        data = request.get_json() or {}
        name = data.get('name', '').strip()
        category = data.get('category', '').strip()
        price = int(data.get('price', 0))

        if not name or not category or price <= 0:
            return jsonify({'error': '상품명, 카테고리, 유효한 판매가는 필수입니다.'}), 400

        doc = {
            'name': name,
            'category': category,
            'sub_category': data.get('sub_category', ''),
            'price': price,
            'original_price': int(data.get('original_price', price)),
            'origin': data.get('origin', '국산 (강원도)'),
            'weight': data.get('weight', '1박스 / 포장'),
            'stock': int(data.get('stock', 100)),
            'is_best': bool(data.get('is_best', False)),
            'is_new': bool(data.get('is_new', True)),
            'is_md': bool(data.get('is_md', False)),
            'rating': 5.0,
            'review_count': 0,
            'badge': data.get('badge', '신상품'),
            'summary': data.get('summary', ''),
            'description': data.get('description', ''),
            'image': data.get('image', '/static/images/p_mushroom_horse.jpg'),
            'images': [data.get('image', '/static/images/p_mushroom_horse.jpg')],
            'options': data.get('options', [{"name": "기본 단품", "price_diff": 0}]),
            'created_at': datetime.datetime.now()
        }

        res = col_products().insert_one(doc)
        doc['_id'] = res.inserted_id
        return jsonify({'message': '상품이 성공적으로 등록되었습니다.', 'product': serialize_doc(doc)}), 201

@api_bp.route('/admin/products/<product_id>', methods=['PUT', 'DELETE'])
@admin_required
def admin_modify_product(user, product_id):
    obj_id = to_object_id(product_id)
    if not obj_id:
        return jsonify({'error': '유효하지 않은 상품 ID입니다.'}), 404

    if request.method == 'DELETE':
        col_products().delete_one({'_id': obj_id})
        return jsonify({'message': '상품이 삭제되었습니다.'})

    elif request.method == 'PUT':
        data = request.get_json() or {}
        update_doc = {}
        for key in ['name', 'category', 'sub_category', 'origin', 'weight', 'badge', 'summary', 'description', 'image']:
            if key in data:
                update_doc[key] = data[key]
        for num_key in ['price', 'original_price', 'stock']:
            if num_key in data:
                update_doc[num_key] = int(data[num_key])
        for bool_key in ['is_best', 'is_new', 'is_md']:
            if bool_key in data:
                update_doc[bool_key] = bool(data[bool_key])
        if 'options' in data:
            update_doc['options'] = data['options']

        col_products().update_one({'_id': obj_id}, {'$set': update_doc})
        updated = col_products().find_one({'_id': obj_id})
        return jsonify({'message': '상품 정보가 수정되었습니다.', 'product': serialize_doc(updated)})

@api_bp.route('/admin/orders', methods=['GET'])
@admin_required
def admin_get_orders(user):
    orders = list(col_orders().find().sort('created_at', -1))
    return jsonify(serialize_docs(orders))

@api_bp.route('/admin/orders/<order_id>/status', methods=['PUT'])
@admin_required
def admin_update_order_status(user, order_id):
    data = request.get_json() or {}
    new_status = data.get('status', '').strip()
    
    allowed = ['입금대기', '결제완료', '상품준비중', '배송중', '배송완료', '주문취소']
    if new_status not in allowed:
        return jsonify({'error': f'올바른 주문 상태를 지정해주세요: {", ".join(allowed)}'}), 400

    query = {'$or': [{'order_number': order_id}]}
    obj_id = to_object_id(order_id)
    if obj_id:
        query['$or'].append({'_id': obj_id})

    col_orders().update_one(query, {'$set': {'status': new_status}})
    updated = col_orders().find_one(query)
    return jsonify({'message': f'주문 상태가 [{new_status}](으)로 변경되었습니다.', 'order': serialize_doc(updated)})
