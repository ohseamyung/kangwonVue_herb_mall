from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from db import col_orders, col_products, col_users, to_object_id
from config import Config
import datetime
import random
import string

order_bp = Blueprint('order', __name__, url_prefix='/order')

def generate_order_no():
    now_str = datetime.datetime.now().strftime('%Y%m%d')
    random_str = ''.join(random.choices(string.digits, k=6))
    return f"KW{now_str}-{random_str}"

@order_bp.route('/checkout')
def checkout():
    cart = session.get('cart', [])
    if not cart:
        flash('장바구니가 비어 있습니다. 주문하실 상품을 담아주세요.', 'warning')
        return redirect(url_for('main.index'))
        
    subtotal = sum(item['price'] * item['qty'] for item in cart)
    shipping_fee = 0 if subtotal >= Config.FREE_SHIPPING_THRESHOLD else Config.SHIPPING_FEE
    total = subtotal + shipping_fee
    
    # User info if logged in
    user = None
    available_points = 0
    if 'user_id' in session:
        user = col_users().find_one({'_id': to_object_id(session['user_id'])})
        if user:
            available_points = user.get('points', 0)
            
    return render_template('checkout.html',
                           cart=cart,
                           subtotal=subtotal,
                           shipping_fee=shipping_fee,
                           total=total,
                           user=user,
                           available_points=available_points,
                           config=Config)

@order_bp.route('/create', methods=['POST'])
def create():
    cart = session.get('cart', [])
    if not cart:
        flash('장바구니가 비어 있습니다.', 'danger')
        return redirect(url_for('main.index'))
        
    subtotal = sum(item['price'] * item['qty'] for item in cart)
    shipping_fee = 0 if subtotal >= Config.FREE_SHIPPING_THRESHOLD else Config.SHIPPING_FEE
    
    # Points used
    points_used = int(request.form.get('points_used', 0) or 0)
    user_id = session.get('user_id')
    user = None
    if user_id:
        user = col_users().find_one({'_id': to_object_id(user_id)})
        max_points = user.get('points', 0) if user else 0
        points_used = min(points_used, max_points, subtotal)
    else:
        points_used = 0
        
    final_total = max(0, subtotal + shipping_fee - points_used)
    
    # Earn points (1% of final product amount)
    points_earned = int(subtotal * Config.POINT_EARN_RATE) if user else 0
    
    order_no = generate_order_no()
    order_data = {
        'order_no': order_no,
        'user_id': user_id,
        'is_guest': user_id is None,
        'orderer_name': request.form.get('orderer_name', '').strip(),
        'orderer_phone': request.form.get('orderer_phone', '').strip(),
        'orderer_email': request.form.get('orderer_email', '').strip(),
        'guest_password': request.form.get('guest_password', '1234') if not user_id else '',
        'receiver_name': request.form.get('receiver_name', '').strip(),
        'receiver_phone': request.form.get('receiver_phone', '').strip(),
        'postcode': request.form.get('postcode', '').strip(),
        'address': request.form.get('address', '').strip(),
        'detail_address': request.form.get('detail_address', '').strip(),
        'delivery_msg': request.form.get('delivery_msg', '').strip(),
        'payment_method': request.form.get('payment_method', 'bank'),  # 'bank', 'card', 'kakaopay'
        'depositor_name': request.form.get('depositor_name', '').strip() or request.form.get('orderer_name', ''),
        'items': cart,
        'subtotal': subtotal,
        'shipping_fee': shipping_fee,
        'points_used': points_used,
        'points_earned': points_earned,
        'total_price': final_total,
        'status': '입금대기' if request.form.get('payment_method') == 'bank' else '결제완료',
        'created_at': datetime.datetime.now()
    }
    
    result = col_orders().insert_one(order_data)
    
    # Update user points if logged in
    if user:
        new_points = user.get('points', 0) - points_used + points_earned
        col_users().update_one({'_id': user['_id']}, {'$set': {'points': new_points}})
        
    # Clear cart
    session['cart'] = []
    session.modified = True
    
    return redirect(url_for('order.complete', order_no=order_no))

@order_bp.route('/complete/<order_no>')
def complete(order_no):
    order = col_orders().find_one({'order_no': order_no})
    if not order:
        flash('주문 정보를 찾을 수 없습니다.', 'danger')
        return redirect(url_for('main.index'))
        
    return render_template('order_complete.html', order=order, config=Config)

@order_bp.route('/lookup', methods=['GET', 'POST'])
def lookup():
    if request.method == 'POST':
        order_no = request.form.get('order_no', '').strip()
        phone_or_pw = request.form.get('phone_or_pw', '').strip()
        
        order = col_orders().find_one({'order_no': order_no})
        if order:
            if order.get('orderer_phone') == phone_or_pw or order.get('guest_password') == phone_or_pw or session.get('is_admin'):
                return redirect(url_for('order.detail_view', order_no=order_no))
            else:
                flash('주문자 연락처 또는 비밀번호가 일치하지 않습니다.', 'danger')
        else:
            flash('해당 번호의 주문 내역이 존재하지 않습니다.', 'danger')
            
    return render_template('auth/login.html', active_tab='guest', config=Config)

@order_bp.route('/detail/<order_no>')
def detail_view(order_no):
    order = col_orders().find_one({'order_no': order_no})
    if not order:
        flash('주문 정보를 찾을 수 없습니다.', 'danger')
        return redirect(url_for('main.index'))
        
    return render_template('order_detail.html', order=order, config=Config)
