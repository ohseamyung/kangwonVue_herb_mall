from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from db import col_users, col_orders, to_object_id
from config import Config
import datetime

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        user = col_users().find_one({'username': username})
        if user and check_password_hash(user['password'], password):
            session['user_id'] = str(user['_id'])
            session['username'] = user['username']
            session['user_name'] = user.get('name', user['username'])
            session['is_admin'] = user.get('is_admin', False)
            
            flash(f"반갑습니다, {user.get('name')}님!", 'success')
            next_url = request.args.get('next')
            return redirect(next_url or url_for('main.index'))
        else:
            flash('아이디 또는 비밀번호가 올바르지 않습니다.', 'danger')
            
    return render_template('auth/login.html', active_tab='member', config=Config)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        phone = request.form.get('phone', '').strip()
        
        if not username or not password or not name:
            flash('필수 입력 항목을 모두 채워주세요.', 'warning')
            return redirect(url_for('auth.register'))
            
        existing = col_users().find_one({'username': username})
        if existing:
            flash('이미 사용 중인 아이디입니다. 다른 아이디를 입력해주세요.', 'danger')
            return redirect(url_for('auth.register'))
            
        new_user = {
            'username': username,
            'password': generate_password_hash(password),
            'name': name,
            'email': email,
            'phone': phone,
            'points': Config.SIGNUP_POINT,  # 2,000 P bonus
            'is_admin': False,
            'created_at': datetime.datetime.now()
        }
        
        res = col_users().insert_one(new_user)
        session['user_id'] = str(res.inserted_id)
        session['username'] = username
        session['user_name'] = name
        session['is_admin'] = False
        
        flash(f"회원가입이 완료되었습니다! 가입 축하 적립금 {Config.SIGNUP_POINT:,}원이 지급되었습니다.", 'success')
        return redirect(url_for('main.index'))
        
    return render_template('auth/register.html', config=Config)

@auth_bp.route('/logout')
def logout():
    session.clear()
    flash('로그아웃 되었습니다.', 'info')
    return redirect(url_for('main.index'))

@auth_bp.route('/mypage')
def mypage():
    if 'user_id' not in session:
        flash('로그인이 필요한 서비스입니다.', 'warning')
        return redirect(url_for('auth.login', next=request.url))
        
    user = col_users().find_one({'_id': to_object_id(session['user_id'])})
    orders = list(col_orders().find({'user_id': session['user_id']}).sort('created_at', -1))
    
    return render_template('auth/mypage.html', user=user, orders=orders, config=Config)
