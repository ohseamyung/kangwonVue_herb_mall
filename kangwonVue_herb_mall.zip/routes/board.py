from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from db import col_notices, col_reviews, col_qna, to_object_id
from config import Config
import datetime

board_bp = Blueprint('board', __name__, url_prefix='/board')

@board_bp.route('/notice')
def notice_list():
    notices = list(col_notices().find().sort('created_at', -1))
    return render_template('boards/notice.html', notices=notices, config=Config)

@board_bp.route('/notice/<notice_id>')
def notice_detail(notice_id):
    obj_id = to_object_id(notice_id)
    notice = col_notices().find_one_and_update(
        {'_id': obj_id},
        {'$inc': {'views': 1}},
        return_document=True
    )
    if not notice:
        flash('공지사항을 찾을 수 없습니다.', 'danger')
        return redirect(url_for('board.notice_list'))
    return render_template('boards/notice_detail.html', notice=notice, config=Config)

@board_bp.route('/reviews')
def review_list():
    reviews = list(col_reviews().find().sort('created_at', -1))
    return render_template('boards/reviews.html', reviews=reviews, config=Config)

@board_bp.route('/qna')
def qna_list():
    qnas = list(col_qna().find().sort('created_at', -1))
    return render_template('boards/qna.html', qnas=qnas, config=Config)

@board_bp.route('/qna/create', methods=['POST'])
def create_qna():
    author = session.get('user_name', request.form.get('author', '고객'))
    title = request.form.get('title', '').strip()
    question = request.form.get('question', '').strip()
    is_secret = request.form.get('is_secret') == 'on'
    
    if not title or not question:
        flash('제목과 내용을 모두 작성해주세요.', 'warning')
        return redirect(url_for('board.qna_list'))
        
    col_qna().insert_one({
        'product_name': '일반 문의',
        'author': author,
        'title': title,
        'question': question,
        'is_secret': is_secret,
        'status': '답변대기',
        'answer': '',
        'created_at': datetime.datetime.now()
    })
    flash('문의가 성공적으로 접수되었습니다.', 'success')
    return redirect(url_for('board.qna_list'))
