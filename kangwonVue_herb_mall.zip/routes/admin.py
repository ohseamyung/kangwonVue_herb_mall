from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from db import col_products, col_orders, col_categories, col_users, col_qna, to_object_id
from config import Config
import datetime

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('is_admin'):
            flash('관리자 권한이 필요합니다.', 'danger')
            return redirect(url_for('auth.login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/')
@admin_required
def dashboard():
    total_sales = sum(o.get('total_price', 0) for o in col_orders().find())
    total_orders = col_orders().count_documents({})
    pending_orders = col_orders().count_documents({'status': '입금대기'})
    total_products = col_products().count_documents({})
    total_users = col_users().count_documents({})
    
    recent_orders = list(col_orders().find().sort('created_at', -1).limit(10))
    pending_qnas = list(col_qna().find({'status': '답변대기'}).sort('created_at', -1).limit(5))
    
    return render_template('admin/dashboard.html',
                           total_sales=total_sales,
                           total_orders=total_orders,
                           pending_orders=pending_orders,
                           total_products=total_products,
                           total_users=total_users,
                           recent_orders=recent_orders,
                           pending_qnas=pending_qnas,
                           config=Config)

@admin_bp.route('/products')
@admin_required
def products():
    prods = list(col_products().find().sort('created_at', -1))
    return render_template('admin/products.html', products=prods, config=Config)

@admin_bp.route('/product/new', methods=['GET', 'POST'])
@admin_required
def product_new():
    categories = list(col_categories().find().sort('order', 1))
    if request.method == 'POST':
        name = request.form.get('name')
        category = request.form.get('category')
        price = int(request.form.get('price', 0))
        original_price = int(request.form.get('original_price', 0) or price)
        origin = request.form.get('origin', '국산 (강원도)')
        weight = request.form.get('weight', '')
        stock = int(request.form.get('stock', 50))
        image = request.form.get('image', '/static/images/p_herb_dangui.jpg')
        badge = request.form.get('badge', '')
        summary = request.form.get('summary', '')
        description = request.form.get('description', '')
        is_best = request.form.get('is_best') == 'on'
        is_md = request.form.get('is_md') == 'on'
        is_new = request.form.get('is_new') == 'on'
        
        col_products().insert_one({
            'name': name,
            'category': category,
            'price': price,
            'original_price': original_price,
            'origin': origin,
            'weight': weight,
            'stock': stock,
            'image': image,
            'badge': badge,
            'summary': summary,
            'description': description,
            'is_best': is_best,
            'is_md': is_md,
            'is_new': is_new,
            'rating': 5.0,
            'review_count': 0,
            'options': [{'name': '기본 상품', 'price_diff': 0}],
            'created_at': datetime.datetime.now()
        })
        flash('새 상품이 성공적으로 등록되었습니다.', 'success')
        return redirect(url_for('admin.products'))
        
    return render_template('admin/product_form.html', categories=categories, product=None, config=Config)

@admin_bp.route('/product/edit/<product_id>', methods=['GET', 'POST'])
@admin_required
def product_edit(product_id):
    obj_id = to_object_id(product_id)
    product = col_products().find_one({'_id': obj_id})
    categories = list(col_categories().find().sort('order', 1))
    
    if request.method == 'POST':
        update_data = {
            'name': request.form.get('name'),
            'category': request.form.get('category'),
            'price': int(request.form.get('price', 0)),
            'original_price': int(request.form.get('original_price', 0)),
            'origin': request.form.get('origin'),
            'weight': request.form.get('weight'),
            'stock': int(request.form.get('stock', 0)),
            'image': request.form.get('image'),
            'badge': request.form.get('badge'),
            'summary': request.form.get('summary'),
            'description': request.form.get('description'),
            'is_best': request.form.get('is_best') == 'on',
            'is_md': request.form.get('is_md') == 'on',
            'is_new': request.form.get('is_new') == 'on',
        }
        col_products().update_one({'_id': obj_id}, {'$set': update_data})
        flash('상품 정보가 수정되었습니다.', 'success')
        return redirect(url_for('admin.products'))
        
    return render_template('admin/product_form.html', categories=categories, product=product, config=Config)

@admin_bp.route('/product/delete/<product_id>', methods=['POST'])
@admin_required
def product_delete(product_id):
    obj_id = to_object_id(product_id)
    col_products().delete_one({'_id': obj_id})
    flash('상품이 삭제되었습니다.', 'info')
    return redirect(url_for('admin.products'))

@admin_bp.route('/orders')
@admin_required
def orders():
    status_filter = request.args.get('status')
    query = {}
    if status_filter:
        query['status'] = status_filter
    order_list = list(col_orders().find(query).sort('created_at', -1))
    return render_template('admin/orders.html', orders=order_list, current_status=status_filter, config=Config)

@admin_bp.route('/order/status/<order_id>', methods=['POST'])
@admin_required
def order_status_update(order_id):
    obj_id = to_object_id(order_id)
    new_status = request.form.get('status')
    if new_status:
        col_orders().update_one({'_id': obj_id}, {'$set': {'status': new_status}})
        flash(f'주문 상태가 [{new_status}](으)로 변경되었습니다.', 'success')
    return redirect(request.referrer or url_for('admin.orders'))

@admin_bp.route('/qna/answer/<qna_id>', methods=['POST'])
@admin_required
def qna_answer(qna_id):
    obj_id = to_object_id(qna_id)
    answer = request.form.get('answer', '').strip()
    if answer:
        col_qna().update_one(
            {'_id': obj_id},
            {'$set': {'answer': answer, 'status': '답변완료', 'answered_at': datetime.datetime.now()}}
        )
        flash('답변이 등록되었습니다.', 'success')
    return redirect(url_for('admin.dashboard'))
