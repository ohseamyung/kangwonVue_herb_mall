from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from db import col_products, to_object_id
from config import Config

cart_bp = Blueprint('cart', __name__, url_prefix='/cart')

def get_cart_items():
    if 'cart' not in session:
        session['cart'] = []
    return session['cart']

def calculate_cart_totals(cart):
    subtotal = sum(item['price'] * item['qty'] for item in cart)
    shipping_fee = 0 if subtotal >= Config.FREE_SHIPPING_THRESHOLD or subtotal == 0 else Config.SHIPPING_FEE
    total = subtotal + shipping_fee
    return subtotal, shipping_fee, total

@cart_bp.route('/')
def view_cart():
    cart = get_cart_items()
    subtotal, shipping_fee, total = calculate_cart_totals(cart)
    free_shipping_gap = max(0, Config.FREE_SHIPPING_THRESHOLD - subtotal)
    
    return render_template('cart.html',
                           cart=cart,
                           subtotal=subtotal,
                           shipping_fee=shipping_fee,
                           total=total,
                           free_shipping_gap=free_shipping_gap,
                           config=Config)

@cart_bp.route('/add', methods=['POST'])
def add():
    product_id = request.form.get('product_id')
    qty = int(request.form.get('qty', 1))
    option_name = request.form.get('option', '')
    action = request.form.get('action', 'cart')  # 'cart' or 'buy_now'
    
    obj_id = to_object_id(product_id)
    if not obj_id:
        return jsonify({'success': False, 'message': '잘못된 상품입니다.'}), 400
        
    product = col_products().find_one({'_id': obj_id})
    if not product:
        return jsonify({'success': False, 'message': '상품을 찾을 수 없습니다.'}), 404
        
    cart = get_cart_items()
    
    # Calculate price based on option
    base_price = product.get('price', 0)
    option_price_diff = 0
    if option_name and 'options' in product:
        for opt in product['options']:
            if opt['name'] == option_name:
                option_price_diff = opt.get('price_diff', 0)
                break
                
    unit_price = base_price + option_price_diff
    
    # Check if item exists in cart
    existing = False
    for item in cart:
        if item['product_id'] == str(obj_id) and item.get('option') == option_name:
            item['qty'] += qty
            existing = True
            break
            
    if not existing:
        cart.append({
            'product_id': str(obj_id),
            'name': product.get('name'),
            'price': unit_price,
            'image': product.get('image', '/static/images/no_image.jpg'),
            'option': option_name,
            'qty': qty,
            'origin': product.get('origin', '')
        })
        
    session['cart'] = cart
    session.modified = True
    
    if action == 'buy_now':
        return redirect(url_for('order.checkout'))
        
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.is_json:
        return jsonify({
            'success': True,
            'message': '장바구니에 상품이 담겼습니다.',
            'cart_count': sum(i['qty'] for i in cart)
        })
        
    flash(f"'{product.get('name')}' 상품이 장바구니에 담겼습니다.", 'success')
    return redirect(url_for('cart.view_cart'))

@cart_bp.route('/update', methods=['POST'])
def update():
    index = int(request.form.get('index', -1))
    qty = int(request.form.get('qty', 1))
    
    cart = get_cart_items()
    if 0 <= index < len(cart):
        if qty > 0:
            cart[index]['qty'] = qty
        else:
            cart.pop(index)
        session['cart'] = cart
        session.modified = True
        
    return redirect(url_for('cart.view_cart'))

@cart_bp.route('/delete/<int:index>', methods=['POST', 'GET'])
def delete(index):
    cart = get_cart_items()
    if 0 <= index < len(cart):
        cart.pop(index)
        session['cart'] = cart
        session.modified = True
        flash('선택하신 상품이 장바구니에서 삭제되었습니다.', 'info')
    return redirect(url_for('cart.view_cart'))

@cart_bp.route('/clear', methods=['POST', 'GET'])
def clear():
    session['cart'] = []
    session.modified = True
    flash('장바구니가 비워졌습니다.', 'info')
    return redirect(url_for('cart.view_cart'))
