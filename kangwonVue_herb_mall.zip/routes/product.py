from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from db import col_products, col_reviews, col_qna, to_object_id
from config import Config
import datetime

product_bp = Blueprint('product', __name__, url_prefix='/product')

@product_bp.route('/<product_id>')
def detail(product_id):
    obj_id = to_object_id(product_id)
    if not obj_id:
        flash('존재하지 않는 상품입니다.', 'danger')
        return redirect(url_for('main.index'))
        
    product = col_products().find_one({'_id': obj_id})
    if not product:
        flash('상품 정보를 찾을 수 없습니다.', 'danger')
        return redirect(url_for('main.index'))
        
    # Related products in same category
    related_products = list(col_products().find({
        'category': product.get('category'),
        '_id': {'$ne': obj_id}
    }).limit(4))
    
    # Reviews and Q&As for this product
    reviews = list(col_reviews().find({'product_name': product.get('name')}).sort('created_at', -1))
    qnas = list(col_qna().find().sort('created_at', -1).limit(5))
    
    return render_template('product_detail.html',
                           product=product,
                           related_products=related_products,
                           reviews=reviews,
                           qnas=qnas,
                           config=Config)

@product_bp.route('/<product_id>/review', methods=['POST'])
def add_review(product_id):
    obj_id = to_object_id(product_id)
    product = col_products().find_one({'_id': obj_id})
    if not product:
        flash('상품 정보를 찾을 수 없습니다.', 'danger')
        return redirect(url_for('main.index'))
        
    author = session.get('user_name', request.form.get('author', '고객'))
    rating = int(request.form.get('rating', 5))
    title = request.form.get('title', '').strip()
    content = request.form.get('content', '').strip()
    
    if not content:
        flash('후기 내용을 입력해주세요.', 'warning')
        return redirect(url_for('product.detail', product_id=product_id))
        
    col_reviews().insert_one({
        'product_name': product.get('name'),
        'product_id': str(obj_id),
        'author': author,
        'rating': rating,
        'title': title or content[:20],
        'content': content,
        'created_at': datetime.datetime.now()
    })
    
    # Update product review count
    col_products().update_one({'_id': obj_id}, {'$inc': {'review_count': 1}})
    
    flash('소중한 구매후기가 등록되었습니다!', 'success')
    return redirect(url_for('product.detail', product_id=product_id) + '#tab-review')

@product_bp.route('/<product_id>/qna', methods=['POST'])
def add_qna(product_id):
    obj_id = to_object_id(product_id)
    product = col_products().find_one({'_id': obj_id})
    
    author = session.get('user_name', request.form.get('author', '고객'))
    title = request.form.get('title', '').strip()
    question = request.form.get('question', '').strip()
    is_secret = request.form.get('is_secret') == 'on'
    
    if not title or not question:
        flash('제목과 문의 내용을 모두 입력해주세요.', 'warning')
        return redirect(url_for('product.detail', product_id=product_id))
        
    col_qna().insert_one({
        'product_name': product.get('name') if product else '상품 문의',
        'product_id': str(obj_id) if obj_id else '',
        'author': author,
        'title': title,
        'question': question,
        'is_secret': is_secret,
        'status': '답변대기',
        'answer': '',
        'created_at': datetime.datetime.now()
    })
    
    flash('상품 문의가 등록되었습니다. 빠른 시일 내에 답변드리겠습니다.', 'success')
    return redirect(url_for('product.detail', product_id=product_id) + '#tab-qna')
