import os
from flask import Flask, render_template, session, send_from_directory, redirect
from flask_cors import CORS
from config import Config
from db import col_categories, col_users, to_object_id
from routes.main import main_bp
from routes.product import product_bp
from routes.cart import cart_bp
from routes.order import order_bp
from routes.auth import auth_bp
from routes.board import board_bp
from routes.admin import admin_bp
from routes.api import api_bp

def create_app():
    frontend_dist = os.path.join(os.path.dirname(__file__), 'frontend', 'dist')
    
    app = Flask(
        __name__,
        static_folder='static',
        static_url_path='/static'
    )
    app.config.from_object(Config)

    # Enable CORS for all routes (especially /api/*)
    CORS(app, resources={r"/api/*": {"origins": "*"}})

    # Register REST API blueprint
    app.register_blueprint(api_bp)

    # Register legacy SSR blueprints
    app.register_blueprint(main_bp)
    app.register_blueprint(product_bp)
    app.register_blueprint(cart_bp)
    app.register_blueprint(order_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(board_bp)
    app.register_blueprint(admin_bp)

    # Vue SPA production build serving
    if os.path.exists(frontend_dist):
        @app.route('/')
        def index_redirect():
            return redirect('/vue/')

        @app.route('/vue/', defaults={'path': ''})
        @app.route('/vue/<path:path>')
        def serve_vue_spa(path):
            if path != "" and os.path.exists(os.path.join(frontend_dist, path)):
                return send_from_directory(frontend_dist, path)
            else:
                return send_from_directory(frontend_dist, 'index.html')

    # Jinja template filters
    @app.template_filter('currency')
    def currency_filter(value):
        try:
            return f"{int(value):,}원"
        except (ValueError, TypeError):
            return "0원"

    @app.template_filter('date')
    def date_filter(value, format='%Y.%m.%d'):
        if not value:
            return ''
        if hasattr(value, 'strftime'):
            return value.strftime(format)
        return str(value)

    @app.template_filter('discount_rate')
    def discount_filter(original, current):
        try:
            if original and original > current:
                rate = int(round((original - current) / original * 100))
                return f"{rate}%"
        except Exception:
            pass
        return ""

    # Global context processor
    @app.context_processor
    def inject_globals():
        try:
            categories = list(col_categories().find().sort('order', 1))
        except Exception:
            categories = []
            
        cart = session.get('cart', [])
        cart_count = sum(item.get('qty', 1) for item in cart)
        
        current_user = None
        if 'user_id' in session:
            try:
                current_user = col_users().find_one({'_id': to_object_id(session['user_id'])})
            except Exception:
                pass
                
        return {
            'global_categories': categories,
            'cart_count': cart_count,
            'current_user': current_user,
            'config': Config
        }

    @app.errorhandler(404)
    def not_found(e):
        return render_template('404.html', config=Config), 404

    @app.errorhandler(500)
    def server_error(e):
        return render_template('500.html', config=Config), 500

    return app

app = create_app()

if __name__ == '__main__':
    print("==================================================")
    print("  강원약초 (kangwons.com) 쇼핑몰 백엔드 서버 시작")
    print("  접속 주소: http://127.0.0.1:5000")
    print("  REST API: http://127.0.0.1:5000/api")
    print("  관리자 계정: admin / admin1234")
    print("  테스트 회원: testuser / 1234")
    print("==================================================")
    app.run(host='0.0.0.0', port=5000, debug=True)
