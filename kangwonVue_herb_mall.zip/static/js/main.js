// Main Interactive JavaScript for Kangwon Herb Mall

document.addEventListener('DOMContentLoaded', function() {
    console.log('강원약초 쇼핑몰이 준비되었습니다.');

    // Auto-dismiss alerts after 4 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert-dismissible');
        alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 4000);

    // Dropdown hover handling for desktop
    const categoryDropdown = document.querySelector('.main-nav .dropdown');
    if (categoryDropdown && window.innerWidth >= 768) {
        const dropdownBtn = categoryDropdown.querySelector('.dropdown-toggle');
        const dropdownMenu = categoryDropdown.querySelector('.dropdown-menu');

        categoryDropdown.addEventListener('mouseenter', function() {
            dropdownMenu.classList.add('show');
            dropdownBtn.setAttribute('aria-expanded', 'true');
        });

        categoryDropdown.addEventListener('mouseleave', function() {
            dropdownMenu.classList.remove('show');
            dropdownBtn.setAttribute('aria-expanded', 'false');
        });
    }
});

