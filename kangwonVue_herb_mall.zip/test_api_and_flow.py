import unittest
import json
from app import app
from db import get_db, col_users, col_products, col_orders

class TestKangwonMallAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = app.test_client()

    def test_01_config_and_banners(self):
        res = self.client.get('/api/config')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data['store_name'], '강원약초')
        self.assertEqual(data['free_shipping_threshold'], 50000)
        self.assertEqual(data['signup_point'], 2000)
        print("[PASS] Config endpoint verified: store_name = 강원약초")

        res2 = self.client.get('/api/banners')
        self.assertEqual(res2.status_code, 200)
        banners = res2.get_json()
        self.assertGreaterEqual(len(banners), 1)
        print(f"[PASS] Banners verified: {len(banners)} banners loaded")

    def test_02_categories_and_products(self):
        res = self.client.get('/api/categories')
        self.assertEqual(res.status_code, 200)
        cats = res.get_json()
        self.assertGreaterEqual(len(cats), 10)
        print(f"[PASS] Categories verified: {len(cats)} categories")

        res_p = self.client.get('/api/products?limit=5')
        self.assertEqual(res_p.status_code, 200)
        prods = res_p.get_json()
        self.assertGreaterEqual(len(prods['products']), 5)
        
        # Test product detail
        sample_id = prods['products'][0]['id']
        res_d = self.client.get(f'/api/products/{sample_id}')
        self.assertEqual(res_d.status_code, 200)
        detail = res_d.get_json()
        self.assertIn('product', detail)
        self.assertIn('related', detail)
        print(f"[PASS] Product detail verified: {detail['product']['name']}")

    def test_03_auth_register_and_login(self):
        # Register test user
        import random
        rand_id = random.randint(1000, 9999)
        test_username = f"user_{rand_id}"
        reg_payload = {
            "username": test_username,
            "password": "password123",
            "name": f"홍길동_{rand_id}",
            "phone": "010-1234-5678",
            "email": f"test_{rand_id}@example.com",
            "address": "강원특별자치도 원주시"
        }
        res_reg = self.client.post('/api/auth/register', json=reg_payload)
        self.assertEqual(res_reg.status_code, 201)
        reg_data = res_reg.get_json()
        self.assertIn('token', reg_data)
        self.assertEqual(reg_data['user']['points'], 2000)
        print(f"[PASS] Register verified: +2000P awarded to {test_username}")

        # Login test
        res_login = self.client.post('/api/auth/login', json={
            "username": test_username,
            "password": "password123"
        })
        self.assertEqual(res_login.status_code, 200)
        login_data = res_login.get_json()
        token = login_data['token']

        # Get Me
        res_me = self.client.get('/api/auth/me', headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(res_me.status_code, 200)
        me_data = res_me.get_json()
        self.assertEqual(me_data['username'], test_username)
        print(f"[PASS] Login & Me verified with JWT token for {test_username}")

    def test_04_order_creation_and_lookup(self):
        # 1. Admin login
        res_adm = self.client.post('/api/auth/login', json={
            "username": "admin",
            "password": "admin1234"
        })
        admin_token = res_adm.get_json()['token']

        # 2. Place an order
        order_payload = {
            "items": [
                {
                    "product_id": "test_p1",
                    "name": "(강원약초) 국산 자연산 말굽버섯 300g",
                    "option_name": "300g (기본)",
                    "price": 65000,
                    "qty": 1,
                    "image": "/static/images/p_mushroom_horse.jpg"
                }
            ],
            "buyer_name": "김주문",
            "buyer_phone": "010-9876-5432",
            "buyer_email": "order@test.com",
            "recipient_name": "김수령",
            "recipient_phone": "010-9876-5432",
            "recipient_postcode": "26323",
            "shipping_address": "강원특별자치도 춘천시 중앙로 1",
            "shipping_memo": "문 앞에 놓아주세요",
            "payment_method": "bank_transfer",
            "used_points": 0
        }
        res_ord = self.client.post('/api/orders', json=order_payload)
        self.assertEqual(res_ord.status_code, 201)
        ord_data = res_ord.get_json()['order']
        order_number = ord_data['order_number']
        self.assertEqual(ord_data['shipping_fee'], 0) # 65,000 >= 50,000 -> Free shipping
        print(f"[PASS] Order created successfully: {order_number} (Free shipping applied)")

        # 3. Non-member order lookup
        res_lookup = self.client.post('/api/orders/lookup', json={
            "order_number": order_number,
            "phone": "010-9876-5432"
        })
        self.assertEqual(res_lookup.status_code, 200)
        lookup_data = res_lookup.get_json()
        self.assertEqual(lookup_data['order_number'], order_number)
        print(f"[PASS] Guest order lookup verified: {order_number}")

        # 4. Admin status update
        res_status = self.client.put(
            f'/api/admin/orders/{order_number}/status',
            headers={"Authorization": f"Bearer {admin_token}"},
            json={"status": "배송완료"}
        )
        self.assertEqual(res_status.status_code, 200)
        self.assertEqual(res_status.get_json()['order']['status'], '배송완료')
        print(f"[PASS] Admin order status updated to '배송완료'")

    def test_05_vue_spa_served(self):
        res = self.client.get('/vue/')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'<div id="app"></div>', res.data)
        print("[PASS] Vue SPA client-side bundle served at /vue/ with status 200")

if __name__ == '__main__':
    unittest.main()
