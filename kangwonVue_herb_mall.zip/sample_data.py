import datetime
from db import get_db, col_products, col_categories, col_users, col_notices, col_reviews, col_qna, col_banners
from werkzeug.security import generate_password_hash

def seed_database():
    db = get_db()
    print("Seeding database...")
    
    # 1. Categories
    categories = [
        {"slug": "nature-herbs", "name": "건강식품 자연약초", "icon": "fa-leaf", "order": 1, "desc": "강원도 청정 고지대에서 자생하는 자연산 토종 약초"},
        {"slug": "rare-herbs", "name": "희귀 자연산약초", "icon": "fa-seedling", "order": 2, "desc": "깊은 산속에서 심마니가 직접 채취한 귀한 약초"},
        {"slug": "liquid-extract", "name": "수제 건강 액기스즙", "icon": "fa-flask", "order": 3, "desc": "원적외선 저온 48시간 추출 순수 무첨가 프리미엄 진액"},
        {"slug": "herb-sets", "name": "건강식품 약초 셋트", "icon": "fa-box-open", "order": 4, "desc": "한방 처방에 맞춘 균형 잡힌 약초 구성 세트"},
        {"slug": "ssanghwa-tea", "name": "쌍화차재료", "icon": "fa-mug-hot", "order": 5, "desc": "전통 비법 10가지 천연 약재 황금비율 구성"},
        {"slug": "sipjeon-tea", "name": "십전대보차 셋트", "icon": "fa-mortar-pestle", "order": 6, "desc": "기혈을 보하는 11가지 최고급 약재 세트"},
        {"slug": "wild-mushrooms", "name": "자연산 버섯", "icon": "fa-tree", "order": 7, "desc": "말굽버섯, 영지버섯, 차가버섯, 상황버섯 등 야생 버섯"},
        {"slug": "wild-ginseng", "name": "산 양 산 삼", "icon": "fa-spa", "order": 8, "desc": "강원도 평창 600고지 무농약 인증 8년근 이상 산양산삼"},
        {"slug": "magamok", "name": "마가목 특산품", "icon": "fa-apple-alt", "order": 9, "desc": "강원도 정선 고지대 야생 마가목 껍질 및 열매 진액"},
        {"slug": "best-items", "name": "BEST 인기상품", "icon": "fa-award", "order": 10, "desc": "강원약초 고객님들이 가장 많이 재구매하시는 명품"}
    ]
    
    col_categories().delete_many({})
    col_categories().insert_many(categories)
    print(f"Inserted {len(categories)} categories.")
    
    # 2. Banners
    banners = [
        {
            "title": "강원도 청정 자연의 숨결, 100% 자연산 토종약초",
            "subtitle": "해발 600m 이상 강원도 고지대에서 정성껏 채취한 산지직송 건강",
            "bg_color": "#1c3d27",
            "tag": "산지직송",
            "link": "/category/nature-herbs",
            "button_text": "자연산 약초 보러가기"
        },
        {
            "title": "48시간 저온추출 수제 마가목·민들레 진액즙",
            "subtitle": "인공첨가물 0%! 순수 원적외선 특수추출로 깊은 맛과 영양을 그대로",
            "bg_color": "#2c261e",
            "tag": "프리미엄 엑기스",
            "link": "/category/liquid-extract",
            "button_text": "수제 진액즙 보기"
        },
        {
            "title": "전통 비법 그대로, 수제 쌍화차 & 십전대보차 세트",
            "subtitle": "엄선된 10~11가지 최고급 약재로 집에서 간편하게 달여 마시는 보약",
            "bg_color": "#382314",
            "tag": "건강선물세트",
            "link": "/category/ssanghwa-tea",
            "button_text": "한방차 세트 보기"
        }
    ]
    col_banners().delete_many({})
    col_banners().insert_many(banners)
    print(f"Inserted {len(banners)} banners.")

    # 3. Products
    products = [
        {
            "name": "(강원약초) 국산 자연산 말굽버섯 300g",
            "category": "wild-mushrooms",
            "sub_category": "자연산 버섯",
            "price": 65000,
            "original_price": 75000,
            "origin": "국산 (강원도 인제/홍천)",
            "weight": "300g (건조)",
            "stock": 45,
            "is_best": True,
            "is_new": False,
            "is_md": True,
            "rating": 4.9,
            "review_count": 86,
            "badge": "HIT",
            "summary": "강원도 야생 고산지대 활엽수에서 채취한 단단하고 향이 깊은 최상품 말굽버섯",
            "description": """
                <h3>[강원도 심마니가 직접 채취한 명품 말굽버섯]</h3>
                <p>말굽버섯은 고산지대 단풍나무, 자작나무 등 활엽수의 고목에 자생하는 귀한 야생 버섯입니다.</p>
                <p>일체의 화학처리나 방부제 없이 자연 그대로 채취 후 햇빛과 바람에 정성껏 자연 건조하였습니다.</p>
                <br>
                <h4>■ 복용법 및 차 끓이는 방법</h4>
                <ul>
                    <li>말굽버섯 약 20~30g을 흐르는 물에 가볍게 씻어줍니다.</li>
                    <li>생수 2L에 버섯을 넣고 센 불로 끓이다가 끓기 시작하면 약불로 줄여 1~2시간 정도 은근히 달입니다.</li>
                    <li>달인 물은 냉장 보관하시며 하루 2~3회 따뜻하게 음용하십시오. (대추나 감초를 곁들이면 더욱 좋습니다)</li>
                </ul>
            """,
            "image": "/static/images/p_mushroom_horse.jpg",
            "images": ["/static/images/p_mushroom_horse.jpg"],
            "options": [
                {"name": "300g (기본)", "price_diff": 0},
                {"name": "600g (실속형)", "price_diff": 58000},
                {"name": "1kg (대용량 박스)", "price_diff": 120000}
            ],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "강원도 자연산 마가목껍질 진액 60봉 (100ml)",
            "category": "liquid-extract",
            "sub_category": "수제 건강 액기스즙",
            "price": 85000,
            "original_price": 98000,
            "origin": "국산 (강원도 정선 100%)",
            "weight": "100ml x 60포",
            "stock": 38,
            "is_best": True,
            "is_new": True,
            "is_md": True,
            "rating": 5.0,
            "review_count": 124,
            "badge": "BEST",
            "summary": "강원도 정선 자연산 마가목 껍질 100% 무첨가, 원적외선 48시간 저온 추출",
            "description": """
                <h3>[정선 고지대 자연산 마가목 껍질 100% 수제 진액]</h3>
                <p>강원도 높은 산에서 거센 비바람과 혹독한 겨울을 견뎌낸 야생 마가목의 껍질만을 정성껏 채취하였습니다.</p>
                <p>물 이외의 어떤 방부제, 색소, 설탕 등 첨가물을 전혀 넣지 않고 48시간 저온 원적외선 방식으로 달여내어 마가목 고유의 진한 풍미와 유효 성분을 온전히 담았습니다.</p>
                <br>
                <h4>■ 섭취 방법</h4>
                <p>성인 기준 1일 2~3회, 1회 1포씩 식전 또는 식후에 따뜻하게 데워 드시면 좋습니다.</p>
            """,
            "image": "/static/images/p_extract_magamok.jpg",
            "images": ["/static/images/p_extract_magamok.jpg"],
            "options": [
                {"name": "60봉 (1박스 - 1개월분)", "price_diff": 0},
                {"name": "120봉 (2박스 - 2개월분 특가)", "price_diff": 75000}
            ],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "전통 수제 쌍화차 재료 10가지 1,100g (황금배합)",
            "category": "ssanghwa-tea",
            "sub_category": "쌍화차재료",
            "price": 42000,
            "original_price": 48000,
            "origin": "국산 약재 8종 + 최상급 정식통관 2종",
            "weight": "1,100g (약 40~50회분)",
            "stock": 60,
            "is_best": True,
            "is_new": False,
            "is_md": True,
            "rating": 4.9,
            "review_count": 215,
            "badge": "인기",
            "summary": "작약, 당귀, 천궁, 숙지황, 황기, 갈근 등 10가지 엄선 약재로 집에서 직접 끓이는 전통 쌍화차",
            "description": """
                <h3>[정통 비법으로 구성한 명품 쌍화차 10선]</h3>
                <p>가족의 건강과 원기 회복을 위해 최고 등급의 작약, 당귀, 천궁, 황기, 숙지황 등 10가지 약재를 황금 비율로 소분 포장하였습니다.</p>
                <br>
                <h4>■ 구성 약재</h4>
                <p>백작약, 참당귀, 천궁, 숙지황, 황기, 육계(계피), 감초, 갈근, 대추, 생강편 (총 10가지 1,100g)</p>
                <br>
                <h4>■ 맛있게 달이는 법</h4>
                <p>물 4~5L에 재료를 넣고 끓이다가 끓어오르면 약불에서 2시간 정도 푹 달여 드세요. 기호에 따라 꿀이나 잣을 띄워 드시면 더욱 훌륭합니다.</p>
            """,
            "image": "/static/images/p_tea_ssanghwa.jpg",
            "images": ["/static/images/p_tea_ssanghwa.jpg"],
            "options": [
                {"name": "1세트 (1,100g)", "price_diff": 0},
                {"name": "2세트 (무료배송 + 한방부직포백 증정)", "price_diff": 39000}
            ],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "강원도 평창 산양산삼 8년근 (5뿌리 / 이끼목함 포장)",
            "category": "wild-ginseng",
            "sub_category": "산 양 산 삼",
            "price": 135000,
            "original_price": 160000,
            "origin": "강원도 평창 해발 650m",
            "weight": "5뿌리 (고급 삼베 이끼목함 포장)",
            "stock": 18,
            "is_best": True,
            "is_new": True,
            "is_md": True,
            "rating": 5.0,
            "review_count": 48,
            "badge": "명품",
            "summary": "평창 고지대 청정 삼림에서 농약 없이 8년간 자연 그대로 자라난 무농약 인증 최상품 산양산삼",
            "description": """
                <h3>[강원도 평창 650고지 자연 생육 8년근 산양산삼]</h3>
                <p>강원도 평창의 깊은 산자락에서 천혜의 기운을 받고 자란 8년근 산양산삼입니다.</p>
                <p>뇌두가 또렷하고 주름이 조밀하며 미삼(뿌리)이 탄탄하여 사포닌 함량이 매우 풍부합니다.</p>
                <p>소중한 분께 드리는 최고의 건강 선물로 고급 원목함에 신선한 생이끼를 담아 안전하게 우체국 택배로 배송됩니다.</p>
                <br>
                <h4>■ 섭취 및 보관 요령</h4>
                <p>수령 후 냉장 보관하시고, 아침 공복에 뇌두를 떼어낸 후 미세한 뿌리부터 10~15분 이상 꼭꼭 씹어 침으로 삼키시면 흡수율이 극대화됩니다.</p>
            """,
            "image": "/static/images/p_ginseng_wild.jpg",
            "images": ["/static/images/p_ginseng_wild.jpg"],
            "options": [
                {"name": "8년근 5뿌리 (목함 포장)", "price_diff": 0},
                {"name": "8년근 7뿌리 (특선 목함)", "price_diff": 50000},
                {"name": "10년근 대물 5뿌리 (한정 수량)", "price_diff": 110000}
            ],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "전통 십전대보차 재료 11가지 세트 1,200g",
            "category": "sipjeon-tea",
            "sub_category": "십전대보차 셋트",
            "price": 48000,
            "original_price": 55000,
            "origin": "국산 9종 + 통관 약재 2종",
            "weight": "1,200g",
            "stock": 50,
            "is_best": False,
            "is_new": False,
            "is_md": True,
            "rating": 4.8,
            "review_count": 92,
            "badge": "추천",
            "summary": "사물탕(당귀, 천궁, 백작약, 숙지황)과 사군자탕(인삼/황기, 백출, 백복령, 감초)에 육계, 대추를 더한 완성형 보차",
            "description": """
                <h3>[몸의 온기와 기력을 북돋는 전통 십전대보차 11선]</h3>
                <p>기(氣)와 혈(血)을 모두 보하는 대표적인 한방 처방의 비율 그대로 엄선된 최상급 원료만을 담았습니다.</p>
            """,
            "image": "/static/images/p_tea_sipjeon.jpg",
            "images": ["/static/images/p_tea_sipjeon.jpg"],
            "options": [{"name": "1세트 (1,200g)", "price_diff": 0}],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "강원도 진부 참당귀 300g (GAP 인증/특상품)",
            "category": "nature-herbs",
            "sub_category": "건강식품 자연약초",
            "price": 28000,
            "original_price": 32000,
            "origin": "강원도 평창 진부면 100%",
            "weight": "300g",
            "stock": 70,
            "is_best": True,
            "is_new": False,
            "is_md": False,
            "rating": 4.9,
            "review_count": 133,
            "badge": "GAP인증",
            "summary": "향이 진하고 육질이 단단한 강원도 진부 고랭지 햇 당귀",
            "description": "<p>여성 건강과 혈액 순환의 대표 약초 강원도 진부 참당귀입니다. GAP 우수농산물 인증을 획득하였습니다.</p>",
            "image": "/static/images/p_herb_dangui.jpg",
            "images": ["/static/images/p_herb_dangui.jpg"],
            "options": [{"name": "300g", "price_diff": 0}, {"name": "600g", "price_diff": 25000}],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "국산 자연산 쇠무릎 우슬 뿌리 300g (1등급 햇우슬)",
            "category": "nature-herbs",
            "sub_category": "건강식품 자연약초",
            "price": 25000,
            "original_price": 29000,
            "origin": "국산 (강원도/충북)",
            "weight": "300g",
            "stock": 85,
            "is_best": True,
            "is_new": False,
            "is_md": True,
            "rating": 4.9,
            "review_count": 178,
            "badge": "관절인기",
            "summary": "소의 무릎을 닮아 관절 건강에 으뜸인 야생 우슬 뿌리 저온 건조 최상품",
            "description": "<p>청정 자연에서 채취한 자연산 우슬 뿌리입니다. 닭발이나 두충과 함께 달여 드시면 관절에 탁월합니다.</p>",
            "image": "/static/images/p_herb_wooseul.jpg",
            "images": ["/static/images/p_herb_wooseul.jpg"],
            "options": [{"name": "300g", "price_diff": 0}, {"name": "600g", "price_diff": 22000}],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "국산 토종 민들레즙 60봉 (100ml / 전초 100%)",
            "category": "liquid-extract",
            "sub_category": "수제 건강 액기스즙",
            "price": 75000,
            "original_price": 85000,
            "origin": "국산 토종 흰민들레·노란민들레 100%",
            "weight": "100ml x 60포",
            "stock": 35,
            "is_best": False,
            "is_new": True,
            "is_md": False,
            "rating": 4.8,
            "review_count": 64,
            "badge": "NEW",
            "summary": "청정지역 민들레 잎과 뿌리를 통째로 원적외선 저온 48시간 추출",
            "description": "<p>간 건강과 소화기에 좋은 토종 민들레의 유효성분을 고스란히 담아낸 수제 진액입니다.</p>",
            "image": "/static/images/p_extract_dandelion.jpg",
            "images": ["/static/images/p_extract_dandelion.jpg"],
            "options": [{"name": "60봉 (1개월)", "price_diff": 0}, {"name": "120봉 (2개월)", "price_diff": 68000}],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "국산 자연산 야관문 (비수리) 500g",
            "category": "nature-herbs",
            "sub_category": "건강식품 자연약초",
            "price": 18000,
            "original_price": 22000,
            "origin": "국산 (강원도 청정지역)",
            "weight": "500g",
            "stock": 100,
            "is_best": True,
            "is_new": False,
            "is_md": False,
            "rating": 4.9,
            "review_count": 210,
            "badge": "담금주추천",
            "summary": "꽃이 필 무렵 가장 활성이 좋을 때 채취하여 저온 건조한 야관문",
            "description": "<p>남성 활력과 눈 건강에 좋은 야관문입니다. 담금주용 또는 보리차처럼 끓여 드셔도 좋습니다.</p>",
            "image": "/static/images/p_herb_yagwanmun.jpg",
            "images": ["/static/images/p_herb_yagwanmun.jpg"],
            "options": [{"name": "500g", "price_diff": 0}, {"name": "1kg", "price_diff": 16000}],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "국산 충북 제천 황기 3~4년근 200g (특상 등급)",
            "category": "nature-herbs",
            "sub_category": "건강식품 자연약초",
            "price": 22000,
            "original_price": 26000,
            "origin": "충북 제천 청정지역 100%",
            "weight": "200g",
            "stock": 90,
            "is_best": False,
            "is_new": False,
            "is_md": False,
            "rating": 4.8,
            "review_count": 87,
            "badge": "인기",
            "summary": "굵기가 굵고 향이 달착지근하며 기력 회복 삼계탕 및 한방차에 필수인 황기",
            "description": "<p>원기 회복과 땀을 다스리는 데 으뜸인 제천 3~4년근 최상급 황기입니다.</p>",
            "image": "/static/images/p_herb_hwanggi.jpg",
            "images": ["/static/images/p_herb_hwanggi.jpg"],
            "options": [{"name": "200g", "price_diff": 0}, {"name": "500g", "price_diff": 28000}],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "국산 자연산 영지버섯 300g (야생 적영지)",
            "category": "wild-mushrooms",
            "sub_category": "자연산 버섯",
            "price": 55000,
            "original_price": 65000,
            "origin": "국산 (강원도 깊은 산)",
            "weight": "300g",
            "stock": 30,
            "is_best": True,
            "is_new": False,
            "is_md": True,
            "rating": 5.0,
            "review_count": 73,
            "badge": "명품버섯",
            "summary": "참나무 원목에서 자연 발생한 야생 적영지버섯",
            "description": "<p>불로초라 불리는 자연산 영지버섯입니다. 쌉싸름한 맛이 깊고 은은하며 면역력 증진에 좋습니다.</p>",
            "image": "/static/images/p_mushroom_youngji.jpg",
            "images": ["/static/images/p_mushroom_youngji.jpg"],
            "options": [{"name": "300g", "price_diff": 0}, {"name": "600g", "price_diff": 48000}],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "러시아 시베리아 자연산 차가버섯 300g (1등급 덩어리)",
            "category": "wild-mushrooms",
            "sub_category": "자연산 버섯",
            "price": 49000,
            "original_price": 58000,
            "origin": "러시아 시베리아 야생 자작나무 100%",
            "weight": "300g (조각/분쇄용)",
            "stock": 40,
            "is_best": False,
            "is_new": False,
            "is_md": False,
            "rating": 4.9,
            "review_count": 51,
            "badge": "직수입",
            "summary": "영하 40도 혹한의 자작나무 수액을 머금고 자란 시베리아산 정품 차가버섯",
            "description": "<p>베타글루칸과 활성 항산화 성분이 농축된 프리미엄 야생 차가버섯입니다.</p>",
            "image": "/static/images/p_mushroom_chaga.jpg",
            "images": ["/static/images/p_mushroom_chaga.jpg"],
            "options": [{"name": "300g", "price_diff": 0}, {"name": "1kg", "price_diff": 95000}],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "강원도 자연산 마가목 껍질 300g (정선 고지대)",
            "category": "magamok",
            "sub_category": "마가목 특산품",
            "price": 35000,
            "original_price": 40000,
            "origin": "강원도 정선군 100%",
            "weight": "300g",
            "stock": 55,
            "is_best": True,
            "is_new": False,
            "is_md": True,
            "rating": 4.9,
            "review_count": 109,
            "badge": "강원특산",
            "summary": "허리, 뼈 건강과 기관지에 좋은 정선 야생 마가목 껍질",
            "description": "<p>강원도 높은 산지의 거친 자연에서 자라난 야생 마가목 껍질을 채취하여 건조한 특산품입니다.</p>",
            "image": "/static/images/p_herb_magamok_bark.jpg",
            "images": ["/static/images/p_herb_magamok_bark.jpg"],
            "options": [{"name": "300g", "price_diff": 0}, {"name": "600g", "price_diff": 32000}],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "자연산 인진쑥 (사철쑥) 진액 60봉 (100ml)",
            "category": "liquid-extract",
            "sub_category": "수제 건강 액기스즙",
            "price": 68000,
            "original_price": 78000,
            "origin": "국산 (강원도 영월 / 충북 괴산)",
            "weight": "100ml x 60포",
            "stock": 28,
            "is_best": False,
            "is_new": False,
            "is_md": True,
            "rating": 4.8,
            "review_count": 42,
            "badge": "추천",
            "summary": "겨울의 눈 속에서도 죽지 않는 생명력, 순수 야생 인진쑥 저온 추출 엑기스",
            "description": "<p>간과 위의 건강을 돕고 몸의 노폐물 배출에 좋은 사철쑥 100% 진액입니다.</p>",
            "image": "/static/images/p_extract_injin.jpg",
            "images": ["/static/images/p_extract_injin.jpg"],
            "options": [{"name": "60봉", "price_diff": 0}, {"name": "120봉", "price_diff": 60000}],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "국산 자연산 환삼덩굴 200g (청정 건조)",
            "category": "rare-herbs",
            "sub_category": "희귀 자연산약초",
            "price": 20000,
            "original_price": 24000,
            "origin": "국산 100%",
            "weight": "200g",
            "stock": 65,
            "is_best": False,
            "is_new": True,
            "is_md": False,
            "rating": 4.7,
            "review_count": 39,
            "badge": "인기",
            "summary": "혈압 안정과 열을 내리는 데 탁월한 자연산 환삼덩굴 잎과 줄기",
            "description": "<p>깨끗한 청정 구릉지대에서 채취하여 이물질을 완벽히 세척 건조한 약초입니다.</p>",
            "image": "/static/images/p_herb_hwansam.jpg",
            "images": ["/static/images/p_herb_hwansam.jpg"],
            "options": [{"name": "200g", "price_diff": 0}],
            "created_at": datetime.datetime.now()
        },
        {
            "name": "국산 자연산 부처손 (권백) 300g",
            "category": "rare-herbs",
            "sub_category": "희귀 자연산약초",
            "price": 32000,
            "original_price": 38000,
            "origin": "국산 (바위 절벽 야생 채취)",
            "weight": "300g",
            "stock": 42,
            "is_best": False,
            "is_new": False,
            "is_md": False,
            "rating": 4.8,
            "review_count": 55,
            "badge": "희귀약초",
            "summary": "생명력이 끈질긴 바위솔 바위손, 항암 및 여성 질환 보조 약초",
            "description": "<p>바위 벼랑에서 자라나는 신비의 약초 부처손입니다. 차로 끓여 드시거나 가루내어 드십니다.</p>",
            "image": "/static/images/p_herb_bucheoson.jpg",
            "images": ["/static/images/p_herb_bucheoson.jpg"],
            "options": [{"name": "300g", "price_diff": 0}],
            "created_at": datetime.datetime.now()
        }
    ]
    
    col_products().delete_many({})
    col_products().insert_many(products)
    print(f"Inserted {len(products)} products.")

    # 4. Users (Admin & Demo Member)
    users = [
        {
            "username": "admin",
            "password": generate_password_hash("admin1234"),
            "name": "관리자",
            "email": "admin@kangwons.com",
            "phone": "033-762-8114",
            "points": 999999,
            "is_admin": True,
            "created_at": datetime.datetime.now()
        },
        {
            "username": "testuser",
            "password": generate_password_hash("1234"),
            "name": "김강원",
            "email": "user@kangwons.com",
            "phone": "010-1234-5678",
            "points": 2000,
            "is_admin": False,
            "created_at": datetime.datetime.now()
        }
    ]
    col_users().delete_many({})
    col_users().insert_many(users)
    print(f"Inserted {len(users)} users.")

    # 5. Notices
    notices = [
        {
            "title": "강원약초 신규 회원가입 시 즉시 사용 가능한 2,000원 적립금 증정 이벤트",
            "content": "강원약초 쇼핑몰에 오신 것을 환영합니다! 신규 회원가입을 하시는 모든 고객님께 첫 구매부터 바로 사용 가능한 2,000 포인트가 자동 지급됩니다.",
            "is_important": True,
            "views": 328,
            "created_at": datetime.datetime.now() - datetime.timedelta(days=10)
        },
        {
            "title": "강원도 청정지역 산지직송 채취 원칙 및 안심 배송 안내",
            "content": "저희 강원약초는 30년 경력의 심마니와 약초 전문가가 강원도 고지대에서 정성껏 채취한 100% 진품 토종 약초만을 공급합니다. 평일 오후 2시 이전 주문 시 당일 우체국/로젠택배로 발송됩니다.",
            "is_important": True,
            "views": 512,
            "created_at": datetime.datetime.now() - datetime.timedelta(days=7)
        },
        {
            "title": "2026년 주요 카드사 무이자 할부 혜택 안내 (최대 6개월)",
            "content": "국민/신한/삼성/현대/농협 카드 5만원 이상 결제 시 2~6개월 무이자 할부 혜택이 적용됩니다.",
            "is_important": False,
            "views": 184,
            "created_at": datetime.datetime.now() - datetime.timedelta(days=2)
        }
    ]
    col_notices().delete_many({})
    col_notices().insert_many(notices)
    print(f"Inserted {len(notices)} notices.")

    # 6. Reviews
    reviews = [
        {
            "product_name": "(강원약초) 국산 자연산 말굽버섯 300g",
            "author": "이*호",
            "rating": 5,
            "title": "버섯 상태가 정말 단단하고 향이 깊네요.",
            "content": "부모님 건강을 위해 구매했는데 약초 상태가 너무 훌륭합니다. 함께 보내주신 레시피대로 끓여서 매일 아침 드시고 계시는데 몸이 가뿐하다고 하십니다.",
            "created_at": datetime.datetime.now() - datetime.timedelta(days=3)
        },
        {
            "product_name": "강원도 자연산 마가목껍질 진액 60봉 (100ml)",
            "author": "박*순",
            "rating": 5,
            "title": "진짜 제대로 달인 마가목 엑기스 맞습니다.",
            "content": "다른 곳에서 산 건 밍밍했는데 여기 마가목즙은 첫 모금부터 진하고 깊은 맛이 납니다. 허리 아프던 게 많이 부드러워진 느낌입니다. 재구매 200%입니다.",
            "created_at": datetime.datetime.now() - datetime.timedelta(days=1)
        },
        {
            "product_name": "전통 수제 쌍화차 재료 10가지 1,100g (황금배합)",
            "author": "최*영",
            "rating": 5,
            "title": "온 집안에 은은한 한약 향이 가득해요",
            "content": "겨울철 감기 예방으로 주전자에 푹 달여놓고 온 가족이 마시고 있어요. 약재가 깨끗하고 벌레 하나 없이 정갈하게 포장되어와서 감동했습니다.",
            "created_at": datetime.datetime.now() - datetime.timedelta(hours=14)
        }
    ]
    col_reviews().delete_many({})
    col_reviews().insert_many(reviews)
    print(f"Inserted {len(reviews)} reviews.")

    # 7. Q&A / FAQs
    qnas = [
        {
            "title": "말굽버섯과 영지버섯을 함께 달여 마셔도 되나요?",
            "author": "김*석",
            "is_secret": False,
            "status": "답변완료",
            "question": "말굽버섯과 영지버섯을 같은 주전자에 넣고 끓여 마셔도 궁합이 괜찮은지 문의드립니다.",
            "answer": "안녕하세요 강원약초입니다! 네, 말굽버섯과 영지버섯은 한방에서도 서로의 성질을 보완해 주어 함께 달이셔도 아주 훌륭한 궁합을 자랑합니다. 대추 3~4알을 곁들이시면 더욱 부드럽게 드실 수 있습니다.",
            "created_at": datetime.datetime.now() - datetime.timedelta(days=4)
        },
        {
            "title": "산양산삼 보관 기간 문의",
            "author": "정*희",
            "is_secret": False,
            "status": "답변완료",
            "question": "선물용으로 5일 뒤에 전해드려야 하는데 어떻게 보관해야 신선도가 유지될까요?",
            "answer": "수령하신 이끼 목함 상태 그대로 냉장실(야채칸, 1~3도)에 보관하시면 2주 이상 싱싱하게 유지됩니다. 이끼가 마르지 않도록 분무기로 가볍게 수분을 보충해 주시면 좋습니다.",
            "created_at": datetime.datetime.now() - datetime.timedelta(days=2)
        }
    ]
    col_qna().delete_many({})
    col_qna().insert_many(qnas)
    print(f"Inserted {len(qnas)} Q&As.")

    print("Database seeding completed successfully!")

if __name__ == "__main__":
    seed_database()
