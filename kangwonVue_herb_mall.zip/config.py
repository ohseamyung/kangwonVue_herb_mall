import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'kangwon-herb-secret-key-2026-super-secure-key-32bytes!')
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'kangwon-jwt-secret-key-2026-super-secure-key-32bytes!')
    MONGODB_URI = os.environ.get('MONGODB_URI', 'mongodb://localhost:27017/')
    DB_NAME = os.environ.get('DB_NAME', 'kangwon_mall_db')
    
    # Shopping Mall Policies
    FREE_SHIPPING_THRESHOLD = 50000   # 5만원 이상 무료배송
    SHIPPING_FEE = 3200               # 기본 배송비 3,200원
    SIGNUP_POINT = 2000               # 회원가입 축하 적립금 2,000원
    POINT_EARN_RATE = 0.01            # 구매 금액의 1% 적립
    
    # Store Info (from kangwons.com)
    STORE_NAME = "강원약초"
    STORE_DESC = "강원도 자연산 토종약초 채취 판매"
    TEL_PRIMARY = "033-762-8114"
    TEL_MOBILE = "010-8638-6380"
    HOURS = "AM 10:00 ~ PM 06:00 (SAT, SUN, HOLIDAY OFF)"
    BANK_NAME = "농협은행"
    BANK_ACCOUNT = "302-0851-0319-21"
    BANK_HOLDER = "강영자(강원약초)"
    ADDRESS = "강원특별자치도 원주시 육판길 27-11 (태장동)"
    CEO = "강영자"
    EMAIL = "glala1007@hanmail.net"
    BIZ_NUMBER = "129-23-86759"
    COMMERCE_NUMBER = "2010-강원원주-00187"
