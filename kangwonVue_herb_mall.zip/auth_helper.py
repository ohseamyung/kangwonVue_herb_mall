import jwt
import datetime
from functools import wraps
from flask import request, jsonify
from config import Config
from db import col_users, to_object_id, serialize_doc

def generate_token(user):
    now = datetime.datetime.now(datetime.timezone.utc)
    is_admin = (user.get('role') == 'admin') or bool(user.get('is_admin'))
    payload = {
        'user_id': str(user['_id']),
        'username': user.get('username'),
        'role': 'admin' if is_admin else 'user',
        'is_admin': is_admin,
        'exp': now + datetime.timedelta(days=7),
        'iat': now
    }
    return jwt.encode(payload, Config.JWT_SECRET_KEY, algorithm='HS256')

def get_current_user():
    auth_header = request.headers.get('Authorization')
    if auth_header and auth_header.startswith('Bearer '):
        token = auth_header.split(' ')[1]
        try:
            payload = jwt.decode(token, Config.JWT_SECRET_KEY, algorithms=['HS256'])
            user_id = payload.get('user_id')
            if user_id:
                user = col_users().find_one({'_id': to_object_id(user_id)})
                if user and payload.get('role') == 'admin':
                    user['role'] = 'admin'
                return user
        except (jwt.ExpiredSignatureError, jwt.InvalidTokenError):
            return None
    return None

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = get_current_user()
        if not user:
            return jsonify({'error': '로그인이 필요한 서비스입니다.', 'code': 'UNAUTHORIZED'}), 401
        return f(user, *args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = get_current_user()
        is_admin = user and ((user.get('role') == 'admin') or bool(user.get('is_admin')))
        if not is_admin:
            return jsonify({'error': '관리자 권한이 필요합니다.', 'code': 'FORBIDDEN'}), 403
        return f(user, *args, **kwargs)
    return decorated_function
